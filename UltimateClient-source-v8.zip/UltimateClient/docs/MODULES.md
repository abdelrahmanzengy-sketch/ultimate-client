# Module reference (generated from the code)

118 modules. All start disabled with no keybind. Set values with `/uc set <module> <setting> <value>`.
Visual (Render) modules describe what to draw; **a world renderer is not written yet, so ESP-style modules show nothing in-game** (see STATUS.md).

## Combat (34)

### Crystal Aura (`crystal-aura`)
Places and breaks end crystals for maximum damage with self-damage protection.

- `place` = true - Place crystals
- `break` = true - Break crystals
- `place-range` = 4.5 [1 to 6] - Placement range
- `break-range` = 4.5 [1 to 6] - Break range
- `target-range` = 10 [3 to 12] - Max distance of targets
- `max-targets` = 1 [1 to 4] - Targets considered at once
- `min-damage` = 6 [0 to 36] - Minimum damage to a target
- `max-self-damage` = 8 [0 to 36] - Maximum damage to yourself
- `self-weight` = 1 [0 to 4] - Score penalty per self-damage point
- `friend-max-damage` = 2 [0 to 36] - Skip any crystal that hurts a friend by this much
- `predict-ticks` = 0 [0 to 10] - Predict target movement (ticks)
- `face-place` = true - Lower min damage on low-health targets
- `face-place-health` = 8 [0 to 20] - Health threshold for face-place
- `place-delay` = 0 [0 to 20] - Place delay (ticks)
- `break-delay` = 0 [0 to 20] - Break delay (ticks)
- `auto-switch` = true - Switch to crystals in the hotbar
- `switch-back` = true - Restore previous slot after placing
- `rotate` = false - Look at the crystal/placement
- `pause-on-eat` = true - Pause while using an item
- `pause-on-mine` = false - Pause while mining

### Kill Aura (`kill-aura`)
Automatically attacks nearby entities.

- `range` = 3.5 [1 to 6] - Attack range
- `wall-range` = 0 [0 to 6] - Range when no line of sight
- `players` = true - Target players
- `animals` = false - Target passive mobs
- `monsters` = true - Target hostile mobs
- `target-friends` = false - Target friends (normally off)
- `priority` = Distance [Distance, Health, Angle] - Target priority
- `max-targets` = 1 [1 to 5] - Entities hit per swing
- `rotate` = true - Look at the target
- `min-cooldown` = 0.95 [0 to 1] - Attack cooldown progress required (0-1)

### Anchor Aura (`anchor-aura`)
Places, charges and detonates respawn anchors on nearby enemies.

- `range` = 4.5 [1 to 6] - Reach for placing/charging/detonating
- `target-range` = 8 [3 to 12] - Max distance of targets
- `min-damage` = 6 [0 to 36] - Minimum damage to the target
- `max-self-damage` = 6 [0 to 36] - Maximum damage to you
- `self-weight` = 1 [0 to 4] - Score penalty per self-damage point
- `charges` = 1 [1 to 4] - Glowstone charges before detonating
- `delay` = 1 [0 to 20] - Ticks between actions
- `place` = true - Place new anchors
- `rotate` = false - Look at the anchor

### Auto Totem (`auto-totem`)
Keeps a totem in the offhand.

- `delay` = 0 [0 to 10] - Delay between swaps (ticks)
- `use-inventory` = true - Also take totems from the main inventory
- `health-threshold` = 36 [1 to 36] - Only act at or below this health (36 = always)

### Auto Offhand (`auto-offhand`)
Keeps your preferred item in the offhand.

- `item` = Golden Apple [Totem, Crystal, Golden Apple] - Offhand item
- `totem-health` = 10 [0 to 36] - Use a totem at or below this health
- `delay` = 1 [0 to 10] - Delay between swaps (ticks)

### Auto Armor (`auto-armor`)
Wears the best armor in your inventory.

- `delay` = 3 [0 to 20] - Ticks between swaps
- `head` = true - Manage helmets
- `chest` = true - Manage chestplates (never replaces an elytra)
- `legs` = true - Manage leggings
- `feet` = true - Manage boots

### Auto Weapon (`auto-weapon`)
Equips your best melee weapon when aiming at an entity.

- `prefer` = Sword [Sword, Axe] - Preferred weapon
- `switch-back` = true - Restore the previous slot when the target is gone

### Aim Assist (`aim-assist`)
Gently steers your aim toward nearby players.

- `range` = 5 [1 to 8] - Maximum distance
- `fov` = 90 [10 to 360] - Only targets within this many degrees of your view
- `speed` = 4 [0.5 to 30] - Max degrees turned per tick
- `vertical` = true - Also adjust pitch
- `aim-at` = Chest [Head, Chest, Feet] - Body part
- `only-with-weapon` = false - Only while holding a sword or axe

### Trigger Bot (`trigger-bot`)
Hits the player you are aiming at when the weapon is ready.

- `min-cooldown` = 0.95 [0.1 to 1] - Attack once the weapon is this recharged
- `mobs` = false - Also attack hostile mobs
- `pause-on-use` = true - Pause while eating/blocking

### Auto City (`auto-city`)
Breaks the blocks around a surrounded enemy.

- `range` = 4.5 [1 to 6] - Mining reach
- `target-range` = 6 [2 to 10] - Max distance of targets
- `only-if-surrounded` = true - Only act when every side of the enemy is blocked

### Shield Breaker (`shield-breaker`)
Disables enemy shields with an axe.

- `min-cooldown` = 0.9 [0.1 to 1] - Attack once the weapon is this recharged

### Auto EXP (`auto-exp`)
Repairs armor with experience bottles when it is safe.

- `threshold` = 0.9 [0.1 to 1] - Throw while the most damaged armor piece is below this durability fraction
- `delay` = 2 [0 to 20] - Ticks between throws
- `enemy-range` = 8 [0 to 20] - Pause when a player is closer than this

### Surround (`surround`)
Places obsidian around your feet.

- `rotate` = false - Look at placement
- `only-on-ground` = true - Only when on ground
- `blocks-per-tick` = 2 [1 to 8] - Blocks placed per tick
- `auto-disable` = false - Disable once surrounded

### Auto Trap (`auto-trap`)
Traps the nearest enemy in obsidian.

- `range` = 4.5 [1 to 6] - Target and placement range
- `blocks-per-tick` = 2 [1 to 8] - Blocks per tick
- `top` = true - Cover the top
- `rotate` = false - Look at placement

### Self Trap (`self-trap`)
Places obsidian above/around your head.

- `mode` = Top [Top, Full] - Top = above head, Full = also head-height sides
- `blocks-per-tick` = 2 [1 to 8] - Blocks per tick

### Auto Web (`auto-web`)
Webs the nearest enemy.

- `range` = 4.5 [1 to 6] - Target and placement range
- `head` = true - Also web head height

### Self Web (`self-web`)
Webs your own position.

- `auto-disable` = true - Disable after placing

### Hole Filler (`hole-filler`)
Fills nearby holes enemies could use.

- `range` = 4.5 [1 to 6] - Fill range
- `enemy-range` = 6 [1 to 12] - Only fill holes this close to an enemy
- `blocks-per-tick` = 1 [1 to 6] - Blocks per tick

### Jump Reset (`jump-reset`)
Jumps the moment you are hit on the ground.

- `chance` = 100 [1 to 100] - Chance to react to a hit (percent)
- `only-moving` = false - Only react while holding a movement key

### Crystal Macro (`crystal-macro`)
Places and breaks crystals where you aim.

- `delay` = 1 [0 to 10] - Ticks between actions
- `place` = true - Place crystals on the aimed base
- `break` = true - Hit the aimed crystal
- `swap` = true - Switch to crystals in the hotbar when needed
- `max-self-damage` = 8 [0 to 36] - Skip actions that would deal more than this to you

### Crystal Optimizer (`crystal-optimizer`)
Instantly hits the crystal you aim at.

- `max-self-damage` = 10 [0 to 36] - Do not hit crystals that would deal more than this to you
- `min-gap` = 0 [0 to 5] - Minimum ticks between hits
- `only-with-crystals` = false - Only active while holding crystals

### Single Anchor Macro (`single-anchor-macro`)
Place, charge and detonate the anchor you aim at.

- `delay` = 2 [0 to 20] - Ticks between steps
- `charges` = 1 [1 to 4] - Glowstone charges before detonating
- `place` = false - Place an anchor on the aimed block first
- `max-self-damage` = 8 [0 to 36] - Do not detonate if you would take more than this
- `detonate-slot` = 1 [1 to 9] - Hotbar slot (1-9) used to detonate; must not hold glowstone

### Anti Anchor (`anti-anchor`)
Blocks the line to nearby charged anchors.

- `radius` = 5 [2 to 8] - Look for charged anchors within this many blocks
- `per-tick` = 2 [1 to 4] - Blocks placed per tick
- `rotate` = false - Look at the block being placed

### Anchor Guard (`anchor-guard`)
Seals head height when anchors are nearby.

- `radius` = 6 [2 to 10] - Act when an anchor is within this many blocks
- `roof` = true - Also cap the block above your head
- `per-tick` = 2 [1 to 5] - Blocks placed per tick

### Anti Bed (`anti-bed`)
Blocks the line to nearby beds.

- `radius` = 4 [2 to 7] - Look for beds within this many blocks
- `per-tick` = 2 [1 to 4] - Blocks placed per tick

### Bed Aura (`bed-aura`)
Places and detonates beds next to enemies (Nether/End).

- `range` = 4.5 [1 to 6] - Placement reach
- `target-range` = 7 [3 to 10] - Max target distance
- `min-damage` = 6 [0 to 36] - Minimum damage to the target
- `max-self-damage` = 6 [0 to 36] - Maximum damage to you
- `delay` = 2 [0 to 20] - Ticks between actions

### Auto Anvil (`auto-anvil`)
Drops anvils on enemies standing in holes.

- `range` = 5 [2 to 6] - Placement reach
- `height` = 3 [2 to 5] - Blocks above the target's feet to place the anvil
- `delay` = 10 [1 to 40] - Ticks between anvils
- `only-in-hole` = true - Only target players standing in a 1x1 hole

### Anti Anvil (`anti-anvil`)
Caps your head against falling anvils.

- `always` = false - Keep the cap up even without an anvil above
- `scan-height` = 6 [2 to 10] - How far above your head to look for anvils

### Criticals (`criticals`)
Hops so your hit lands as a falling critical.

- `min-charge` = 0.9 [0.5 to 1] - Attack charge needed before hopping (0-1)
- `living-only` = true - Only hop when aiming at a player or mob

### W-Tap (`w-tap`)
Resets sprint after each hit.

- `release-ticks` = 2 [1 to 6] - Ticks to stay un-sprinted

### Mace (`mace`)
Equips a mace while you fall onto a target.

- `min-fall` = 1.5 [0.5 to 20] - Fall distance (blocks) before switching
- `need-target` = true - Only when aiming at an entity

### Auto Inventory Totem (`auto-inventory-totem`)
Fills the offhand with a totem when you open your inventory.

- `delay` = 1 [0 to 10] - Ticks between swaps

### Hover Totem (`hover-totem`)
Hover a totem in your inventory to equip it.

- `delay` = 1 [0 to 10] - Ticks between swaps

### Friend Guard (`friend-guard`)
Stops you from hitting friends.

- `sneak-override` = true - Hold sneak to hit a friend anyway

## Movement (27)

### Fly (`fly`)
Allows free flight.

- `mode` = Hover [Hover, Glide] - Hover holds height, Glide sinks slowly
- `speed` = 0.5 [0.05 to 3] - Horizontal speed (blocks/tick)
- `vertical-speed` = 0.4 [0.05 to 3] - Vertical speed (blocks/tick)

### Elytra Fly (`elytra-fly`)
Controlled elytra flight.

- `speed` = 1.2 [0.1 to 4] - Forward speed (blocks/tick)
- `vertical-speed` = 0.5 [0.05 to 2] - Vertical speed (blocks/tick)
- `idle-sink` = 0.02 [0 to 0.3] - Sink rate while hovering

### Speed (`speed`)
Increases forward movement speed.

- `speed` = 0.35 [0.1 to 1.5] - Horizontal speed (blocks/tick; walking is ~0.22)
- `in-water` = false - Work in water

### Sprint (`sprint`)
Automatically sprints while moving.

- `omni` = false - Sprint on any movement input, not only forward

### No Fall (`no-fall`)
Prevents fall damage.

- `min-fall` = 2.5 [1 to 20] - Fall distance before acting

### Auto Walk (`auto-walk`)
Walks forward without holding the key.

- `stop-on-sneak` = true - Stop walking while sneaking

### High Jump (`high-jump`)
Jumps higher.

- `power` = 0.8 [0.42 to 3] - Jump velocity (vanilla is 0.42)

### Air Jump (`air-jump`)
Jump again while airborne.

- `jumps` = 1 [1 to 10] - Extra jumps before landing
- `power` = 0.42 [0.1 to 1] - Upward speed of each extra jump

### Jesus (`jesus`)
Walk on liquids.

- `lift` = 0.1 [0.02 to 0.4] - Upward speed at the surface (blocks/tick)
- `lava` = false - Also float on lava (it still burns you)

### Reverse Step (`reverse-step`)
Drop off ledges quickly.

- `max-drop` = 2 [1 to 4] - Only for drops of at most this many blocks
- `pull` = 0.8 [0.1 to 2] - Downward speed (blocks/tick)

### Elytra Autopilot (`elytra-autopilot`)
Flies your elytra to a coordinate.

- `target-x` = 0 [-30000000 to 30000000] - Destination X
- `target-z` = 0 [-30000000 to 30000000] - Destination Z
- `arrive-radius` = 12 [2 to 200] - Stop within this many blocks of the target
- `turn-rate` = 6 [1 to 30] - Max degrees turned per tick
- `climb-pitch` = -30 [-60 to 0] - Pitch used to gain height (degrees, negative = up)
- `dive-pitch` = 20 [0 to 60] - Pitch used to gain speed (degrees)

### Long Jump (`long-jump`)
Jump farther.

- `boost` = 1.6 [1 to 3] - Horizontal speed multiplier at take-off

### Slow Fall (`slow-fall`)
Fall gently.

- `max-fall` = 0.1 [0.02 to 0.5] - Fastest allowed fall speed (blocks/tick)

### Step (`step`)
Walk up blocks instantly.

- `height` = 1 [0.6 to 2.5] - Step height in blocks

### Safe Walk (`safe-walk`)
Prevents falling off ledges.

- `max-drop` = 2 [1 to 5] - Drops of at most this many blocks are allowed
- `look-ahead` = 3 [1 to 8] - Ticks of motion to look ahead

### Auto Jump (`auto-jump`)
Hops over single blocks automatically.

- `reach` = 0.8 [0.4 to 1.5] - How far ahead to look (blocks)

### Parkour (`parkour`)
Auto-jumps at ledges.

- `edge` = 0.35 [0.1 to 0.9] - Distance from the ledge to jump (blocks)

### Spider (`spider`)
Climb walls like a spider.

- `speed` = 0.2 [0.05 to 0.8] - Climb speed (blocks/tick)

### Fast Climb (`fast-climb`)
Climb ladders quickly.

- `speed` = 0.3 [0.1 to 1] - Climb speed (blocks/tick)

### Sneak (`sneak`)
Keeps you sneaking.

- `only-when-moving` = false - Sneak only while you are moving

### Anti Void (`anti-void`)
Saves you from falling into the void.

- `void-y` = -56 [-128 to 320] - Act below this Y (overworld bottom is -64)
- `lift` = 0.8 [0.1 to 2] - Upward speed (blocks/tick)

### Strafe (`strafe`)
Steers horizontal motion in the air toward your input.

- `boost` = 0.26 [0.1 to 1] - Minimum air speed while steering (blocks/tick)
- `keep-speed` = true - Keep your current speed if it is higher than the minimum

### Velocity (`velocity`)
Reduces knockback you take (client side).

- `horizontal` = 0 [0 to 100] - Horizontal knockback kept (percent)
- `vertical` = 100 [0 to 100] - Vertical knockback kept (percent)

### Elytra Boost (`elytra-boost`)
Accelerates elytra flight while moving forward.

- `boost` = 0.03 [0.005 to 0.2] - Speed added per tick (blocks/tick)
- `max-speed` = 1.6 [0.5 to 4] - Stop boosting above this speed (blocks/tick)

### Boat Fly (`boat-fly`)
Flies while riding a boat.

- `horizontal` = 0.8 [0.1 to 3] - Forward speed (blocks/tick)
- `vertical` = 0.3 [0.05 to 1.5] - Climb/descend speed (blocks/tick)
- `hover` = true - Hold height when no vertical key is pressed

### Entity Speed (`entity-speed`)
Speeds up the mount you are riding.

- `speed` = 0.5 [0.1 to 3] - Horizontal speed (blocks/tick)

### GUI Move (`gui-move`)
Move while your inventory is open.

- `jump` = true - Also allow jumping
- `sneak` = true - Also allow sneaking

## Player (13)

### Auto Respawn (`auto-respawn`)
Respawns automatically after death.

- `delay` = 0.5 [0 to 5] - Seconds to wait before respawning

### Auto Eat (`auto-eat`)
Eats automatically when hungry.

- `hunger` = 14 [1 to 19] - Eat at or below this food level
- `prefer-golden-apple` = false - Eat golden apples first

### Auto Gap (`auto-gap`)
Eats golden apples when hurt.

- `health` = 12 [2 to 20] - Eat at or below this health (hearts x2)
- `only-without-absorption` = true - Skip while you still have absorption hearts

### Auto Tool (`auto-tool`)
Picks the best tool while mining.

- `switch-back` = true - Restore the previous slot when you stop mining

### Auto Replenish (`auto-replenish`)
Keeps your hotbar stacks topped up.

- `threshold` = 8 [1 to 32] - Refill when a hotbar stack has this many or fewer
- `delay` = 4 [1 to 40] - Ticks between refills

### Auto Fish (`auto-fish`)
Fishes for you.

- `auto-cast` = true - Cast automatically when no bobber is out
- `recast-delay` = 20 [5 to 100] - Ticks to wait after reeling before casting

### Auto Clicker (`auto-clicker`)
Clicks on the entity you are aiming at.

- `delay` = 4 [1 to 40] - Ticks between clicks
- `players-only` = false - Only click players

### Chest Swap (`chest-swap`)
Swap between elytra and chestplate.

- `notify` = true - Tell me in chat what was swapped

### Anti AFK (`anti-afk`)
Periodically nudges the camera.

- `interval` = 400 [20 to 2400] - Ticks between look changes

### Fast Use (`fast-use`)
Removes the delay between item uses.

- `cooldown` = 0 [0 to 4] - Maximum ticks between uses (vanilla is 4)

### Fast XP (`fast-xp`)
Throws experience bottles without the delay.

- `cooldown` = 0 [0 to 4] - Maximum ticks between throws

### Break Delay (`break-delay`)
Shortens the delay between mined blocks.

- `delay` = 0 [0 to 5] - Maximum ticks between blocks

### Speed Mine (`speed-mine`)
Mines blocks faster.

- `boost` = 0.05 [0.01 to 0.5] - Extra progress per tick (0.1 = a tenth of a block)

## Render (22)

### Fullbright (`fullbright`)
See clearly in the dark.

- `dark-below` = 15 [1 to 15] - Only brighten where the light level is below this (15 = always)

### Zoom (`zoom`)
Zoom in.

- `fov` = 30 [30 to 110] - FOV while zoomed
- `smooth` = 12 [1 to 110] - Max FOV change per tick (110 = instant)

### Custom FOV (`custom-fov`)
Sets your field of view.

- `fov` = 100 [30 to 110] - Field of view (vanilla limits 30-110)

### Entity ESP (`entity-esp`)
Highlights mobs.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `hostile` = true - Show hostile mobs
- `passive` = false - Show passive mobs

### Player ESP (`player-esp`)
Highlights other players.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `friend-color` = #FF30FF60 - Colour for friends
- `health` = true - Show health in the label

### Item ESP (`item-esp`)
Highlights dropped items.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)

### Storage ESP (`storage-esp`)
Highlights chests and other storage.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `types` = chest,barrel,shulker_box,hopper,furnace,dispenser,dropper - Block id fragments to show, comma separated

### Block ESP (`block-esp`)
Highlights chosen blocks.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `scan-radius` = 16 [4 to 48] - Horizontal scan radius
- `scan-height` = 16 [4 to 48] - Vertical scan range up and down
- `scan-budget` = 600 [100 to 5000] - Blocks examined per tick (lower = faster)
- `blocks` = diamond_ore,emerald_ore,ancient_debris - Block id fragments, comma separated

### Netherite Finder (`netherite-finder`)
Highlights ancient debris.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `scan-radius` = 16 [4 to 48] - Horizontal scan radius
- `scan-height` = 16 [4 to 48] - Vertical scan range up and down
- `scan-budget` = 600 [100 to 5000] - Blocks examined per tick (lower = faster)
- `blocks` = ancient_debris - Block id fragments, comma separated

### Spawner ESP (`spawner-esp`)
Highlights monster spawners.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `scan-radius` = 16 [4 to 48] - Horizontal scan radius
- `scan-height` = 16 [4 to 48] - Vertical scan range up and down
- `scan-budget` = 600 [100 to 5000] - Blocks examined per tick (lower = faster)
- `blocks` = spawner - Block id fragments, comma separated

### Hole ESP (`hole-esp`)
Shows safe and half-safe holes.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `safe-color` = #FF30FF60 - Colour of fully safe holes
- `radius` = 6 [2 to 12] - Search radius
- `interval` = 10 [1 to 60] - Ticks between searches
- `show-breakable` = true - Also show holes with breakable sides

### City ESP (`city-esp`)
Shows breakable blocks around an enemy in a hole.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `target-range` = 8 [2 to 16] - Max distance of the enemy

### Target ESP (`target-esp`)
Highlights the nearest enemy player.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)

### Tracers (`tracers`)
Draws lines to players.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `friend-color` = #FF30FF60 - Colour for friends
- `mobs` = false - Also draw lines to hostile mobs

### Nametags (`nametags`)
Shows name, health and distance above players.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `distance-text` = true - Show distance in the label

### Trajectories (`trajectories`)
Shows where thrown items and arrows will land.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `steps` = 80 [10 to 200] - Maximum simulated ticks

### Pearl Trajectory (`pearl-trajectory`)
Shows where flying ender pearls will land.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `steps` = 120 [10 to 300] - Maximum simulated ticks

### Breadcrumbs (`breadcrumbs`)
Draws the path you walked.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `length` = 300 [20 to 2000] - Points kept
- `spacing` = 1 [0.25 to 8] - Distance between points (blocks)

### Logout Spots (`logout-spots`)
Marks where players logged out.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `keep` = 10 [1 to 40] - Spots remembered
- `seen-range` = 64 [8 to 160] - Only record players who were this close

### Waypoints (`waypoints`)
Shows saved positions in the world.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `data` =  - Stored waypoints (edit with /uc wp)

### Block Overlay (`block-overlay`)
Highlights the block under your crosshair.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)

### Light Overlay (`light-overlay`)
Shows where mobs can spawn.

- `color` = #FFFF3030 - Main colour
- `opacity` = 0.6 [0.05 to 1] - Opacity (0.05 - 1)
- `distance` = 64 [4 to 256] - Maximum distance in blocks
- `thickness` = 1.5 [0.5 to 6] - Line thickness
- `style` = Outline [Outline, Fill, Both] - Render style
- `labels` = true - Show text labels
- `max-draw` = 150 [10 to 1000] - Maximum shapes per frame (lower = faster)
- `max-light` = 0 [0 to 7] - Mark tiles with block light at or below this
- `radius` = 6 [2 to 12] - Search radius
- `interval` = 10 [2 to 60] - Ticks between scans

## World (13)

### Nuker (`nuker`)
Mines everything around you.

- `range` = 4 [1 to 6] - Radius
- `mode` = All [All, Flatten] - All blocks, or only blocks at/above your feet
- `skip-liquids` = true - Ignore fluids
- `per-tick` = 1 [1 to 8] - Break attempts per tick (helps in creative)

### Tunnel Miner (`tunnel-miner`)
Digs a tunnel in front of you.

- `width` = 1 [1 to 5] - Tunnel width
- `height` = 2 [1 to 5] - Tunnel height
- `depth` = 4 [1 to 6] - How many blocks ahead to clear
- `walk` = false - Walk forward while the way ahead is clear

### Vein Miner (`vein-miner`)
Mines whole ore veins.

- `filter` = _ore,ancient_debris - Comma-separated id fragments (e.g. _ore,ancient_debris); empty = any block
- `max-blocks` = 32 [1 to 128] - Largest vein to mine
- `range` = 5 [2 to 6] - Mining reach

### Liquid Filler (`liquid-filler`)
Fills in liquids around you.

- `range` = 4 [1 to 5] - Reach
- `per-tick` = 2 [1 to 8] - Blocks per tick

### Spawn Proofer (`spawn-proofer`)
Lights up mob-spawnable ground.

- `range` = 4 [1 to 5] - Reach
- `max-light` = 0 [0 to 7] - Place where light is at or below this
- `per-tick` = 1 [1 to 4] - Torches per tick

### Stash Finder (`stash-finder`)
Reports chunks with many chests and barrels.

- `threshold` = 8 [2 to 100] - Announce chunks with at least this many containers
- `interval` = 40 [10 to 400] - Ticks between scans
- `types` = chest,barrel,shulker_box,hopper - Block id fragments counted, comma separated

### E-Chest Farmer (`echest-farmer`)
Mines nearby ender chests.

- `range` = 4.5 [2 to 6] - Reach

### Excavator (`excavator`)
Digs out a box you define (pos1/pos2).

- `range` = 4.5 [2 to 6] - Reach
- `per-tick` = 1 [1 to 6] - Break attempts per tick
- `max-volume` = 20000 [100 to 200000] - Refuse boxes larger than this many blocks

### Waypoint Navigation (`waypoint-nav`)
Walks straight to a waypoint.

- `stop-distance` = 2 [0.5 to 10] - Stop when this close (blocks)
- `sprint` = true - Sprint while walking

### Auto Shearer (`auto-shearer`)
Shears sheep in reach.

- `range` = 3.5 [1 to 5] - Reach
- `cooldown` = 600 [20 to 6000] - Ticks before shearing the same sheep again

### Auto Breed (`auto-breed`)
Feeds animals so they breed.

- `range` = 3.5 [1 to 5] - Reach
- `cooldown` = 6000 [100 to 24000] - Ticks before feeding the same animal again (breeding cooldown is 6000)

### Auto Mount (`auto-mount`)
Boards a nearby mount automatically.

- `range` = 3 [1 to 5] - Reach
- `delay` = 20 [5 to 100] - Ticks between tries
- `boats-minecarts` = true - Also board boats and minecarts

### Baritone (`baritone`)
Settings and control for the Baritone pathfinder.

- `allow-break` = true - Let Baritone break blocks
- `allow-place` = true - Let Baritone place blocks
- `allow-sprint` = true - Let Baritone sprint
- `allow-parkour` = false - Allow jumping gaps
- `free-look` = false - Look around freely while Baritone walks
- `chat-control` = false - Let Baritone react to # chat commands

## Misc (8)

### Chat Macro (`chat-macro`)
Sends a saved chat message.

- `message` =  - Message or /command to send
- `mode` = Once [Once, Repeat] - Send once then turn off, or repeat
- `interval` = 200 [40 to 24000] - Ticks between repeats (min 40)

### Player Detection (`player-detection`)
Announces players entering your range.

- `range` = 64 [8 to 256] - Detection radius
- `ignore-friends` = true - Do not announce friends
- `announce-leave` = true - Also announce when they leave

### Weather Notifier (`weather-notifier`)
Announces weather changes.

- `announce-rain` = true - Announce when rain starts
- `announce-clear` = true - Announce when rain stops

### Block Notifier (`block-notifier`)
Announces valuable blocks nearby.

- `blocks` = diamond_ore,ancient_debris - Comma-separated id fragments, e.g. diamond_ore,ancient_debris,spawner
- `range` = 16 [4 to 32] - Scan radius
- `per-tick` = 300 [50 to 2000] - Positions checked per tick (lower = lighter)

### Staff List (`staff-list`)
Announces watched staff names joining or leaving.

- `names` =  - Staff names, comma separated
- `interval` = 20 [5 to 200] - Ticks between checks
- `announce-leave` = true - Also announce when they leave

### Auto Reconnect (`auto-reconnect`)
Rejoins the server after a disconnect.

- `seconds` = 5 [1 to 120] - Wait before reconnecting
- `max-attempts` = 5 [1 to 50] - Give up after this many tries in a row

### Auto Relog (`auto-relog`)
Rejoins after matching disconnects with growing waits.

- `reasons` = restart,timed out,connection,lost,closed - Reconnect when the message contains any of these (comma separated)
- `base-seconds` = 5 [1 to 60] - First wait; doubles after each failed try
- `max-attempts` = 6 [1 to 20] - Give up after this many tries

### Name Protect (`name-protect`)
Hides your real username on your screen.

- `name` = Player - Name to show instead of yours

## Client (1)

### Client Brand (`client-brand`)
Changes the brand string sent to servers. Not a stealth feature.

- `mode` = Vanilla [Vanilla, Fabric, Custom] - Brand string to send
- `custom` = vanilla - Brand used in Custom mode (printable ASCII, max 32)
