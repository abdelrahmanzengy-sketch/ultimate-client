package dev.ultimate.modules.misc;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

public final class NameProtect extends Module {
    public final Setting.Str replacement;
    public final Setting.Bool protectFriends;

    public NameProtect() {
        super("name-protect", "Name Protect", "Hides your name and optionally friends' names.", Category.MISC);
        replacement = add(new Setting.Str("replacement", "Replacement text", "Player", 32));
        protectFriends = add(new Setting.Bool("protect-friends", "Also protect friends", true));
    }
}