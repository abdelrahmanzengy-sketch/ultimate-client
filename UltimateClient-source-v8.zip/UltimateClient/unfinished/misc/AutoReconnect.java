package dev.ultimate.modules.misc;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

public final class AutoReconnect extends Module {
    public final Setting.Num delay;

    public AutoReconnect() {
        super("auto-reconnect", "Auto Reconnect", "Reconnects after being disconnected.", Category.MISC);
        delay = add(Setting.Num.dbl("delay", "Delay in seconds", 5.0, 0.5, 60.0, 0.5));
    }
}