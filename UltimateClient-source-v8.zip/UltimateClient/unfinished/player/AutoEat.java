package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

public final class AutoEat extends Module {
    public final Setting.Num hunger;
    public final Setting.Num health;
    public final Setting.Bool pauseAura;
    public final Setting.Bool preferGapples;

    public AutoEat() {
        super("auto-eat", "Auto Eat", "Eats food when hungry or low health.", Category.PLAYER);
        hunger = add(Setting.Num.intg("hunger", "Hunger threshold", 14, 1, 20));
        health = add(Setting.Num.dbl("health", "Health threshold", 0.0, 0.0, 20.0, 0.5));
        pauseAura = add(new Setting.Bool("pause-aura", "Pause combat modules while eating", true));
        preferGapples = add(new Setting.Bool("prefer-gapples", "Prefer golden apples", false));
    }
}