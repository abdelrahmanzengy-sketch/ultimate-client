package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

public final class FastUse extends Module {
    public final Setting.Num delay;
    public final Setting.Bool xp;
    public final Setting.Bool blocks;
    public final Setting.Bool all;

    public FastUse() {
        super("fast-use", "Fast Use", "Reduces right-click delay.", Category.PLAYER);
        delay = add(Setting.Num.intg("delay", "Use delay (ticks)", 0, 0, 4));
        xp = add(new Setting.Bool("xp", "Affect experience bottles", true));
        blocks = add(new Setting.Bool("blocks", "Affect blocks", false));
        all = add(new Setting.Bool("all", "Affect everything", false));
    }
}