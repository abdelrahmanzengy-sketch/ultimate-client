package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

/** Increases movement speed. Has multiple modes: Straight, Vanilla, and Bhop. */
public final class Speed extends Module {
    public final Setting.Mode mode;
    public final Setting.Num speed;
    public final Setting.Bool inWater;
    public final Setting.Bool useTimer;

    public Speed() {
        super("speed", "Speed", "Increases movement speed.", Category.MOVEMENT);
        mode = add(new Setting.Mode("mode", "Speed mode", "Strafe", "Strafe", "Vanilla", "BHop"));
        speed = add(Setting.Num.dbl("speed", "Speed multiplier", 1.6, 0.1, 10.0, 0.1));
        inWater = add(new Setting.Bool("in-water", "Work in water", false));
        useTimer = add(new Setting.Bool("use-timer", "Use timer boost", false));
    }
}