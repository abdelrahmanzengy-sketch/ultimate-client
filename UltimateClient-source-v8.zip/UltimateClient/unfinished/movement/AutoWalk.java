package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

/** Walks forward automatically. Actual input injection is version-specific. */
public final class AutoWalk extends Module {
    public final Setting.Mode mode;

    public AutoWalk() {
        super("auto-walk", "Auto Walk", "Walks forward without holding the key.", Category.MOVEMENT);
        mode = add(new Setting.Mode("mode", "Direction mode", "Forward", "Forward", "Backwards", "Left", "Right"));
    }
}
