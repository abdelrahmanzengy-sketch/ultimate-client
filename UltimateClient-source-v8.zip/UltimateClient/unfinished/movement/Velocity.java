package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

public final class Velocity extends Module {
    public final Setting.Num horizontal;
    public final Setting.Num vertical;
    public final Setting.Bool knockback;
    public final Setting.Bool explosions;

    public Velocity() {
        super("velocity", "Velocity", "Modifies knockback taken.", Category.MOVEMENT);
        horizontal = add(Setting.Num.dbl("horizontal", "Horizontal knockback %", 0.0, 0.0, 100.0, 1.0));
        vertical = add(Setting.Num.dbl("vertical", "Vertical knockback %", 0.0, 0.0, 100.0, 1.0));
        knockback = add(new Setting.Bool("knockback", "Modify entity knockback", true));
        explosions = add(new Setting.Bool("explosions", "Modify explosion knockback", true));
    }
}