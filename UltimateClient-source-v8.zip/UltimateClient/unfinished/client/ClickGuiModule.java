package dev.ultimate.modules.client;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

/**
 * Toggle for the Click GUI. The actual screen is not implemented yet.
 * Keybind defaults to Right Shift (key code 344 in GLFW).
 */
public final class ClickGuiModule extends Module {
    public final Setting.Key openKey;

    public ClickGuiModule() {
        super("click-gui", "Click GUI", "Opens the module configuration interface.", Category.CLIENT);
        openKey = add(new Setting.Key("open-key", "Key used to open the GUI", 344)); // GLFW_KEY_RIGHT_SHIFT
        setKeybind(344);
    }

    @Override
    protected void onEnable() {
        // When the real GUI exists, open it here and then disable the module
        // so the toggle acts as a momentary open.
        setEnabled(false);
    }
}
