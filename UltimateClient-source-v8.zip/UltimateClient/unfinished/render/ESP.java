package dev.ultimate.modules.render;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

public final class ESP extends Module {
    public final Setting.Bool players;
    public final Setting.Bool animals;
    public final Setting.Bool monsters;
    public final Setting.Bool items;
    public final Setting.Color playerColor;
    public final Setting.Num range;
    public final Setting.Mode mode;
    public final Setting.Bool tracers;

    public ESP() {
        super("esp", "ESP", "Highlights entities through walls.", Category.RENDER);
        players = add(new Setting.Bool("players", "Show players", true));
        animals = add(new Setting.Bool("animals", "Show animals", false));
        monsters = add(new Setting.Bool("monsters", "Show monsters", true));
        items = add(new Setting.Bool("items", "Show items", false));
        playerColor = add(new Setting.Color("player-color", "Player color", 0xFF55FFFF));
        range = add(Setting.Num.dbl("range", "Max distance", 64.0, 8.0, 256.0, 8.0));
        mode = add(new Setting.Mode("mode", "Render mode", "Box", "Box", "Outline", "Glow"));
        tracers = add(new Setting.Bool("tracers", "Draw tracers", false));
    }
}