package dev.ultimate.modules.render;

/**
 * Forces maximum gamma / removes darkness.
 * The actual gamma change is applied from a version-specific render or option mixin.
 */
public final class Fullbright extends Module {
    public final Setting.Mode mode;
    public final Setting.Num gamma;

    public Fullbright() {
        super("fullbright", "Fullbright", "Removes darkness and lighting restrictions.", Category.RENDER);
        mode = add(new Setting.Mode("mode", "How fullbright is applied", "Gamma", "Gamma", "NightVision"));
        gamma = add(Setting.Num.dbl("gamma", "Gamma value when mode is Gamma", 16.0, 1.0, 16.0, 0.5));
        gamma.visibleWhen(() -> mode.get().equals("Gamma"));
    }
}