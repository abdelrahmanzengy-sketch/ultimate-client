package dev.ultimate.modules.render;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

public final class Xray extends Module {
    public final Setting.Bool ores;
    public final Setting.Bool spawners;
    public final Setting.Num opacity;
    public final Setting.Bool exposedOnly;

    public Xray() {
        super("xray", "Xray", "Shows selected blocks through walls.", Category.RENDER);
        ores = add(new Setting.Bool("ores", "Show ores", true));
        spawners = add(new Setting.Bool("spawners", "Show spawners", true));
        opacity = add(Setting.Num.dbl("opacity", "Non-selected block opacity", 0.2, 0.0, 1.0, 0.05));
        exposedOnly = add(new Setting.Bool("exposed-only", "Only show exposed blocks", false));
    }
}