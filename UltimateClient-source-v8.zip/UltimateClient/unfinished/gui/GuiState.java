package dev.ultimate.gui;

/**
 * Pure data for the Click GUI layout and open state.
 * Actual screen rendering is version-specific and not implemented yet.
 */
public final class GuiState {
    public boolean open;
    public int panelX = 40;
    public int panelY = 40;
    public int panelWidth = 220;
    public String selectedCategory = "Combat";
    public String search = "";
    public String expandedModuleId = null;

    public void toggle() {
        open = !open;
        if (!open) {
            search = "";
            expandedModuleId = null;
        }
    }
}
