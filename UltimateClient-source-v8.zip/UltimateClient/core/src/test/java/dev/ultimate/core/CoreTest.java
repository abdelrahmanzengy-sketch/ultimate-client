package dev.ultimate.core;

import java.nio.file.*;
import java.util.*;

public final class CoreTest {
    static int fails = 0, checks = 0;
    static void check(boolean c, String msg) { checks++; if (!c) { fails++; System.out.println("FAIL: " + msg); } }

    record Ping(int n) {}

    static final class Counter extends Module {
        int enables, disables, ticks, pings; final Setting.Num speed; final Setting.Mode mode; final Setting.Bool flag; final Setting.Color col;
        Counter(String id) {
            super(id, "Counter " + id, "counts things", Category.MISC);
            speed = add(Setting.Num.dbl("speed", "speed", 1.0, 0.1, 5.0, 0.1));
            mode = add(new Setting.Mode("mode", "mode", "A", "A", "B", "C"));
            flag = add(new Setting.Bool("flag", "flag", false));
            col = add(new Setting.Color("color", "color", 0xFF336699));
        }
        @Override protected void onEnable() { enables++; listen(Ping.class, p -> pings += p.n()); }
        @Override protected void onDisable() { disables++; }
        @Override protected void onTick() { ticks++; }
    }
    static final class Bomb extends Module {
        final String where; Bomb(String where) { super("bomb-" + where, "Bomb", "throws", Category.COMBAT); this.where = where; }
        @Override protected void onEnable() { if (where.equals("enable")) throw new IllegalStateException("boom"); listen(Ping.class, p -> { throw new RuntimeException("listener boom"); }); }
        @Override protected void onTick() { if (where.equals("tick")) throw new IllegalStateException("tick boom"); }
        @Override protected void onDisable() { if (where.equals("disable")) throw new IllegalStateException("disable boom"); }
    }

    public static void main(String[] a) throws Exception {
        List<String> logs = new ArrayList<>();
        ModuleManager mm = new ModuleManager(logs::add);
        Counter c1 = new Counter("one"), c2 = new Counter("two");
        mm.register(c1); mm.register(c2);

        // duplicate / bad ids
        try { mm.register(new Counter("one")); check(false, "duplicate id accepted"); } catch (IllegalArgumentException e) { check(true, ""); }
        try { new Counter("Bad Id"); check(false, "bad id accepted"); } catch (IllegalArgumentException e) { check(true, ""); }

        // lifecycle
        check(c1.setEnabled(true) && c1.isEnabled() && c1.enables == 1, "enable");
        mm.tick(); mm.tick(); check(c1.ticks == 2 && c2.ticks == 0, "tick only enabled");
        mm.bus().post(new Ping(3)); check(c1.pings == 3 && c2.pings == 0, "event routed to enabled only");
        c1.setEnabled(false); check(c1.disables == 1 && mm.bus().listenerCount(c1) == 0, "disable unsubscribes");
        mm.bus().post(new Ping(5)); check(c1.pings == 3, "no events after disable");
        c1.setEnabled(false); check(c1.disables == 1, "double disable is a no-op");
        for (int i = 0; i < 1000; i++) { c1.toggle(); } check(mm.bus().listenerCount(c1) == 0 && !c1.isEnabled(), "no listener leak after 1000 toggles");

        // settings validation
        check(!c1.speed.set(Double.NaN) && c1.speed.get() == 1.0, "NaN rejected");
        c1.speed.set(99.0); check(c1.speed.get() == 5.0, "clamped high");
        check(!c1.mode.set("Z") && c1.mode.get().equals("A"), "bad mode rejected");
        check(c1.mode.set("B"), "good mode");
        Setting.Num in = Setting.Num.intg("n", "n", 3, 1, 10); in.set(4.6); check(in.asInt() == 5, "int rounding");
        c1.col.set(0xFFFF0000); check(c1.col.fromJson(c1.col.toJson()) && c1.col.get() == 0xFFFF0000, "color roundtrip incl. negative int");
        try { Setting.Num.dbl("x", "x", 100, 0, 10, 1); check(false, "out-of-range default accepted"); } catch (IllegalArgumentException e) { check(true, ""); }
        c1.resetSettings(); check(c1.mode.get().equals("A") && c1.speed.get() == 1.0, "reset");

        // error isolation
        Bomb be = new Bomb("enable"), bt = new Bomb("tick"), bd = new Bomb("disable"), bl = new Bomb("listener");
        for (Bomb b : List.of(be, bt, bd, bl)) mm.register(b);
        check(!be.setEnabled(true) && !be.isEnabled() && be.lastError() != null, "enable failure leaves module off");
        bt.setEnabled(true); c2.setEnabled(true); mm.tick(); check(!bt.isEnabled() && c2.isEnabled() && c2.ticks == 1, "tick failure disables only that module");
        bd.setEnabled(true); check(bd.setEnabled(false) && !bd.isEnabled(), "throwing onDisable still disables");
        bl.setEnabled(true); int before = c2.pings; mm.bus().post(new Ping(1)); check(c2.pings == before + 1, "throwing listener doesn't block others");
        bl.setEnabled(false);

        // keybinds, search, favorites, recent, world leave
        c2.setEnabled(false); c2.setKeybind(70);
        check(mm.onKey(70) && c2.isEnabled() && !mm.onKey(71) && !mm.onKey(-1), "keybind toggles");
        check(mm.search("counter t").size() == 1 && mm.search("THINGS").size() >= 2 && mm.search("").size() == mm.all().size(), "search");
        mm.setFavorite("one", true); mm.setFavorite("nope", true); check(mm.favorites().equals(Set.of("one")), "favorites ignore unknown ids");
        check(mm.recent().get(0).equals("two"), "recent order");
        mm.onWorldLeave(); check(c2.isEnabled(), "world leave default keeps module");

        // config roundtrip
        Path dir = Files.createTempDirectory("uc-test");
        ConfigManager cm = new ConfigManager(dir, mm);
        c1.setKeybind(82); c1.mode.set("C"); c1.speed.set(2.5); c1.col.set(0xCC112233); c1.setEnabled(true);
        mm.layout.put("hud.watermark", new LinkedHashMap<>(Map.of("x", 12.0, "y", 8.0, "scale", 1.5)));
        cm.save("pvp");
        c1.setKeybind(-1); c1.mode.set("A"); c1.speed.set(1.0); c1.setEnabled(false); mm.layout.clear(); mm.setFavorite("one", false);
        check(cm.load("pvp") == null, "load ok");
        check(c1.keybind() == 82 && c1.mode.get().equals("C") && c1.speed.get() == 2.5 && c1.col.get() == 0xCC112233 && c1.isEnabled(), "settings+keybind+enabled restored");
        check(mm.layout.get("hud.watermark") instanceof Map<?, ?> m && ((Number) m.get("scale")).doubleValue() == 1.5, "layout restored");
        check(mm.isFavorite("one"), "favorites restored");
        check(cm.profiles().equals(List.of("pvp")), "profile list");

        // hostile / corrupt files
        Files.writeString(dir.resolve("bad.json"), "{ not json");
        check(cm.load("bad") != null, "corrupt file reported");
        Files.writeString(dir.resolve("arr.json"), "[1,2]");
        check(cm.load("arr") != null, "non-object reported");
        Files.writeString(dir.resolve("future.json"), "{\"schema\": 99}");
        check(cm.load("future") != null, "future schema refused");
        Files.writeString(dir.resolve("junk.json"), "{\"schema\":1,\"modules\":{\"ghost\":{},\"one\":{\"settings\":{\"speed\":\"fast\",\"mode\":\"Z\",\"nothing\":1,\"flag\":true},\"keybind\":\"x\"}},\"favorites\":[1,\"two\"]}");
        double sp = c1.speed.get(); String md = c1.mode.get(); check(cm.load("junk") == null && c1.speed.get() == sp && c1.mode.get().equals(md) && c1.flag.get() && c1.keybind() == 82, "invalid values skipped, valid applied");
        Files.writeString(dir.resolve("old.json"), "{\"config\":{\"one\":{\"settings\":{\"speed\":4}}}}");
        check(cm.load("old") == null && c1.speed.get() == 4.0, "schema 0 migrated");
        check(cm.load("../etc/passwd") != null && cm.load("nope") != null, "bad names / missing profile");
        try { cm.save("../x"); check(false, "path traversal save accepted"); } catch (IllegalArgumentException e) { check(true, ""); }
        check(!cm.delete("../x") && cm.delete("pvp") && !cm.profiles().contains("pvp"), "delete");
        try (var s = Files.list(dir)) { check(s.noneMatch(p -> p.toString().endsWith(".tmp")), "no temp files left"); }

        // json edge cases
        String tricky = "line\n\"quote\" \\ tab\t \u0001 é";
        check(Json.parse(Json.write(Map.of("s", tricky))) instanceof Map<?, ?> m && tricky.equals(m.get("s")), "json string escapes");
        try { Json.parse("[".repeat(500)); check(false, "deep nesting accepted"); } catch (IllegalArgumentException e) { check(true, ""); }
        try { Json.write(Double.NaN); check(false, "NaN written"); } catch (IllegalArgumentException e) { check(true, ""); }

        mm.disableAll(); boolean allOff = true; for (Module m : mm.all()) allOff &= !m.isEnabled(); check(allOff, "disableAll");
        System.out.println(checks + " checks, " + fails + " failures");
        System.exit(fails == 0 ? 0 : 1);
    }
}
