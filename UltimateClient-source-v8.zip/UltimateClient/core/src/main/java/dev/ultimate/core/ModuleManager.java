package dev.ultimate.core;

import java.util.*;
import java.util.function.Consumer;

/** Central registry: registration, ticking, keybinds, search, favorites and recently used. */
public final class ModuleManager {
    private final Map<String, Module> modules = new LinkedHashMap<>();
    private final EventBus bus;
    private final Consumer<String> logger;
    private final Set<String> favorites = new LinkedHashSet<>();
    private final ArrayDeque<String> recent = new ArrayDeque<>();
    /** Free-form GUI/HUD layout state (positions, sizes, open panels); persisted by ConfigManager. */
    public final Map<String, Object> layout = new LinkedHashMap<>();
    private static final int RECENT_MAX = 8;

    public ModuleManager(Consumer<String> logger) { this.logger = logger; this.bus = new EventBus(logger); }
    public ModuleManager() { this(s -> System.err.println("[UltimateClient] " + s)); }

    public EventBus bus() { return bus; }
    void log(String m) { logger.accept(m); }

    public void register(Module m) {
        if (modules.containsKey(m.id)) throw new IllegalArgumentException("duplicate module id " + m.id);
        modules.put(m.id, m); m.attach(this);
    }

    public Module get(String id) { return modules.get(id); }
    public Collection<Module> all() { return Collections.unmodifiableCollection(modules.values()); }

    public List<Module> inCategory(Category c) {
        List<Module> out = new ArrayList<>();
        for (Module m : modules.values()) if (m.category == c) out.add(m);
        return out;
    }

    /** Case-insensitive match on name, id or description; name matches rank first. */
    public List<Module> search(String q) {
        String s = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        List<Module> hits = new ArrayList<>(), weak = new ArrayList<>();
        for (Module m : modules.values()) {
            if (s.isEmpty() || m.name.toLowerCase(Locale.ROOT).contains(s) || m.id.contains(s)) hits.add(m);
            else if (m.description.toLowerCase(Locale.ROOT).contains(s)) weak.add(m);
        }
        hits.addAll(weak); return hits;
    }

    /** Ticks every enabled module; one failing module never affects the others. */
    public void tick() { for (Module m : modules.values()) m.tick(); }

    /** Collects draw requests from every enabled module; a failing module is disabled, the rest still draw. */
    public void render(RenderQueue q) { for (Module m : modules.values()) m.render(q); }

    /** @return true if a keybind matched (so the caller can consume the key). */
    public boolean onKey(int key) {
        if (key < 0) return false;
        boolean hit = false;
        for (Module m : modules.values()) if (m.keybind() == key) { m.toggle(); hit = true; }
        return hit;
    }

    public void onWorldLeave() { for (Module m : modules.values()) m.worldLeave(); }

    public void disableAll() { for (Module m : modules.values()) m.setEnabled(false); }

    // ---- favorites / recent ----
    public boolean isFavorite(String id) { return favorites.contains(id); }
    public void setFavorite(String id, boolean fav) { if (!modules.containsKey(id)) return; if (fav) favorites.add(id); else favorites.remove(id); }
    public Set<String> favorites() { return Collections.unmodifiableSet(favorites); }
    public List<String> recent() { return List.copyOf(recent); }
    void noteEnabled(Module m) {
        recent.remove(m.id); recent.addFirst(m.id);
        while (recent.size() > RECENT_MAX) recent.removeLast();
    }
    void restoreRecent(List<String> ids) { recent.clear(); for (String id : ids) if (modules.containsKey(id) && recent.size() < RECENT_MAX) recent.addLast(id); }
}
