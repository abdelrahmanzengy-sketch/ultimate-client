package dev.ultimate.game;

public record BlockPos(int x, int y, int z) {
    public BlockPos up() { return new BlockPos(x, y + 1, z); }
    public BlockPos offset(int dx, int dy, int dz) { return new BlockPos(x + dx, y + dy, z + dz); }
    public Vec3 center() { return new Vec3(x + 0.5, y + 0.5, z + 0.5); }
}
