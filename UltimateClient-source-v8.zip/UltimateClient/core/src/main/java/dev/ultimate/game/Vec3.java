package dev.ultimate.game;

/** Immutable 3D vector (pure Java, version independent). */
public record Vec3(double x, double y, double z) {
    public static final Vec3 ZERO = new Vec3(0, 0, 0);
    public Vec3 add(double dx, double dy, double dz) { return new Vec3(x + dx, y + dy, z + dz); }
    public Vec3 add(Vec3 o) { return add(o.x, o.y, o.z); }
    public Vec3 scale(double s) { return new Vec3(x * s, y * s, z * s); }
    public double distanceTo(Vec3 o) { double a = x - o.x, b = y - o.y, c = z - o.z; return Math.sqrt(a * a + b * b + c * c); }
    public double horizontalLength() { return Math.sqrt(x * x + z * z); }
}
