package dev.ultimate.core;

import java.util.*;

/**
 * Simple case-insensitive friend list used by combat modules for protection.
 * Pure data - no Minecraft dependency.
 */
public final class FriendManager {
    private final Set<String> friends = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

    public boolean add(String name) {
        if (name == null || name.isBlank()) return false;
        return friends.add(name.trim());
    }

    public boolean remove(String name) {
        if (name == null) return false;
        return friends.remove(name.trim());
    }

    public boolean isFriend(String name) {
        return name != null && friends.contains(name.trim());
    }

    public Set<String> all() {
        return Collections.unmodifiableSet(friends);
    }

    public void clear() {
        friends.clear();
    }

    public List<Object> toJson() {
        return new ArrayList<>(friends);
    }

    public void fromJson(Object o) {
        friends.clear();
        if (o instanceof List<?> list) {
            for (Object item : list) {
                if (item instanceof String s && !s.isBlank()) friends.add(s.trim());
            }
        }
    }
}
