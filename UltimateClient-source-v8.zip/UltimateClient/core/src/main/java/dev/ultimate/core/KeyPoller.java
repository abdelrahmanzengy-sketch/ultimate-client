package dev.ultimate.core;

import java.util.function.IntPredicate;

/**
 * Fires module keybinds on the rising edge of a key press. Call {@link #poll} once per client tick.
 * No allocations per poll. Keys held while a screen is open never fire when the screen closes.
 */
public final class KeyPoller {
    private final ModuleManager mm; private final IntPredicate down; private final boolean[] prev = new boolean[512];
    public KeyPoller(ModuleManager mm, IntPredicate down) { this.mm = mm; this.down = down; }

    public void poll(boolean blocked) {
        for (Module m : mm.all()) {
            int k = m.keybind();
            if (k < 0 || k >= prev.length) continue;
            boolean d = down.test(k);
            if (d && !prev[k] && !blocked) { prev[k] = true; mm.onKey(k); }   // onKey toggles every module on this key once
            prev[k] = d;
        }
    }
}
