package dev.ultimate.combat;

import dev.ultimate.game.EntityInfo;
import dev.ultimate.game.Vec3;

/**
 * Explosion damage model following vanilla's formulas (exposure ray-sampling, distance falloff,
 * difficulty scaling, armor/toughness, resistance and blast-protection reduction).
 * Block collision is approximated as full cubes (slabs, stairs etc. are treated as solid or not by the caller).
 * Pure Java so it can be unit-tested; it has not been compared with an in-game explosion.
 */
public final class Explosion {
    private Explosion() {}

    public enum Kind {
        CRYSTAL(6f), ANCHOR(5f), BED(5f);
        public final float power;
        Kind(float p) { power = p; }
    }

    public interface Blocks { boolean solid(int x, int y, int z); }

    /** Fraction (0..1) of sample points on the entity's box that can see the explosion center. */
    public static double exposure(Blocks blocks, Vec3 c, Vec3 min, Vec3 max) {
        double dx = 1.0 / ((max.x() - min.x()) * 2.0 + 1.0);
        double dy = 1.0 / ((max.y() - min.y()) * 2.0 + 1.0);
        double dz = 1.0 / ((max.z() - min.z()) * 2.0 + 1.0);
        double ox = (1.0 - Math.floor(1.0 / dx) * dx) / 2.0, oz = (1.0 - Math.floor(1.0 / dz) * dz) / 2.0;
        if (dx < 0 || dy < 0 || dz < 0) return 0;
        int hit = 0, total = 0;
        for (double fx = 0; fx <= 1.0; fx += dx)
            for (double fy = 0; fy <= 1.0; fy += dy)
                for (double fz = 0; fz <= 1.0; fz += dz) {
                    double px = min.x() + (max.x() - min.x()) * fx + ox;
                    double py = min.y() + (max.y() - min.y()) * fy;
                    double pz = min.z() + (max.z() - min.z()) * fz + oz;
                    if (clear(blocks, px, py, pz, c.x(), c.y(), c.z())) hit++;
                    total++;
                }
        return total == 0 ? 0 : (double) hit / total;
    }

    /** Voxel traversal (Amanatides-Woo): true if no solid block lies between the two points. */
    public static boolean clear(Blocks b, double x0, double y0, double z0, double x1, double y1, double z1) {
        int x = (int) Math.floor(x0), y = (int) Math.floor(y0), z = (int) Math.floor(z0);
        int ex = (int) Math.floor(x1), ey = (int) Math.floor(y1), ez = (int) Math.floor(z1);
        double dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
        int sx = (int) Math.signum(dx), sy = (int) Math.signum(dy), sz = (int) Math.signum(dz);
        double tdx = sx == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dx);
        double tdy = sy == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dy);
        double tdz = sz == 0 ? Double.POSITIVE_INFINITY : Math.abs(1.0 / dz);
        double tx = sx == 0 ? Double.POSITIVE_INFINITY : (sx > 0 ? (x + 1 - x0) : (x0 - x)) * tdx;
        double ty = sy == 0 ? Double.POSITIVE_INFINITY : (sy > 0 ? (y + 1 - y0) : (y0 - y)) * tdy;
        double tz = sz == 0 ? Double.POSITIVE_INFINITY : (sz > 0 ? (z + 1 - z0) : (z0 - z)) * tdz;
        int guard = 0;
        while (true) {
            if (!(x == ex && y == ey && z == ez) && b.solid(x, y, z)) return false;
            if (x == ex && y == ey && z == ez) return true;
            if (++guard > 256) return false;
            if (tx <= ty && tx <= tz) { x += sx; tx += tdx; }
            else if (ty <= tz) { y += sy; ty += tdy; }
            else { z += sz; tz += tdz; }
        }
    }

    /** Damage (in half-hearts) dealt to {@code e} standing at {@code at}, before absorption. */
    public static float damage(Kind kind, Vec3 center, EntityInfo e, Vec3 at, int difficulty, Blocks blocks) {
        if (difficulty <= 0 && e.kind() == EntityInfo.Kind.PLAYER) return 0f;
        double q = kind.power * 2.0;
        double dist = at.distanceTo(center) / q;
        if (dist > 1.0) return 0f;
        EntityInfo moved = e.movedTo(at);
        double impact = (1.0 - dist) * exposure(blocks, center, moved.boxMin(), moved.boxMax());
        float dmg = (float) ((int) ((impact * impact + impact) / 2.0 * 7.0 * q + 1.0));
        if (e.kind() == EntityInfo.Kind.PLAYER) {
            if (difficulty == 1) dmg = Math.min(dmg / 2f + 1f, dmg);
            else if (difficulty >= 3) dmg = dmg * 3f / 2f;
        }
        dmg = afterArmor(dmg, (float) e.armor(), (float) e.armorToughness());
        if (e.resistanceAmplifier() >= 0) dmg = Math.max(0f, dmg * (25 - (e.resistanceAmplifier() + 1) * 5) / 25f);
        if (e.blastProtectionEpf() > 0) dmg *= 1f - Math.min(20, e.blastProtectionEpf()) / 25f;
        return Math.max(0f, dmg);
    }

    public static float afterArmor(float damage, float armor, float toughness) {
        float f = 2f + toughness / 4f;
        float g = Math.max(armor * 0.2f, Math.min(20f, armor - damage / f));
        return damage * (1f - g / 25f);
    }
}
