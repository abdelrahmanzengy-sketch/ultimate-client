package dev.ultimate.core;

/** Holds the client-brand string the ClientBrand module wants sent to servers (null = leave the game's default). Read by a mixin. */
public final class BrandState {
    private BrandState() {}
    private static volatile String override;
    public static String get() { return override; }
    public static void set(String brand) { override = brand; }

    /** Printable ASCII only, trimmed, 1-32 chars; anything else falls back to "vanilla". */
    public static String sanitize(String s) {
        if (s == null) return "vanilla";
        StringBuilder b = new StringBuilder();
        for (char c : s.toCharArray()) if (c >= 32 && c < 127 && b.length() < 32) b.append(c);
        String t = b.toString().trim();
        return t.isEmpty() ? "vanilla" : t;
    }
}
