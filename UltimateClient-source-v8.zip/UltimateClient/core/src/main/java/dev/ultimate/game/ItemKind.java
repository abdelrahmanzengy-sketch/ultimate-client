package dev.ultimate.game;

/** Item categories modules care about. The version adapter maps real items onto these. */
public enum ItemKind {
    NONE, TOTEM, END_CRYSTAL, OBSIDIAN, GOLDEN_APPLE, WEB, FOOD, OTHER,
    SWORD, AXE, PICKAXE, EXP_BOTTLE, GLOWSTONE, RESPAWN_ANCHOR, ELYTRA, CHESTPLATE, FISHING_ROD, TORCH, FILLER_BLOCK,
    ANVIL, BED, MACE, TRIDENT, PEARL, SHEARS
}
