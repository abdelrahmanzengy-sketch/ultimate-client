package dev.ultimate.core;

/** Text replacement used by Name Protect; read by the text-rendering mixin. Pure Java so it is unit-tested. */
public final class NameState {
    private NameState() {}
    private static volatile String real, fake;
    public static void set(String realName, String fakeName) {
        if (realName == null || realName.isBlank() || fakeName == null) { clear(); return; }
        fake = fakeName; real = realName;
    }
    public static void clear() { real = null; fake = null; }
    public static boolean active() { return real != null; }
    /** Replaces every occurrence of the real name (case-insensitive). Returns the input when inactive. */
    public static String apply(String text) {
        String r = real, f = fake;
        if (r == null || text == null || text.length() < r.length()) return text;
        int i = indexOfIgnoreCase(text, r, 0);
        if (i < 0) return text;
        StringBuilder sb = new StringBuilder(text.length() + 8); int from = 0;
        while (i >= 0) { sb.append(text, from, i).append(f); from = i + r.length(); i = indexOfIgnoreCase(text, r, from); }
        return sb.append(text, from, text.length()).toString();
    }
    private static int indexOfIgnoreCase(String s, String q, int from) {
        int n = s.length() - q.length();
        for (int i = from; i <= n; i++) if (s.regionMatches(true, i, q, 0, q.length())) return i;
        return -1;
    }
}
