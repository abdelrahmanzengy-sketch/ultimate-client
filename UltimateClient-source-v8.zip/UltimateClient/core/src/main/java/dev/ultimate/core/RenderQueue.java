package dev.ultimate.core;

import dev.ultimate.game.Vec3;
import java.util.ArrayList;
import java.util.List;

/**
 * Render primitives that modules ask for each frame. Modules only describe shapes in world coordinates; a per-version
 * renderer draws them. The queue is bounded so a buggy module cannot flood the renderer.
 */
public final class RenderQueue {
    public enum Style { OUTLINE, FILL, BOTH }
    public record Box(Vec3 min, Vec3 max, int argb, Style style, float thickness) {}
    public record Line(Vec3 a, Vec3 b, int argb, float thickness) {}
    public record Label(Vec3 pos, String text, int argb) {}

    public static final int MAX = 4000;
    private final List<Box> boxes = new ArrayList<>(); private final List<Line> lines = new ArrayList<>(); private final List<Label> labels = new ArrayList<>();

    public void clear() { boxes.clear(); lines.clear(); labels.clear(); }
    public int size() { return boxes.size() + lines.size() + labels.size(); }
    public boolean box(Vec3 min, Vec3 max, int argb, Style style, float thickness) { if (size() >= MAX) return false; boxes.add(new Box(min, max, argb, style, thickness)); return true; }
    public boolean line(Vec3 a, Vec3 b, int argb, float thickness) { if (size() >= MAX) return false; lines.add(new Line(a, b, argb, thickness)); return true; }
    public boolean label(Vec3 pos, String text, int argb) { if (size() >= MAX) return false; labels.add(new Label(pos, text, argb)); return true; }
    public List<Box> boxes() { return boxes; }
    public List<Line> lines() { return lines; }
    public List<Label> labels() { return labels; }
}
