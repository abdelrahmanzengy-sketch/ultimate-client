package dev.ultimate.core;

import java.util.*;

/** Minimal dependency-free JSON reader/writer (Map, List, String, Double, Boolean, null). */
public final class Json {
    private Json() {}

    public static String write(Object o) { StringBuilder sb = new StringBuilder(); w(o, sb, 0); return sb.append('\n').toString(); }

    private static void pad(StringBuilder sb, int n) { for (int i = 0; i < n; i++) sb.append("  "); }

    private static void w(Object o, StringBuilder sb, int ind) {
        if (o == null) sb.append("null");
        else if (o instanceof String s) str(s, sb);
        else if (o instanceof Boolean b) sb.append(b.booleanValue());
        else if (o instanceof Number n) {
            double d = n.doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) throw new IllegalArgumentException("non-finite number");
            if (d == Math.rint(d) && Math.abs(d) < 1e15) sb.append((long) d); else sb.append(d);
        } else if (o instanceof Map<?, ?> m) {
            if (m.isEmpty()) { sb.append("{}"); return; }
            sb.append("{\n"); int i = 0;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                pad(sb, ind + 1); str(String.valueOf(e.getKey()), sb); sb.append(": "); w(e.getValue(), sb, ind + 1);
                if (++i < m.size()) sb.append(','); sb.append('\n');
            }
            pad(sb, ind); sb.append('}');
        } else if (o instanceof List<?> l) {
            if (l.isEmpty()) { sb.append("[]"); return; }
            sb.append("[\n");
            for (int i = 0; i < l.size(); i++) {
                pad(sb, ind + 1); w(l.get(i), sb, ind + 1);
                if (i + 1 < l.size()) sb.append(','); sb.append('\n');
            }
            pad(sb, ind); sb.append(']');
        } else throw new IllegalArgumentException("unsupported type " + o.getClass());
    }

    private static void str(String s, StringBuilder sb) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                default -> { if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c); }
            }
        }
        sb.append('"');
    }

    /** Parses JSON text; throws IllegalArgumentException on any malformed input. */
    public static Object parse(String text) {
        Parser p = new Parser(text);
        p.ws();
        Object v = p.value(0);
        p.ws();
        if (p.i != text.length()) throw p.err("trailing data");
        return v;
    }

    private static final class Parser {
        final String s; int i;
        Parser(String s) { this.s = s; }
        IllegalArgumentException err(String m) { return new IllegalArgumentException("JSON: " + m + " at " + i); }
        void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        char peek() { if (i >= s.length()) throw err("unexpected end"); return s.charAt(i); }
        void expect(char c) { if (peek() != c) throw err("expected '" + c + "'"); i++; }

        Object value(int depth) {
            if (depth > 64) throw err("too deep");
            char c = peek();
            if (c == '{') {
                i++; Map<String, Object> m = new LinkedHashMap<>(); ws();
                if (peek() == '}') { i++; return m; }
                while (true) {
                    ws(); String k = string(); ws(); expect(':'); ws();
                    m.put(k, value(depth + 1)); ws();
                    if (peek() == ',') { i++; continue; }
                    expect('}'); return m;
                }
            }
            if (c == '[') {
                i++; List<Object> l = new ArrayList<>(); ws();
                if (peek() == ']') { i++; return l; }
                while (true) {
                    ws(); l.add(value(depth + 1)); ws();
                    if (peek() == ',') { i++; continue; }
                    expect(']'); return l;
                }
            }
            if (c == '"') return string();
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            if (s.startsWith("null", i)) { i += 4; return null; }
            int st = i;
            while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            if (st == i) throw err("unexpected character");
            try { return Double.valueOf(s.substring(st, i)); } catch (NumberFormatException e) { throw err("bad number"); }
        }

        String string() {
            expect('"'); StringBuilder sb = new StringBuilder();
            while (true) {
                char c = peek(); i++;
                if (c == '"') return sb.toString();
                if (c != '\\') { sb.append(c); continue; }
                char e = peek(); i++;
                switch (e) {
                    case '"' -> sb.append('"'); case '\\' -> sb.append('\\'); case '/' -> sb.append('/');
                    case 'n' -> sb.append('\n'); case 'r' -> sb.append('\r'); case 't' -> sb.append('\t');
                    case 'b' -> sb.append('\b'); case 'f' -> sb.append('\f');
                    case 'u' -> {
                        if (i + 4 > s.length()) throw err("bad unicode escape");
                        try { sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); } catch (NumberFormatException ex) { throw err("bad unicode escape"); }
                        i += 4;
                    }
                    default -> throw err("bad escape");
                }
            }
        }
    }
}
