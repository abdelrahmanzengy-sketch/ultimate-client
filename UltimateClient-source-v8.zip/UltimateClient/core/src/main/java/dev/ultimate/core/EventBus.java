package dev.ultimate.core;

import java.util.*;
import java.util.function.Consumer;

/** Allocation-free dispatch (array snapshots); a throwing listener never stops other listeners. */
public final class EventBus {
    private record Sub(Object owner, Consumer<Object> fn) {}
    private static final Sub[] NONE = new Sub[0];

    private final Map<Class<?>, Sub[]> subs = new HashMap<>();
    private final Consumer<String> log;

    public EventBus(Consumer<String> log) { this.log = log; }

    @SuppressWarnings("unchecked")
    public synchronized <E> void subscribe(Object owner, Class<E> type, Consumer<E> fn) {
        Sub[] old = subs.getOrDefault(type, NONE);
        Sub[] n = Arrays.copyOf(old, old.length + 1);
        n[old.length] = new Sub(owner, (Consumer<Object>) fn);
        subs.put(type, n);
    }

    /** Removes every listener registered by owner (called automatically when a module is disabled). */
    public synchronized void unsubscribeAll(Object owner) {
        for (Map.Entry<Class<?>, Sub[]> e : subs.entrySet()) {
            Sub[] arr = e.getValue();
            int keep = 0;
            for (Sub s : arr) if (s.owner != owner) keep++;
            if (keep == arr.length) continue;
            Sub[] n = new Sub[keep]; int i = 0;
            for (Sub s : arr) if (s.owner != owner) n[i++] = s;
            e.setValue(n);
        }
    }

    public int listenerCount(Object owner) {
        int c = 0;
        synchronized (this) { for (Sub[] arr : subs.values()) for (Sub s : arr) if (s.owner == owner) c++; }
        return c;
    }

    public <E> E post(E event) {
        Sub[] arr;
        synchronized (this) { arr = subs.get(event.getClass()); }
        if (arr == null) return event;
        for (Sub s : arr) {
            try { s.fn.accept(event); }
            catch (Throwable t) { log.accept("Event listener failed for " + event.getClass().getSimpleName() + ": " + t); }
        }
        return event;
    }
}
