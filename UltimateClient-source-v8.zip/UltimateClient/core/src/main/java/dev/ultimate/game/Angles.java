package dev.ultimate.game;

/** Minecraft view-angle maths (yaw 0 = +Z, pitch positive = looking down). Pure Java. */
public final class Angles {
    private Angles() {}
    public static final double EYE_HEIGHT = 1.62;

    public static float wrap(float deg) {
        deg %= 360f;
        if (deg >= 180f) deg -= 360f;
        if (deg < -180f) deg += 360f;
        return deg;
    }
    public static float yawTo(Vec3 from, Vec3 to) {
        return (float) (Math.toDegrees(Math.atan2(to.z() - from.z(), to.x() - from.x())) - 90.0);
    }
    public static float pitchTo(Vec3 from, Vec3 to) {
        double h = Math.sqrt((to.x() - from.x()) * (to.x() - from.x()) + (to.z() - from.z()) * (to.z() - from.z()));
        return (float) -Math.toDegrees(Math.atan2(to.y() - from.y(), h));
    }
    public static Vec3 eye(EntityInfo e) { return e.pos().add(0, EYE_HEIGHT, 0); }
    /** Horizontal unit direction for a yaw. */
    public static Vec3 dir(float yawDeg) {
        double r = Math.toRadians(yawDeg);
        return new Vec3(-Math.sin(r), 0, Math.cos(r));
    }
    /** Full 3D look direction. */
    public static Vec3 look(float yawDeg, float pitchDeg) {
        double y = Math.toRadians(yawDeg), p = Math.toRadians(pitchDeg);
        double c = Math.cos(p);
        return new Vec3(-Math.sin(y) * c, -Math.sin(p), Math.cos(y) * c);
    }
    public static float step(float current, float target, float maxStep) {
        float d = wrap(target - current);
        return current + Math.max(-maxStep, Math.min(maxStep, d));
    }
}
