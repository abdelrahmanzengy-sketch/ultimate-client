package dev.ultimate.core;

import java.util.*;

/** GLFW key code <-> readable name, so keybinds can be set and shown without a GUI. Pure Java. */
public final class Keys {
    private Keys() {}
    private static final Map<String, Integer> BY_NAME = new HashMap<>();
    private static final Map<Integer, String> BY_CODE = new HashMap<>();
    private static void reg(String n, int c) { BY_NAME.put(n.toLowerCase(Locale.ROOT), c); BY_CODE.putIfAbsent(c, n); }
    static {
        for (char c = 'A'; c <= 'Z'; c++) reg(String.valueOf(c), c);
        for (char c = '0'; c <= '9'; c++) reg(String.valueOf(c), c);
        for (int i = 1; i <= 25; i++) reg("F" + i, 289 + i);
        for (int i = 0; i <= 9; i++) reg("NUM" + i, 320 + i);
        reg("SPACE", 32); reg("APOSTROPHE", 39); reg("COMMA", 44); reg("MINUS", 45); reg("PERIOD", 46); reg("SLASH", 47);
        reg("SEMICOLON", 59); reg("EQUALS", 61); reg("LBRACKET", 91); reg("BACKSLASH", 92); reg("RBRACKET", 93); reg("GRAVE", 96);
        reg("ESCAPE", 256); reg("ENTER", 257); reg("TAB", 258); reg("BACKSPACE", 259); reg("INSERT", 260); reg("DELETE", 261);
        reg("RIGHT", 262); reg("LEFT", 263); reg("DOWN", 264); reg("UP", 265); reg("PAGEUP", 266); reg("PAGEDOWN", 267);
        reg("HOME", 268); reg("END", 269); reg("LSHIFT", 340); reg("LCTRL", 341); reg("LALT", 342); reg("RSHIFT", 344); reg("RCTRL", 345); reg("RALT", 346);
    }
    /** @return key code, -1 for "none"/"unbound", or -2 if the name is unknown. */
    public static int code(String name) {
        if (name == null) return -2;
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (n.equals("none") || n.equals("unbound") || n.equals("-1")) return -1;
        Integer c = BY_NAME.get(n);
        if (c != null) return c;
        try { int v = Integer.parseInt(n); return v >= 0 && v < 512 ? v : -2; } catch (NumberFormatException e) { return -2; }
    }
    public static String name(int code) { return code < 0 ? "none" : BY_CODE.getOrDefault(code, "key" + code); }
}
