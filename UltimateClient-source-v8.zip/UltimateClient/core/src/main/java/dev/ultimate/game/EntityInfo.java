package dev.ultimate.game;

/** Snapshot of a living entity / crystal. Built by the version adapter once per query, never retained. */
public record EntityInfo(
        int id, Kind kind, String name, Vec3 pos, Vec3 velocity, double width, double height,
        float health, float absorption, double armor, double armorToughness,
        int blastProtectionEpf, int resistanceAmplifier /* -1 = none */, boolean onGround) {

    public enum Kind { PLAYER, CRYSTAL, HOSTILE, PASSIVE, ITEM, OTHER }

    public Vec3 boxMin() { return new Vec3(pos.x() - width / 2, pos.y(), pos.z() - width / 2); }
    public Vec3 boxMax() { return new Vec3(pos.x() + width / 2, pos.y() + height, pos.z() + width / 2); }
    public float effectiveHealth() { return health + absorption; }
    public EntityInfo movedTo(Vec3 p) {
        return new EntityInfo(id, kind, name, p, velocity, width, height, health, absorption, armor, armorToughness,
                blastProtectionEpf, resistanceAmplifier, onGround);
    }
}
