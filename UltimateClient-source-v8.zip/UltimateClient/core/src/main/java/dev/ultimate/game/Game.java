package dev.ultimate.game;

import java.util.List;

/**
 * Everything gameplay modules need from Minecraft. Each supported Minecraft version implements this once
 * (the only Minecraft-facing code); modules stay version independent and can be unit-tested with a fake.
 * All methods are called on the client thread. Queries on unloaded chunks must return "not solid, not loaded".
 */
public interface Game {
    boolean inWorld();
    boolean selfDead();
    /** The local player; only valid while {@link #inWorld()}. */
    EntityInfo self();
    /** All loaded entities except the local player. */
    List<EntityInfo> entities();
    long tick();
    int difficulty(); // 0 peaceful .. 3 hard

    // ---- world ----
    boolean isLoaded(int x, int z);
    boolean isSolid(int x, int y, int z);
    boolean isAir(int x, int y, int z);
    /** Obsidian or bedrock: valid end-crystal base. */
    boolean isCrystalBase(int x, int y, int z);
    /** True if nothing (entity or block) blocks a crystal being placed on top of base. */
    boolean canPlaceCrystal(BlockPos base);

    // ---- inventory ----
    int selectedSlot();
    void selectSlot(int hotbarSlot);
    /** Hotbar slot (0-8) holding the item, or -1. */
    int hotbarSlotOf(ItemKind kind);
    /** Main-inventory slot (9-35) holding the item, or -1. */
    int mainInvSlotOf(ItemKind kind);
    ItemKind mainHand();
    ItemKind offhand();
    /** Swap the given inventory slot with the offhand. */
    void swapWithOffhand(int invSlot);

    // ---- actions (return false if the game refused / impossible) ----
    boolean placeCrystal(BlockPos base);
    boolean placeBlock(BlockPos at);
    boolean attack(int entityId);
    void lookAt(Vec3 point);
    void setVelocity(Vec3 v);
    void setSprinting(boolean on);
    void respawn();

    // ---- input / state ----
    boolean movingForward();
    boolean movingAny();
    boolean jumping();
    boolean sneaking();
    boolean usingItem();
    boolean breakingBlock();
    float yaw();
    float fallDistance();
    boolean inWater();
    /** Pretend-on-ground flag sent to the server (used by NoFall). */
    void sendOnGround(boolean onGround);
    /** Attack cooldown progress 0..1 for the held item. */
    float attackCooldown();
    void message(String text);
    /** Force the forward key on/off (AutoWalk). Pass false to hand control back to the player. */
    void setForwardInput(boolean on);
    /** Food level 0-20. */
    int hunger();
    /** Hold/release the use-item key (eating). */
    void setUseKey(boolean down);
    /** Total count of the item kind across the inventory and offhand. */
    int countItem(ItemKind kind);

    // =====================================================================================================
    // Added in the 2026-11-13 v4 update. Every method below has a conservative default so older fakes keep
    // compiling, but the Minecraft adapters (McGame) implement all of them for real.
    // =====================================================================================================
    default float pitch() { return 0f; }
    /** Set the local player's view angles (degrees). */
    default void setRotation(float yaw, float pitch) {}
    default void setJumpInput(boolean on) {}
    default void setSneakInput(boolean on) {}
    /** A single right-click with the main hand (use item). */
    default void useItem() {}
    /** Entity id under the crosshair, or -1. */
    default int crosshairEntity() { return -1; }
    default boolean horizontalCollision() { return false; }
    default boolean onClimbable() { return false; }
    default boolean gliding() { return false; }
    /** Start/continue breaking the block (survival) or break it instantly (creative). */
    default boolean breakBlock(BlockPos p) { return false; }
    /** Right-click the block with the current hand item. */
    default boolean interactBlock(BlockPos p) { return false; }
    default boolean isLiquid(int x, int y, int z) { return false; }
    default int lightLevel(int x, int y, int z) { return 15; }
    /** Charge level 0-4 of a respawn anchor, or -1 if the block is not an anchor. */
    default int anchorCharges(BlockPos p) { return -1; }
    /** Block the player is looking at, or null. */
    default BlockPos targetBlock() { return null; }
    /** Hotbar slot with the fastest tool for the block, or -1 if the current slot is already best / nothing better. */
    default int bestToolSlotFor(BlockPos p) { return -1; }
    /** Client-side only night-vision look (no packets). Implementations must not remove a real, server-given effect. */
    default void setNightVision(boolean on) {}
    /** Registry id of the item in a player-inventory slot (0-8 hotbar, 9-35 main), "" if empty. */
    default String itemId(int invSlot) { return ""; }
    /** False for unbreakable blocks (bedrock, barriers, ...). */
    default boolean isBreakable(int x, int y, int z) { return true; }
    default int fov() { return 70; }
    default void setFov(int fov) {}
    default float stepHeight() { return 0.6f; }
    default void setStepHeight(float h) {}
    default boolean raining() { return false; }
    default void sendChat(String text) {}
    /** True when a fishing bobber is in the water and has just been pulled under (a bite). */
    default boolean fishBobberDipping() { return false; }
    default boolean fishBobberOut() { return false; }
    /** Lowest durability fraction (0..1) among worn armor; 1 if nothing is damaged / no armor. */
    default float armorDurability() { return 1f; }
    /** Stack size in a player-inventory slot (0-8 hotbar, 9-35 main). */
    default int stackCount(int invSlot) { return 0; }
    default ItemKind kindAt(int invSlot) { return ItemKind.NONE; }
    /** Move items from a main-inventory slot onto the stack in the given hotbar slot. */
    default void mergeIntoHotbar(int mainSlot, int hotbarSlot) {}
    /** Armor index 0=feet 1=legs 2=chest 3=head. Returns an inventory slot holding strictly better armor, or -1. */
    default int betterArmorSlot(int armorIdx) { return -1; }
    default void equipArmor(int invSlot, int armorIdx) {}
    /** What is worn in the chest slot (CHESTPLATE, ELYTRA, NONE or OTHER). */
    default ItemKind chest() { return ItemKind.NONE; }
    default void swapWithChest(int invSlot) {}

    // ---- v5 additions (safe defaults; real implementations live in the Minecraft adapters) ----
    /** True while the given GLFW key code is physically held (keyboard keys only). */
    default boolean keyDown(int glfwKey) { return false; }
    /** True while a screen (inventory, chat, menu...) is open, so keybinds must not fire. */
    default boolean screenOpen() { return false; }
    /** Whether the living entity with this id is currently blocking with a shield. */
    default boolean isBlocking(int entityId) { return false; }
    /** Registry id of the block at the position ("minecraft:stone"), "" for air or unloaded chunks. Must not allocate per call. */
    default String blockId(int x, int y, int z) { return ""; }
    default int fps() { return 0; }
    /** Latency in ms, or -1 if unknown (singleplayer). */
    default int ping() { return -1; }

    // ---- v6 additions (safe defaults; real implementations live in the Minecraft adapters) ----
    /** Ticks of "just got hurt" remaining on the local player (0 = not recently hurt). */
    default int hurtTime() { return 0; }
    /** Names currently shown in the server's player list (tab list). Must not return null. */
    default java.util.List<String> onlinePlayerNames() { return java.util.List.of(); }
    /** Sideways input: -1 (left) .. 1 (right). Forward input is {@link #movingForward()}. */
    default float sidewaysInput() { return 0f; }
    /** Active status effects of the local player as "Name M:SS" strings for the HUD. Must not return null. */
    default java.util.List<String> effectTimers() { return java.util.List.of(); }
    /** Address of the connected server, or "" in singleplayer / when unknown. */
    default String serverAddress() { return ""; }

    // ---- v7 additions (safe defaults; real implementations live in the Minecraft adapters) ----
    default boolean riding() { return false; }
    default boolean vehicleIsBoat() { return false; }
    default Vec3 vehicleVelocity() { return Vec3.ZERO; }
    default void setVehicleVelocity(Vec3 v) {}
    /** True while a container/inventory screen (not chat, sign or a menu with text boxes) is open. */
    default boolean inventoryScreenOpen() { return false; }
    /** Inventory slot (0-8 hotbar, 9-35 main) under the mouse in an open inventory screen, or -1. */
    default int hoveredSlot() { return -1; }
    /** Right-click an entity with the main hand. */
    default boolean interactEntity(int entityId) { return false; }
    /** Loaded block entities (chests, spawners, ...). Must not return null. */
    default java.util.List<BlockEntry> blockEntities() { return java.util.List.of(); }
    default int itemUseCooldown() { return 0; }
    default void setItemUseCooldown(int ticks) {}
    default int breakCooldown() { return 0; }
    default void setBreakCooldown(int ticks) {}
    default float breakProgress() { return 0f; }
    default void setBreakProgress(float p) {}
    /** True while the "disconnected" / connection-lost screen is showing. */
    default boolean disconnectScreenShown() { return false; }
    /** Text of the last disconnect reason, "" if unknown. */
    default String disconnectReason() { return ""; }
    /** Reconnect to the last server. Must do nothing if a connection attempt is already running. */
    default void reconnect() {}
    /** Milliseconds since the last packet arrived from the server, or 0 when unknown. */
    default long msSincePacket() { return 0; }
}
