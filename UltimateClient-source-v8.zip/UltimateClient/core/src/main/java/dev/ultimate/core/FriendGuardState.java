package dev.ultimate.core;

/** Read by the attack mixin: when active, attacks on friends are cancelled. */
public final class FriendGuardState {
    private FriendGuardState() {}
    private static volatile FriendManager friends; private static volatile boolean active, sneakOverride;
    public static void set(FriendManager f, boolean on, boolean sneakOverrides) { friends = f; active = on && f != null; sneakOverride = sneakOverrides; }
    /** @param sneaking whether you are sneaking; with the sneak override on, sneaking lets the hit through. */
    public static boolean shouldBlock(String playerName, boolean sneaking) { FriendManager f = friends; return active && f != null && playerName != null && f.isFriend(playerName) && !(sneakOverride && sneaking); }
}
