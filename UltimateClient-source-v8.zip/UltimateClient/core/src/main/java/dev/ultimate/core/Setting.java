package dev.ultimate.core;

import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** A typed, validated, JSON-persistable module setting. Invalid values are rejected, never stored. */
public abstract class Setting<T> {
    public final String id;
    public final String description;
    private T def;
    private T value;
    private BooleanSupplier visible = () -> true;
    private Consumer<T> onChange;

    protected Setting(String id, String description) { this.id = id; this.description = description; }

    /** Subclasses call this at the end of their constructor, once their own fields are set. */
    protected final void init(T defaultValue) {
        T d = defaultValue == null ? null : sanitize(defaultValue);
        if (d == null) throw new IllegalArgumentException("invalid default for setting " + id);
        this.def = d; this.value = d;
    }

    public T get() { return value; }
    public T defaultValue() { return def; }

    /** @return true if the value was accepted. */
    public boolean set(T v) {
        T n = v == null ? null : sanitize(v);
        if (n == null) return false;
        value = n;
        if (onChange != null) onChange.accept(n);
        return true;
    }

    public void reset() { set(def); }
    public Setting<T> visibleWhen(BooleanSupplier s) { this.visible = s; return this; }
    public boolean isVisible() { return visible.getAsBoolean(); }
    public Setting<T> onChange(Consumer<T> c) { this.onChange = c; return this; }

    /** Returns the cleaned value, or null if invalid. */
    protected abstract T sanitize(T v);
    public abstract Object toJson();
    /** @return true if the JSON value was valid and applied. */
    public abstract boolean fromJson(Object o);

    public static final class Bool extends Setting<Boolean> {
        public Bool(String id, String desc, boolean def) { super(id, desc); init(def); }
        @Override protected Boolean sanitize(Boolean v) { return v; }
        @Override public Object toJson() { return get(); }
        @Override public boolean fromJson(Object o) { return o instanceof Boolean b && set(b); }
    }

    public static final class Num extends Setting<Double> {
        public final double min, max, step; public final boolean integer;
        private Num(String id, String desc, double def, double min, double max, double step, boolean integer) {
            super(id, desc);
            if (!(min <= max)) throw new IllegalArgumentException("min > max for " + id);
            if (!(def >= min && def <= max)) throw new IllegalArgumentException("default out of range for " + id);
            this.min = min; this.max = max; this.step = step; this.integer = integer;
            init(def);
        }
        public static Num dbl(String id, String desc, double def, double min, double max, double step) { return new Num(id, desc, def, min, max, step, false); }
        public static Num intg(String id, String desc, int def, int min, int max) { return new Num(id, desc, def, min, max, 1, true); }
        public int asInt() { return (int) Math.round(get()); }
        public float asFloat() { return get().floatValue(); }
        @Override protected Double sanitize(Double v) {
            if (v.isNaN() || v.isInfinite()) return null;
            double c = Math.max(min, Math.min(max, v));
            return integer ? (double) Math.round(c) : c;
        }
        @Override public Object toJson() { return get(); }
        @Override public boolean fromJson(Object o) { return o instanceof Number n && set(n.doubleValue()); }
    }

    public static final class Mode extends Setting<String> {
        public final List<String> modes;
        public Mode(String id, String desc, String def, String... modes) {
            super(id, desc);
            this.modes = List.of(modes);
            init(def);
        }
        @Override protected String sanitize(String v) { return modes.contains(v) ? v : null; }
        @Override public Object toJson() { return get(); }
        @Override public boolean fromJson(Object o) { return o instanceof String s && set(s); }
    }

    /** ARGB color. */
    public static final class Color extends Setting<Integer> {
        public Color(String id, String desc, int argb) { super(id, desc); init(argb); }
        @Override protected Integer sanitize(Integer v) { return v; }
        @Override public Object toJson() { return (double) (get() & 0xFFFFFFFFL); }
        @Override public boolean fromJson(Object o) {
            return o instanceof Number n && n.doubleValue() >= 0 && n.doubleValue() <= 0xFFFFFFFFL && set((int) n.longValue());
        }
    }

    /** Free-form string (used for chat macros, names, etc.). Max length enforced. */
    public static final class Str extends Setting<String> {
        public final int maxLen;
        public Str(String id, String desc, String def, int maxLen) {
            super(id, desc);
            this.maxLen = Math.max(1, maxLen);
            init(def == null ? "" : def);
        }
        @Override protected String sanitize(String v) {
            if (v == null) return null;
            String t = v.length() > maxLen ? v.substring(0, maxLen) : v;
            return t;
        }
        @Override public Object toJson() { return get(); }
        @Override public boolean fromJson(Object o) { return o instanceof String s && set(s); }
    }

    /** Key code storage. -1 means unbound. Values are GLFW/Minecraft key codes. */
    public static final class Key extends Setting<Integer> {
        public Key(String id, String desc, int def) { super(id, desc); init(def < 0 ? -1 : def); }
        @Override protected Integer sanitize(Integer v) { return v == null || v < 0 ? -1 : v; }
        @Override public Object toJson() { return (double) get(); }
        @Override public boolean fromJson(Object o) { return o instanceof Number n && set(n.intValue()); }
        public boolean isBound() { return get() >= 0; }
    }
}
