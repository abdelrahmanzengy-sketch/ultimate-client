package dev.ultimate.core;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** JSON profiles: per-module enabled/keybind/settings, favorites, recent, GUI layout. Atomic writes, tolerant loads. */
public final class ConfigManager {
    public static final int SCHEMA = 1;
    private final Path dir;
    private final ModuleManager mm;
    private String active = "default";

    public ConfigManager(Path dir, ModuleManager mm) { this.dir = dir; this.mm = mm; }

    public static boolean validProfileName(String n) { return n != null && n.matches("[A-Za-z0-9_-]{1,32}"); }
    public String activeProfile() { return active; }
    private Path file(String profile) { return dir.resolve(profile + ".json"); }

    public void save(String profile) throws IOException {
        if (!validProfileName(profile)) throw new IllegalArgumentException("invalid profile name");
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("schema", (double) SCHEMA);
        Map<String, Object> mods = new LinkedHashMap<>();
        for (Module m : mm.all()) {
            Map<String, Object> o = new LinkedHashMap<>();
            o.put("enabled", m.isEnabled());
            o.put("keybind", (double) m.keybind());
            Map<String, Object> st = new LinkedHashMap<>();
            for (Setting<?> s : m.settings()) st.put(s.id, s.toJson());
            o.put("settings", st);
            mods.put(m.id, o);
        }
        root.put("modules", mods);
        root.put("favorites", new ArrayList<Object>(mm.favorites()));
        root.put("recent", new ArrayList<Object>(mm.recent()));
        root.put("layout", mm.layout);
        Files.createDirectories(dir);
        Path tmp = Files.createTempFile(dir, "save-", ".tmp");
        try {
            Files.writeString(tmp, Json.write(root), StandardCharsets.UTF_8);
            try { Files.move(tmp, file(profile), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, file(profile), StandardCopyOption.REPLACE_EXISTING); }
        } finally { Files.deleteIfExists(tmp); }
        active = profile;
    }

    /**
     * Loads a profile. A corrupt file leaves current state untouched and returns a message;
     * unknown modules/settings and invalid values are skipped individually.
     * @return null on success, otherwise a human-readable problem description.
     */
    public String load(String profile) {
        if (!validProfileName(profile)) return "Invalid profile name";
        Path f = file(profile);
        if (!Files.isRegularFile(f)) return "Profile '" + profile + "' does not exist";
        Map<String, Object> root;
        try {
            Object parsed = Json.parse(Files.readString(f, StandardCharsets.UTF_8));
            if (!(parsed instanceof Map<?, ?> m0)) return "Profile is not a JSON object";
            @SuppressWarnings("unchecked") Map<String, Object> m = (Map<String, Object>) m0;
            root = m;
        } catch (IOException | IllegalArgumentException e) { return "Could not read profile: " + e.getMessage(); }

        int schema = root.get("schema") instanceof Number n ? n.intValue() : 0;
        if (schema > SCHEMA) return "Profile was made by a newer client version (schema " + schema + ")";
        migrate(root, schema);

        int skipped = 0;
        if (root.get("modules") instanceof Map<?, ?> mods) {
            for (Map.Entry<?, ?> e : mods.entrySet()) {
                Module m = mm.get(String.valueOf(e.getKey()));
                if (m == null || !(e.getValue() instanceof Map<?, ?> o)) { skipped++; continue; }
                if (o.get("settings") instanceof Map<?, ?> st) {
                    for (Map.Entry<?, ?> se : st.entrySet()) {
                        Setting<?> s = m.setting(String.valueOf(se.getKey()));
                        if (s == null || !s.fromJson(se.getValue())) skipped++;
                    }
                }
                if (o.get("keybind") instanceof Number k) m.setKeybind(k.intValue());
                if (o.get("enabled") instanceof Boolean b) m.setEnabled(b);
            }
        }
        if (root.get("favorites") instanceof List<?> fav) {
            for (String id : new ArrayList<>(mm.favorites())) mm.setFavorite(id, false);
            for (Object o : fav) if (o instanceof String s) mm.setFavorite(s, true);
        }
        if (root.get("recent") instanceof List<?> rec) {
            List<String> ids = new ArrayList<>(); for (Object o : rec) if (o instanceof String s) ids.add(s);
            mm.restoreRecent(ids);
        }
        if (root.get("layout") instanceof Map<?, ?> lay) {
            mm.layout.clear();
            for (Map.Entry<?, ?> e : lay.entrySet()) mm.layout.put(String.valueOf(e.getKey()), e.getValue());
        }
        active = profile;
        return null;
    }

    /** Upgrades older schemas in place. Schema 0 (no version field) stored settings under "config". */
    private void migrate(Map<String, Object> root, int from) {
        if (from < 1 && root.containsKey("config") && !root.containsKey("modules")) root.put("modules", root.remove("config"));
    }

    public List<String> profiles() {
        List<String> out = new ArrayList<>();
        if (!Files.isDirectory(dir)) return out;
        try (var st = Files.list(dir)) {
            st.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json"))
              .map(n -> n.substring(0, n.length() - 5)).filter(ConfigManager::validProfileName).sorted().forEach(out::add);
        } catch (IOException ignored) {}
        return out;
    }

    public boolean delete(String profile) throws IOException { return validProfileName(profile) && Files.deleteIfExists(file(profile)); }

    public void resetAll() { for (Module m : mm.all()) { m.resetSettings(); m.setKeybind(-1); } }
}
