package dev.ultimate.game;

/** A block (usually a block entity such as a chest) with its registry id, e.g. "minecraft:chest". */
public record BlockEntry(BlockPos pos, String id) {}
