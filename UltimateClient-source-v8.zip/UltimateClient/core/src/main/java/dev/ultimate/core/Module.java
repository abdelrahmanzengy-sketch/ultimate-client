package dev.ultimate.core;

import java.util.*;
import java.util.function.Consumer;

/**
 * Base class for every module. Lifecycle hooks are optional overrides; any exception thrown by a hook
 * disables only that module, releases its event listeners and records {@link #lastError()}.
 */
public abstract class Module {
    public final String id, name, description;
    public final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private boolean enabled;
    private int keybind = -1; // -1 = unbound
    private String lastError;
    private ModuleManager manager;

    protected Module(String id, String name, String description, Category category) {
        if (!id.matches("[a-z0-9][a-z0-9-]{0,47}")) throw new IllegalArgumentException("bad module id: " + id);
        this.id = id; this.name = name; this.description = description; this.category = category;
    }

    // ---- hooks ----
    protected void onEnable() {}
    protected void onDisable() {}
    protected void onTick() {}
    /** Called when the player leaves a world/server; default keeps the module enabled. */
    protected void onWorldLeave() {}
    /** Called every frame while enabled: describe what to draw in world coordinates. Keep it allocation-light. */
    protected void onRender(RenderQueue q) {}

    // ---- settings ----
    protected final <S extends Setting<?>> S add(S s) {
        for (Setting<?> o : settings) if (o.id.equals(s.id)) throw new IllegalArgumentException("duplicate setting " + s.id + " in " + id);
        settings.add(s); return s;
    }
    public final List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }
    public final Setting<?> setting(String sid) { for (Setting<?> s : settings) if (s.id.equals(sid)) return s; return null; }
    public final void resetSettings() { for (Setting<?> s : settings) s.reset(); }

    // ---- events ----
    protected final <E> void listen(Class<E> type, Consumer<E> fn) {
        if (manager == null) throw new IllegalStateException(id + " is not registered");
        manager.bus().subscribe(this, type, fn);
    }

    // ---- state ----
    public final boolean isEnabled() { return enabled; }
    public final int keybind() { return keybind; }
    public final void setKeybind(int key) { this.keybind = key < 0 ? -1 : key; }
    public final String lastError() { return lastError; }
    final void attach(ModuleManager m) { this.manager = m; }

    public final boolean setEnabled(boolean on) {
        if (on == enabled) return true;
        if (on) {
            if (manager == null) return false;
            enabled = true; lastError = null;
            try { onEnable(); }
            catch (Throwable t) { fail("enable", t); return false; }
            manager.noteEnabled(this);
            return true;
        }
        enabled = false;
        release();
        return true;
    }

    public final boolean toggle() { return setEnabled(!enabled) ? enabled : false; }

    final void tick() {
        if (!enabled) return;
        try { onTick(); } catch (Throwable t) { fail("tick", t); }
    }

    final void render(RenderQueue q) {
        if (!enabled) return;
        try { onRender(q); } catch (Throwable t) { fail("render", t); }
    }

    final void worldLeave() {
        if (!enabled) return;
        try { onWorldLeave(); } catch (Throwable t) { fail("world-leave", t); }
    }

    private void fail(String phase, Throwable t) {
        lastError = phase + ": " + t;
        enabled = false;
        if (manager != null) manager.log("Module '" + name + "' disabled after error in " + phase + ": " + t);
        release();
    }

    private void release() {
        if (manager != null) manager.bus().unsubscribeAll(this);
        try { onDisable(); }
        catch (Throwable t) { lastError = "disable: " + t; if (manager != null) manager.log("Module '" + name + "' failed to disable cleanly: " + t); }
    }
}
