package dev.ultimate.mixin;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Exposes block-breaking delay and progress to Break Delay / Speed Mine. */
@Mixin(ClientPlayerInteractionManager.class)
public interface InteractionManagerAccessor {
    @Accessor("blockBreakingCooldown") int ultimateclient$getCooldown();
    @Accessor("blockBreakingCooldown") void ultimateclient$setCooldown(int v);
    @Accessor("currentBreakingProgress") float ultimateclient$getProgress();
    @Accessor("currentBreakingProgress") void ultimateclient$setProgress(float v);
}
