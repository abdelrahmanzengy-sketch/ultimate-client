package dev.ultimate;

import dev.ultimate.core.ModuleManager;
import dev.ultimate.game.Game;
import dev.ultimate.hud.Hud;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;

/**
 * Draws the HUD model. Text is rebuilt only every few ticks (not every frame) to keep garbage and CPU low on phones.
 * UNCOMPILED. Per-element scale from the model is not applied yet (drawing is at the default size).
 */
final class HudRenderer {
    private record Draw(Hud.Element e, List<String> lines) {}
    private final Hud hud; private final ModuleManager mm; private final Game game;
    private volatile List<Draw> snapshot = List.of(); private int counter;

    HudRenderer(Hud hud, ModuleManager mm, Game game) { this.hud = hud; this.mm = mm; this.game = game; }

    void tick() {
        if (++counter % 4 != 0) return;
        List<Draw> next = new ArrayList<>();
        if (game.inWorld()) {
            Hud.Ctx c = new Hud.Ctx(game, mm);
            for (Hud.Element e : hud.elements()) { List<String> l = e.lines(c); if (!l.isEmpty()) next.add(new Draw(e, l)); }
        }
        snapshot = next;
    }

    void render(DrawContext ctx, RenderTickCounter tick) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden) return;
        List<Draw> draws = snapshot; if (draws.isEmpty()) return;
        TextRenderer tr = mc.textRenderer; int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        for (Draw d : draws) {
            int y = (int) (d.e().y * h);
            for (String s : d.lines()) {
                int x = (int) (d.e().x * w); if (d.e().x > 0.5) x -= tr.getWidth(s);
                ctx.drawTextWithShadow(tr, s, Math.max(0, Math.min(w - 1, x)), Math.max(0, Math.min(h - tr.fontHeight, y)), 0xFFFFFFFF);
                y += tr.fontHeight + 1;
            }
        }
    }
}
