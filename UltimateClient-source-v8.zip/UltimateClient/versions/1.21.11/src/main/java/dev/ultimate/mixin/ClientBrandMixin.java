package dev.ultimate.mixin;

import dev.ultimate.core.BrandState;
import net.minecraft.client.ClientBrandRetriever;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Lets the ClientBrand module replace the brand string the game sends at login. Does nothing while the module is off. */
@Mixin(ClientBrandRetriever.class)
public abstract class ClientBrandMixin {
    @Inject(method = "getClientModName", at = @At("HEAD"), cancellable = true, require = 0)
    private static void ultimateclient$brand(CallbackInfoReturnable<String> cir) {
        String b = BrandState.get();
        if (b != null) cir.setReturnValue(b);
    }
}
