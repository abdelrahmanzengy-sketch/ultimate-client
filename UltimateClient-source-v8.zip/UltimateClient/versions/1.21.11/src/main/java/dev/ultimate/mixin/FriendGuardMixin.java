package dev.ultimate.mixin;

import dev.ultimate.core.FriendGuardState;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Friend Guard: cancels your own attack on a friend. Does nothing while the module is off. */
@Mixin(ClientPlayerInteractionManager.class)
public abstract class FriendGuardMixin {
    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true, require = 0)
    private void ultimateclient$guard(PlayerEntity player, Entity target, CallbackInfo ci) {
        if (target instanceof PlayerEntity t && FriendGuardState.shouldBlock(t.getName().getString(), player.isSneaking())) ci.cancel();
    }
}
