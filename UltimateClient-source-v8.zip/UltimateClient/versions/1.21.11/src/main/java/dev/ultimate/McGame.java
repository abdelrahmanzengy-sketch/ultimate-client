package dev.ultimate;

import dev.ultimate.game.*;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import java.util.ArrayList;
import java.util.List;

/**
 * Game implementation for Minecraft 1.21.11 (Yarn names).
 *
 * !!! NOT COMPILED OR RUN !!!  This file was written without access to the Minecraft/Yarn jars (the build sandbox
 * blocked maven.fabricmc.net), so some method names may differ in 1.21.11 and need fixing on the first real build.
 * Known simplifications: blast-protection EPF of other players is reported as 0 (only armor, toughness and
 * resistance are read), and collision is treated as full cubes via isSolidBlock.
 */
public final class McGame implements Game {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    private ClientPlayerEntity p() { return mc.player; }

    private static net.minecraft.util.math.BlockPos bp(int x, int y, int z) { return new net.minecraft.util.math.BlockPos(x, y, z); }
    private static net.minecraft.util.math.BlockPos bp(BlockPos b) { return bp(b.x(), b.y(), b.z()); }
    private static Vec3 v(net.minecraft.util.math.Vec3d d) { return new Vec3(d.x, d.y, d.z); }

    private EntityInfo info(Entity e) {
        EntityInfo.Kind kind = e instanceof EndCrystalEntity ? EntityInfo.Kind.CRYSTAL
                : e instanceof PlayerEntity ? EntityInfo.Kind.PLAYER
                : e instanceof net.minecraft.entity.ItemEntity ? EntityInfo.Kind.ITEM
                : e instanceof HostileEntity ? EntityInfo.Kind.HOSTILE
                : e instanceof PassiveEntity ? EntityInfo.Kind.PASSIVE : EntityInfo.Kind.OTHER;
        float hp = 1, abs = 0; double armor = 0, tough = 0; int res = -1;
        if (e instanceof LivingEntity le) {
            hp = le.getHealth(); abs = le.getAbsorptionAmount(); armor = le.getArmor();
            tough = le.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS);
            StatusEffectInstance r = le.getStatusEffect(StatusEffects.RESISTANCE);
            if (r != null) res = r.getAmplifier();
        }
        return new EntityInfo(e.getId(), kind, e.getName().getString(), v(e.getPos()), v(e.getVelocity()),
                e.getWidth(), e.getHeight(), hp, abs, armor, tough, 0, res, e.isOnGround());
    }

    @Override public boolean inWorld() { return mc.player != null && mc.world != null && mc.getNetworkHandler() != null; }
    @Override public boolean selfDead() { return p().isDead() || p().getHealth() <= 0; }
    @Override public EntityInfo self() { return info(p()); }
    @Override public List<EntityInfo> entities() {
        List<EntityInfo> out = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) if (e != p() && !e.isRemoved()) out.add(info(e));
        return out;
    }
    @Override public long tick() { return mc.world.getTime(); }
    @Override public int difficulty() { return mc.world.getDifficulty().getId(); }

    @Override public boolean isLoaded(int x, int z) { return mc.world.getChunkManager().isChunkLoaded(x >> 4, z >> 4); }
    @Override public boolean isSolid(int x, int y, int z) {
        if (!isLoaded(x, z)) return false;
        net.minecraft.util.math.BlockPos pos = bp(x, y, z);
        return mc.world.getBlockState(pos).isSolidBlock(mc.world, pos);
    }
    @Override public boolean isAir(int x, int y, int z) { return isLoaded(x, z) && mc.world.getBlockState(bp(x, y, z)).isAir(); }
    @Override public boolean isCrystalBase(int x, int y, int z) {
        if (!isLoaded(x, z)) return false;
        BlockState s = mc.world.getBlockState(bp(x, y, z));
        return s.isOf(Blocks.OBSIDIAN) || s.isOf(Blocks.BEDROCK);
    }
    @Override public boolean canPlaceCrystal(BlockPos b) {
        if (!isAir(b.x(), b.y() + 1, b.z()) || !isAir(b.x(), b.y() + 2, b.z())) return false;
        return mc.world.getOtherEntities(null, new Box(b.x(), b.y() + 1, b.z(), b.x() + 1, b.y() + 3, b.z() + 1)).isEmpty();
    }

    @Override public int selectedSlot() { return p().getInventory().getSelectedSlot(); }
    @Override public void selectSlot(int s) { p().getInventory().setSelectedSlot(s); }
    private static boolean matches(ItemStack s, ItemKind k) {
        if (s.isEmpty()) return false;
        return switch (k) {
            case TOTEM -> s.isOf(Items.TOTEM_OF_UNDYING); case END_CRYSTAL -> s.isOf(Items.END_CRYSTAL);
            case OBSIDIAN -> s.isOf(Items.OBSIDIAN); case GOLDEN_APPLE -> s.isOf(Items.GOLDEN_APPLE);
            case WEB -> s.isOf(Items.COBWEB);
            case SWORD -> s.isIn(net.minecraft.registry.tag.ItemTags.SWORDS);
            case AXE -> s.isIn(net.minecraft.registry.tag.ItemTags.AXES);
            case PICKAXE -> s.isIn(net.minecraft.registry.tag.ItemTags.PICKAXES);
            case EXP_BOTTLE -> s.isOf(Items.EXPERIENCE_BOTTLE);
            case GLOWSTONE -> s.isOf(Items.GLOWSTONE);
            case RESPAWN_ANCHOR -> s.isOf(Items.RESPAWN_ANCHOR);
            case ELYTRA -> s.isOf(Items.ELYTRA);
            case CHESTPLATE -> equipSlot(s) == net.minecraft.entity.EquipmentSlot.CHEST && !s.isOf(Items.ELYTRA);
            case FISHING_ROD -> s.isOf(Items.FISHING_ROD);
            case TORCH -> s.isOf(Items.TORCH);
            case ANVIL -> s.isOf(Items.ANVIL) || s.isOf(Items.CHIPPED_ANVIL) || s.isOf(Items.DAMAGED_ANVIL);
            case BED -> s.isIn(net.minecraft.registry.tag.ItemTags.BEDS);
            case MACE -> s.isOf(Items.MACE);
            case TRIDENT -> s.isOf(Items.TRIDENT);
            case PEARL -> s.isOf(Items.ENDER_PEARL);
            case SHEARS -> s.isOf(Items.SHEARS);
            case FILLER_BLOCK -> s.isOf(Items.COBBLESTONE) || s.isOf(Items.STONE) || s.isOf(Items.DIRT) || s.isOf(Items.NETHERRACK) || s.isOf(Items.COBBLED_DEEPSLATE);
            case FOOD -> s.getComponents().contains(net.minecraft.component.DataComponentTypes.FOOD); // verify name on build
            default -> false;
        };
    }
    private static net.minecraft.entity.EquipmentSlot equipSlot(ItemStack s) {
        net.minecraft.component.type.EquippableComponent c = s.get(net.minecraft.component.DataComponentTypes.EQUIPPABLE);
        return c == null ? null : c.slot();
    }
    private static ItemKind kind(ItemStack s) {
        if (s.isEmpty()) return ItemKind.NONE;
        if (s.isOf(Items.TOTEM_OF_UNDYING)) return ItemKind.TOTEM;
        if (s.isOf(Items.END_CRYSTAL)) return ItemKind.END_CRYSTAL;
        if (s.isOf(Items.OBSIDIAN)) return ItemKind.OBSIDIAN;
        if (s.isOf(Items.GOLDEN_APPLE)) return ItemKind.GOLDEN_APPLE;
        for (ItemKind k : new ItemKind[]{ItemKind.SWORD, ItemKind.AXE, ItemKind.PICKAXE, ItemKind.EXP_BOTTLE, ItemKind.GLOWSTONE, ItemKind.RESPAWN_ANCHOR,
                ItemKind.ELYTRA, ItemKind.CHESTPLATE, ItemKind.FISHING_ROD, ItemKind.TORCH, ItemKind.FILLER_BLOCK, ItemKind.WEB, ItemKind.ANVIL, ItemKind.BED, ItemKind.MACE, ItemKind.TRIDENT, ItemKind.PEARL, ItemKind.SHEARS})
            if (matches(s, k)) return k;
        return ItemKind.OTHER;
    }
    @Override public int hotbarSlotOf(ItemKind k) { for (int i = 0; i < 9; i++) if (matches(p().getInventory().getStack(i), k)) return i; return -1; }
    @Override public int mainInvSlotOf(ItemKind k) { for (int i = 9; i < 36; i++) if (matches(p().getInventory().getStack(i), k)) return i; return -1; }
    @Override public int countItem(ItemKind k) { int n = 0; for (int i = 0; i < 36; i++) { ItemStack st = p().getInventory().getStack(i); if (matches(st, k)) n += st.getCount(); } ItemStack o = p().getOffHandStack(); if (matches(o, k)) n += o.getCount(); return n; }
    private boolean forceForward;
    /** True if the user is physically holding the key bound to this action (keyboard keys only). */
    private boolean physical(net.minecraft.client.option.KeyBinding kb) {
        int code = net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.getBoundKeyOf(kb).getCode();
        return code >= 0 && org.lwjgl.glfw.GLFW.glfwGetKey(mc.getWindow().getHandle(), code) == org.lwjgl.glfw.GLFW.GLFW_PRESS;
    }
    @Override public void setForwardInput(boolean on) { forceForward = on; mc.options.forwardKey.setPressed(on || physical(mc.options.forwardKey)); }
    @Override public int hunger() { return p().getHungerManager().getFoodLevel(); }
    @Override public void setUseKey(boolean down) { mc.options.useKey.setPressed(down); }
    @Override public ItemKind mainHand() { return kind(p().getMainHandStack()); }
    @Override public ItemKind offhand() { return kind(p().getOffHandStack()); }
    @Override public void swapWithOffhand(int invSlot) {
        int screenSlot = invSlot < 9 ? 36 + invSlot : invSlot; // player screen handler: hotbar 36-44, main 9-35
        mc.interactionManager.clickSlot(p().playerScreenHandler.syncId, screenSlot, 40, SlotActionType.SWAP, p());
    }

    private Hand crystalHand() { return p().getOffHandStack().isOf(Items.END_CRYSTAL) && !p().getMainHandStack().isOf(Items.END_CRYSTAL) ? Hand.OFF_HAND : Hand.MAIN_HAND; }
    @Override public boolean placeCrystal(BlockPos b) {
        Hand h = crystalHand();
        if (!(h == Hand.OFF_HAND ? p().getOffHandStack() : p().getMainHandStack()).isOf(Items.END_CRYSTAL)) return false;
        BlockHitResult hit = new BlockHitResult(new net.minecraft.util.math.Vec3d(b.x() + 0.5, b.y() + 1.0, b.z() + 0.5), Direction.UP, bp(b), false);
        mc.interactionManager.interactBlock(p(), h, hit); p().swingHand(h); return true;
    }
    @Override public boolean placeBlock(BlockPos at) {
        if (!mc.world.getBlockState(bp(at)).isReplaceable()) return false;
        for (Direction d : Direction.values()) {
            net.minecraft.util.math.BlockPos n = bp(at).offset(d);
            if (!isSolid(n.getX(), n.getY(), n.getZ())) continue;
            Direction face = d.getOpposite();
            net.minecraft.util.math.Vec3d hitPos = new net.minecraft.util.math.Vec3d(n.getX() + 0.5 + face.getOffsetX() * 0.5, n.getY() + 0.5 + face.getOffsetY() * 0.5, n.getZ() + 0.5 + face.getOffsetZ() * 0.5);
            mc.interactionManager.interactBlock(p(), Hand.MAIN_HAND, new BlockHitResult(hitPos, face, n, false));
            p().swingHand(Hand.MAIN_HAND); return true;
        }
        return false;
    }
    @Override public boolean attack(int id) {
        Entity e = mc.world.getEntityById(id); if (e == null) return false;
        mc.interactionManager.attackEntity(p(), e); p().swingHand(Hand.MAIN_HAND); return true;
    }
    @Override public void lookAt(Vec3 t) {
        net.minecraft.util.math.Vec3d eye = p().getEyePos();
        double dx = t.x() - eye.x, dy = t.y() - eye.y, dz = t.z() - eye.z, h = Math.sqrt(dx * dx + dz * dz);
        p().setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0)); p().setPitch((float) -Math.toDegrees(Math.atan2(dy, h)));
    }
    @Override public void setVelocity(Vec3 vel) { p().setVelocity(vel.x(), vel.y(), vel.z()); }
    @Override public void setSprinting(boolean on) { p().setSprinting(on); }
    @Override public void respawn() { p().requestRespawn(); }

    @Override public boolean movingForward() { return mc.options.forwardKey.isPressed(); }
    @Override public boolean movingAny() { return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed() || mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed(); }
    @Override public boolean jumping() { return mc.options.jumpKey.isPressed(); }
    @Override public boolean sneaking() { return mc.options.sneakKey.isPressed(); }
    @Override public boolean usingItem() { return p().isUsingItem(); }
    @Override public boolean breakingBlock() { return mc.interactionManager.isBreakingBlock(); }
    @Override public float yaw() { return p().getYaw(); }
    @Override public float fallDistance() { return (float) p().fallDistance; }
    @Override public boolean inWater() { return p().isTouchingWater(); }
    @Override public void sendOnGround(boolean g) { p().networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(g, p().horizontalCollision)); }
    @Override public float attackCooldown() { return p().getAttackCooldownProgress(0.5f); }
    @Override public void message(String t) { p().sendMessage(Text.literal("[UC] " + t), false); }

    // =================================================================================================
    // v4 additions. Same status as the rest of this file: written from memory of the 1.21.11 Yarn API,
    // NEVER compiled or run. Expect a few renamed methods on the first real build.
    // =================================================================================================
    private static int screenSlot(int invSlot) { return invSlot < 9 ? 36 + invSlot : invSlot; }
    private void click(int screenSlot) { mc.interactionManager.clickSlot(p().playerScreenHandler.syncId, screenSlot, 0, SlotActionType.PICKUP, p()); }
    /** Swap an inventory slot with a screen slot (armor slots: 5 head, 6 chest, 7 legs, 8 feet) using three clicks so nothing is lost. */
    private void swapWithScreenSlot(int invSlot, int target) { int a = screenSlot(invSlot); click(a); click(target); click(a); }

    @Override public float pitch() { return p().getPitch(); }
    @Override public void setRotation(float yaw, float pitch) { p().setYaw(yaw); p().setPitch(pitch); }
    @Override public void setJumpInput(boolean on) { mc.options.jumpKey.setPressed(on || physical(mc.options.jumpKey)); }
    @Override public void setSneakInput(boolean on) { mc.options.sneakKey.setPressed(on || physical(mc.options.sneakKey)); }
    @Override public void useItem() { if (mc.interactionManager.interactItem(p(), Hand.MAIN_HAND).isAccepted()) p().swingHand(Hand.MAIN_HAND); }
    @Override public int crosshairEntity() { return mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult r ? r.getEntity().getId() : -1; }
    @Override public boolean horizontalCollision() { return p().horizontalCollision; }
    @Override public boolean onClimbable() { return p().isClimbing(); }
    @Override public boolean gliding() { return p().isGliding(); }
    @Override public boolean breakBlock(BlockPos b) {
        boolean ok = mc.interactionManager.updateBlockBreakingProgress(bp(b), Direction.UP);
        if (ok) p().swingHand(Hand.MAIN_HAND);
        return ok;
    }
    @Override public boolean interactBlock(BlockPos b) {
        BlockHitResult hit = new BlockHitResult(new net.minecraft.util.math.Vec3d(b.x() + 0.5, b.y() + 1.0, b.z() + 0.5), Direction.UP, bp(b), false);
        boolean ok = mc.interactionManager.interactBlock(p(), Hand.MAIN_HAND, hit).isAccepted();
        if (ok) p().swingHand(Hand.MAIN_HAND);
        return ok;
    }
    @Override public boolean isLiquid(int x, int y, int z) { return isLoaded(x, z) && !mc.world.getFluidState(bp(x, y, z)).isEmpty(); }
    /** Block light only (what decides mob spawning in caves); sky light is deliberately ignored. */
    @Override public int lightLevel(int x, int y, int z) { return isLoaded(x, z) ? mc.world.getLightLevel(net.minecraft.world.LightType.BLOCK, bp(x, y, z)) : 15; }
    @Override public int anchorCharges(BlockPos b) {
        if (!isLoaded(b.x(), b.z())) return -1;
        BlockState st = mc.world.getBlockState(bp(b));
        return st.isOf(Blocks.RESPAWN_ANCHOR) ? st.get(net.minecraft.block.RespawnAnchorBlock.CHARGES) : -1;
    }
    @Override public BlockPos targetBlock() {
        if (mc.crosshairTarget instanceof BlockHitResult r && r.getType() == net.minecraft.util.hit.HitResult.Type.BLOCK) {
            net.minecraft.util.math.BlockPos q = r.getBlockPos(); return new BlockPos(q.getX(), q.getY(), q.getZ());
        }
        return null;
    }
    @Override public int bestToolSlotFor(BlockPos b) {
        BlockState st = mc.world.getBlockState(bp(b));
        int cur = selectedSlot(), best = -1; float bestSpeed = p().getInventory().getStack(cur).getMiningSpeedMultiplier(st);
        for (int i = 0; i < 9; i++) {
            float sp = p().getInventory().getStack(i).getMiningSpeedMultiplier(st);
            if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; }
        }
        return best;
    }
    private boolean ownNightVision;
    @Override public void setNightVision(boolean on) {
        if (on) {
            StatusEffectInstance cur = p().getStatusEffect(StatusEffects.NIGHT_VISION);
            if (cur != null && !ownNightVision) return;                      // a real (server-given) effect: leave it alone
            if (cur == null || cur.getDuration() < 400) {
                p().addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1200, 0, false, false, false));
                ownNightVision = true;
            }
        } else if (ownNightVision) {
            p().removeStatusEffect(StatusEffects.NIGHT_VISION); ownNightVision = false;
        }
    }
    @Override public String itemId(int slot) { ItemStack st = p().getInventory().getStack(slot); return st.isEmpty() ? "" : net.minecraft.registry.Registries.ITEM.getId(st.getItem()).toString(); }
    @Override public boolean isBreakable(int x, int y, int z) { return isLoaded(x, z) && mc.world.getBlockState(bp(x, y, z)).getHardness(mc.world, bp(x, y, z)) >= 0; }
    @Override public int fov() { return mc.options.getFov().getValue(); }
    @Override public void setFov(int f) { mc.options.getFov().setValue(Math.max(30, Math.min(110, f))); }
    @Override public float stepHeight() { return (float) p().getAttributeValue(EntityAttributes.STEP_HEIGHT); }
    @Override public void setStepHeight(float h) { var inst = p().getAttributeInstance(EntityAttributes.STEP_HEIGHT); if (inst != null) inst.setBaseValue(h); }
    @Override public boolean raining() { return mc.world.isRaining(); }
    @Override public void sendChat(String text) {
        if (text.startsWith("/")) p().networkHandler.sendChatCommand(text.substring(1)); else p().networkHandler.sendChatMessage(text);
    }
    @Override public boolean fishBobberOut() { return p().fishHook != null; }
    /** Heuristic: the bobber is in water and has been yanked downward (vanilla bite motion). Verify in game. */
    @Override public boolean fishBobberDipping() { var h = p().fishHook; return h != null && h.isTouchingWater() && h.getVelocity().y < -0.05; }
    @Override public float armorDurability() {
        float worst = 1f;
        for (net.minecraft.entity.EquipmentSlot es : new net.minecraft.entity.EquipmentSlot[]{net.minecraft.entity.EquipmentSlot.HEAD, net.minecraft.entity.EquipmentSlot.CHEST, net.minecraft.entity.EquipmentSlot.LEGS, net.minecraft.entity.EquipmentSlot.FEET}) {
            ItemStack st = p().getEquippedStack(es);
            if (!st.isEmpty() && st.isDamageable()) worst = Math.min(worst, 1f - (float) st.getDamage() / st.getMaxDamage());
        }
        return worst;
    }
    @Override public int stackCount(int slot) { return p().getInventory().getStack(slot).getCount(); }
    @Override public ItemKind kindAt(int slot) { return kind(p().getInventory().getStack(slot)); }
    /** Pick up the main-inventory stack, drop it on the hotbar stack (merges), put any remainder back. */
    @Override public void mergeIntoHotbar(int mainSlot, int hotbarSlot) { click(mainSlot); click(36 + hotbarSlot); click(mainSlot); }

    private static final net.minecraft.entity.EquipmentSlot[] ARMOR_BY_IDX = {net.minecraft.entity.EquipmentSlot.FEET, net.minecraft.entity.EquipmentSlot.LEGS, net.minecraft.entity.EquipmentSlot.CHEST, net.minecraft.entity.EquipmentSlot.HEAD};
    /** Armor + toughness from the item's attribute modifiers (enchantments are NOT scored). */
    private static double armorScore(ItemStack st) {
        net.minecraft.component.type.AttributeModifiersComponent mods = st.getOrDefault(net.minecraft.component.DataComponentTypes.ATTRIBUTE_MODIFIERS, net.minecraft.component.type.AttributeModifiersComponent.DEFAULT);
        double score = 0;
        for (var e : mods.modifiers()) if (e.attribute().equals(EntityAttributes.ARMOR) || e.attribute().equals(EntityAttributes.ARMOR_TOUGHNESS)) score += e.modifier().value();
        return score;
    }
    @Override public int betterArmorSlot(int idx) {
        net.minecraft.entity.EquipmentSlot es = ARMOR_BY_IDX[idx];
        double cur = armorScore(p().getEquippedStack(es)); int best = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack st = p().getInventory().getStack(i);
            if (st.isEmpty() || equipSlot(st) != es || st.isOf(Items.ELYTRA)) continue;
            double sc = armorScore(st);
            if (sc > cur + 0.01) { cur = sc; best = i; }
        }
        return best;
    }
    @Override public void equipArmor(int invSlot, int idx) { swapWithScreenSlot(invSlot, 8 - idx); }   // feet 8, legs 7, chest 6, head 5
    @Override public ItemKind chest() {
        ItemStack st = p().getEquippedStack(net.minecraft.entity.EquipmentSlot.CHEST);
        return st.isEmpty() ? ItemKind.NONE : st.isOf(Items.ELYTRA) ? ItemKind.ELYTRA : matches(st, ItemKind.CHESTPLATE) ? ItemKind.CHESTPLATE : ItemKind.OTHER;
    }
    @Override public void swapWithChest(int invSlot) { swapWithScreenSlot(invSlot, 6); }

    // ---- v5 additions (also uncompiled; see the note at the top of this file) ----
    private final java.util.IdentityHashMap<net.minecraft.block.Block, String> blockIdCache = new java.util.IdentityHashMap<>();
    @Override public boolean keyDown(int code) { return code >= 0 && org.lwjgl.glfw.GLFW.glfwGetKey(mc.getWindow().getHandle(), code) == org.lwjgl.glfw.GLFW.GLFW_PRESS; }
    @Override public boolean screenOpen() { return mc.currentScreen != null; }
    @Override public boolean isBlocking(int id) { return mc.world != null && mc.world.getEntityById(id) instanceof LivingEntity le && le.isBlocking(); }
    /** Cached per Block so scanning modules do not allocate a String per position. */
    @Override public String blockId(int x, int y, int z) {
        if (!isLoaded(x, z)) return "";
        BlockState st = mc.world.getBlockState(bp(x, y, z));
        if (st.isAir()) return "";
        return blockIdCache.computeIfAbsent(st.getBlock(), b -> net.minecraft.registry.Registries.BLOCK.getId(b).toString());
    }
    @Override public int fps() { return mc.getCurrentFps(); }
    @Override public int ping() {
        if (mc.getNetworkHandler() == null || p() == null) return -1;
        var e = mc.getNetworkHandler().getPlayerListEntry(p().getUuid());
        return e == null ? -1 : e.getLatency();
    }

    // ---- v6 additions (UNVERIFIED names, see VERIFY marks) ----
    @Override public int hurtTime() { return p() == null ? 0 : p().hurtTime; } // VERIFY: field may be getter-only
    @Override public java.util.List<String> onlinePlayerNames() {
        java.util.List<String> out = new java.util.ArrayList<>();
        if (mc.getNetworkHandler() == null) return out;
        for (var e : mc.getNetworkHandler().getPlayerList()) out.add(e.getProfile().name()); // VERIFY: GameProfile.name() vs getName()
        return out;
    }
    @Override public float sidewaysInput() { // VERIFY: Input API changed in 1.21.x (PlayerInput record)
        float l = mc.options.leftKey.isPressed() ? 1f : 0f, r = mc.options.rightKey.isPressed() ? 1f : 0f; return r - l;
    }
    @Override public java.util.List<String> effectTimers() {
        java.util.List<String> out = new java.util.ArrayList<>();
        if (p() == null) return out;
        for (StatusEffectInstance e : p().getStatusEffects()) {
            int sec = e.isInfinite() ? -1 : e.getDuration() / 20;
            String time = sec < 0 ? "inf" : (sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60);
            out.add(e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1) + " " + time);
        }
        return out;
    }
    @Override public String serverAddress() { var s = mc.getCurrentServerEntry(); return s == null ? "" : s.address; }

    // ---- v7 additions (UNVERIFIED names, see VERIFY marks) ----
    private net.minecraft.entity.Entity vehicle() { return p() == null ? null : p().getVehicle(); }
    @Override public boolean riding() { return vehicle() != null; }
    @Override public boolean vehicleIsBoat() { return vehicle() instanceof net.minecraft.entity.vehicle.AbstractBoatEntity; } // name confirmed in Yarn 1.21.11
    @Override public Vec3 vehicleVelocity() { var v = vehicle(); if (v == null) return Vec3.ZERO; var d = v.getVelocity(); return new Vec3(d.x, d.y, d.z); }
    @Override public void setVehicleVelocity(Vec3 v) { var e = vehicle(); if (e != null) e.setVelocity(v.x(), v.y(), v.z()); }
    @Override public boolean inventoryScreenOpen() { return mc.currentScreen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen<?>; }
    @Override public int hoveredSlot() {
        if (!(mc.currentScreen instanceof net.minecraft.client.gui.screen.ingame.HandledScreen<?> hs) || p() == null) return -1;
        var slot = ((dev.ultimate.mixin.HandledScreenAccessor) hs).ultimateclient$focusedSlot(); // field confirmed in Yarn 1.21.11
        return slot != null && slot.inventory == p().getInventory() ? slot.getIndex() : -1;
    }
    @Override public boolean interactEntity(int id) {
        Entity e = mc.world == null ? null : mc.world.getEntityById(id); if (e == null || mc.interactionManager == null) return false;
        boolean ok = mc.interactionManager.interactEntity(p(), e, Hand.MAIN_HAND).isAccepted(); if (ok) p().swingHand(Hand.MAIN_HAND); return ok;
    }
    @Override public java.util.List<BlockEntry> blockEntities() {
        java.util.List<BlockEntry> out = new java.util.ArrayList<>(); if (mc.world == null || p() == null) return out;
        int r = mc.options.getViewDistance().getValue(), cx = p().getChunkPos().x, cz = p().getChunkPos().z;
        for (int x = cx - r; x <= cx + r; x++) for (int z = cz - r; z <= cz + r; z++) {
            var ch = mc.world.getChunkManager().getWorldChunk(x, z); if (ch == null) continue; // ChunkManager.getWorldChunk(int,int) confirmed in Yarn 1.21.11
            for (var be : ch.getBlockEntities().values()) out.add(new BlockEntry(new BlockPos(be.getPos().getX(), be.getPos().getY(), be.getPos().getZ()), net.minecraft.registry.Registries.BLOCK_ENTITY_TYPE.getId(be.getType()).toString()));
        }
        return out;
    }
    @Override public int itemUseCooldown() { return ((dev.ultimate.mixin.MinecraftClientAccessor) mc).ultimateclient$getItemUseCooldown(); }
    @Override public void setItemUseCooldown(int t) { ((dev.ultimate.mixin.MinecraftClientAccessor) mc).ultimateclient$setItemUseCooldown(t); }
    @Override public int breakCooldown() { return ((dev.ultimate.mixin.InteractionManagerAccessor) mc.interactionManager).ultimateclient$getCooldown(); }
    @Override public void setBreakCooldown(int t) { ((dev.ultimate.mixin.InteractionManagerAccessor) mc.interactionManager).ultimateclient$setCooldown(t); }
    @Override public float breakProgress() { return ((dev.ultimate.mixin.InteractionManagerAccessor) mc.interactionManager).ultimateclient$getProgress(); }
    @Override public void setBreakProgress(float p) { ((dev.ultimate.mixin.InteractionManagerAccessor) mc.interactionManager).ultimateclient$setProgress(p); }
    private net.minecraft.client.network.ServerInfo lastServer;
    /** Call once per client tick: remembers the server so Auto Reconnect can rejoin it. */
    public void track() { if (mc.world != null && mc.getCurrentServerEntry() != null) lastServer = mc.getCurrentServerEntry(); }
    @Override public boolean disconnectScreenShown() { return mc.world == null && mc.currentScreen instanceof net.minecraft.client.gui.screen.DisconnectedScreen; }
    @Override public void reconnect() {
        if (lastServer == null || mc.world != null || !(mc.currentScreen instanceof net.minecraft.client.gui.screen.DisconnectedScreen)) return;
        net.minecraft.client.gui.screen.multiplayer.ConnectScreen.connect(new net.minecraft.client.gui.screen.TitleScreen(), mc,
            net.minecraft.client.network.ServerAddress.parse(lastServer.address), lastServer, false, null); // signature confirmed in Yarn 1.21.11 (Screen, client, ServerAddress, ServerInfo, boolean, CookieStorage)
    }
}
