package dev.ultimate.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Exposes the private use-delay counter to Fast Use / Fast XP. */
@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
    @Accessor("itemUseCooldown") int ultimateclient$getItemUseCooldown();
    @Accessor("itemUseCooldown") void ultimateclient$setItemUseCooldown(int v);
}
