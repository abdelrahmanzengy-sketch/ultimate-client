package dev.ultimate.mixin;

import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Exposes block-breaking delay and progress to Break Delay / Speed Mine. */
@Mixin(MultiPlayerGameMode.class)
public interface InteractionManagerAccessor {
    @Accessor("destroyDelay") int ultimateclient$getCooldown();
    @Accessor("destroyDelay") void ultimateclient$setCooldown(int v);
    @Accessor("destroyProgress") float ultimateclient$getProgress();
    @Accessor("destroyProgress") void ultimateclient$setProgress(float v);
}
