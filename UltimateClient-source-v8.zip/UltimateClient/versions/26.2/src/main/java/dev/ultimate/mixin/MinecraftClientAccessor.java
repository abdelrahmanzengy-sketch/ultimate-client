package dev.ultimate.mixin;

import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Exposes the private use-delay counter to Fast Use / Fast XP. */
@Mixin(Minecraft.class)
public interface MinecraftClientAccessor {
    @Accessor("rightClickDelay") int ultimateclient$getItemUseCooldown();
    @Accessor("rightClickDelay") void ultimateclient$setItemUseCooldown(int v);
}
