package dev.ultimate.mixin;

import dev.ultimate.core.FriendGuardState;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Friend Guard: cancels your own attack on a friend. Does nothing while the module is off. */
@Mixin(MultiPlayerGameMode.class)
public abstract class FriendGuardMixin {
    @Inject(method = "attack", at = @At("HEAD"), cancellable = true, require = 0)
    private void ultimateclient$guard(Player player, Entity target, CallbackInfo ci) {
        if (target instanceof Player t && FriendGuardState.shouldBlock(t.getName().getString(), player.isShiftKeyDown())) ci.cancel();
    }
}
