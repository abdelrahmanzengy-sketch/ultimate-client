package dev.ultimate;

import com.mojang.brigadier.arguments.StringArgumentType;
import dev.ultimate.core.ConfigManager;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.KeyPoller;
import dev.ultimate.core.ModuleManager;
import dev.ultimate.hud.Hud;
import dev.ultimate.modules.Modules;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.chat.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 26.2 entrypoint (UNCOMPILED, see McGame). Same behaviour as 1.21.11 except there is no on-screen HUD renderer yet:
 * the HUD model exists but nothing draws it on 26.2. Control everything with /uc (see /uc help).
 */
public final class UltimateClient implements ClientModInitializer {
    public static final String MOD_ID = "ultimateclient";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static ModuleManager modules; private static ConfigManager configs; private static FriendManager friends; private static Shell shell;

    @Override public void onInitializeClient() {
        McGame game = new McGame(); Hud hud = new Hud();
        modules = new ModuleManager(m -> LOGGER.info("[UC] {}", m));
        friends = new FriendManager();
        configs = new ConfigManager(FabricLoader.getInstance().getConfigDir().resolve("ultimateclient"), modules);
        Modules.registerAll(modules, game, friends);
        shell = new Shell(modules, configs, friends, hud);
        if (configs.profiles().contains("default")) { String err = shell.load("default"); if (err != null) LOGGER.warn("[UC] {}", err); }

        KeyPoller keys = new KeyPoller(modules, game::keyDown);
        ClientTickEvents.END_CLIENT_TICK.register(c -> { game.track(); keys.poll(game.screenOpen()); modules.tick(); });
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> { modules.onWorldLeave(); autosave(); });
        ClientLifecycleEvents.CLIENT_STOPPING.register(c -> autosave());
        ClientCommandRegistrationCallback.EVENT.register((d, access) -> d.register(ClientCommandManager.literal("uc")
            .executes(ctx -> { for (String l : shell.exec("help")) ctx.getSource().sendFeedback(Component.literal(l)); return 1; })
            .then(ClientCommandManager.argument("args", StringArgumentType.greedyString()).executes(ctx -> {
                for (String l : shell.exec(StringArgumentType.getString(ctx, "args"))) ctx.getSource().sendFeedback(Component.literal(l));
                return 1; }))));
        LOGGER.info("[UC] {} modules registered", modules.all().size());
    }
    private static void autosave() { String err = shell.save(configs.activeProfile()); if (err != null) LOGGER.warn("[UC] autosave: {}", err); }
    public static ModuleManager modules() { return modules; }
    public static FriendManager friends() { return friends; }
    public static ConfigManager configs() { return configs; }
}
