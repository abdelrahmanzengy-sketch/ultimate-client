package dev.ultimate;

import dev.ultimate.game.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.decoration.EndCrystal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;

/**
 * Game implementation for Minecraft 26.2 using Mojang's official (unobfuscated) names.
 *
 * !!! NOT COMPILED OR RUN !!!  Written from memory of the 1.21.x Mojang-mapped API without access to the 26.2 jars, so expect renamed
 * methods on the first real build. The riskiest spots are marked "VERIFY". Behaviour mirrors versions/1.21.11/McGame.java.
 */
public final class McGame implements Game {
    private final Minecraft mc = Minecraft.getInstance();
    private LocalPlayer p() { return mc.player; }

    private static net.minecraft.core.BlockPos bp(int x, int y, int z) { return new net.minecraft.core.BlockPos(x, y, z); }
    private static net.minecraft.core.BlockPos bp(BlockPos b) { return bp(b.x(), b.y(), b.z()); }
    private static Vec3 v(net.minecraft.world.phys.Vec3 d) { return new Vec3(d.x, d.y, d.z); }

    private EntityInfo info(Entity e) {
        EntityInfo.Kind kind = e instanceof EndCrystal ? EntityInfo.Kind.CRYSTAL : e instanceof Player ? EntityInfo.Kind.PLAYER
                : e instanceof net.minecraft.world.entity.item.ItemEntity ? EntityInfo.Kind.ITEM : e instanceof Monster ? EntityInfo.Kind.HOSTILE : e instanceof Animal ? EntityInfo.Kind.PASSIVE : EntityInfo.Kind.OTHER;
        float hp = 1, abs = 0; double armor = 0, tough = 0; int res = -1;
        if (e instanceof LivingEntity le) {
            hp = le.getHealth(); abs = le.getAbsorptionAmount(); armor = le.getArmorValue(); tough = le.getAttributeValue(Attributes.ARMOR_TOUGHNESS);
            MobEffectInstance r = le.getEffect(MobEffects.RESISTANCE); if (r != null) res = r.getAmplifier();
        }
        return new EntityInfo(e.getId(), kind, e.getName().getString(), v(e.position()), v(e.getDeltaMovement()), e.getBbWidth(), e.getBbHeight(), hp, abs, armor, tough, 0, res, e.onGround());
    }

    @Override public boolean inWorld() { return mc.player != null && mc.level != null && mc.getConnection() != null; }
    @Override public boolean selfDead() { return p().isDeadOrDying() || p().getHealth() <= 0; }
    @Override public EntityInfo self() { return info(p()); }
    @Override public List<EntityInfo> entities() { List<EntityInfo> out = new ArrayList<>(); for (Entity e : mc.level.entitiesForRendering()) if (e != p() && !e.isRemoved()) out.add(info(e)); return out; } // VERIFY name
    @Override public long tick() { return mc.level.getGameTime(); }
    @Override public int difficulty() { return mc.level.getDifficulty().getId(); }

    @Override public boolean isLoaded(int x, int z) { return mc.level.getChunkSource().hasChunk(x >> 4, z >> 4); }
    @Override public boolean isSolid(int x, int y, int z) { if (!isLoaded(x, z)) return false; var pos = bp(x, y, z); return mc.level.getBlockState(pos).isCollisionShapeFullBlock(mc.level, pos); }
    @Override public boolean isAir(int x, int y, int z) { return isLoaded(x, z) && mc.level.getBlockState(bp(x, y, z)).isAir(); }
    @Override public boolean isCrystalBase(int x, int y, int z) { if (!isLoaded(x, z)) return false; BlockState s = mc.level.getBlockState(bp(x, y, z)); return s.is(Blocks.OBSIDIAN) || s.is(Blocks.BEDROCK); }
    @Override public boolean canPlaceCrystal(BlockPos b) {
        return isAir(b.x(), b.y() + 1, b.z()) && isAir(b.x(), b.y() + 2, b.z())
            && mc.level.getEntities((Entity) null, new AABB(b.x(), b.y() + 1, b.z(), b.x() + 1, b.y() + 3, b.z() + 1)).isEmpty();
    }

    @Override public int selectedSlot() { return p().getInventory().getSelectedSlot(); }
    @Override public void selectSlot(int s) { p().getInventory().setSelectedSlot(s); }
    private static EquipmentSlot equipSlot(ItemStack s) { var c = s.get(DataComponents.EQUIPPABLE); return c == null ? null : c.slot(); }
    private static boolean matches(ItemStack s, ItemKind k) {
        if (s.isEmpty()) return false;
        return switch (k) {
            case TOTEM -> s.is(Items.TOTEM_OF_UNDYING); case END_CRYSTAL -> s.is(Items.END_CRYSTAL); case OBSIDIAN -> s.is(Items.OBSIDIAN);
            case GOLDEN_APPLE -> s.is(Items.GOLDEN_APPLE); case WEB -> s.is(Items.COBWEB); case FOOD -> s.has(DataComponents.FOOD);
            case SWORD -> s.is(ItemTags.SWORDS); case AXE -> s.is(ItemTags.AXES); case PICKAXE -> s.is(ItemTags.PICKAXES);
            case EXP_BOTTLE -> s.is(Items.EXPERIENCE_BOTTLE); case GLOWSTONE -> s.is(Items.GLOWSTONE); case RESPAWN_ANCHOR -> s.is(Items.RESPAWN_ANCHOR);
            case ELYTRA -> s.is(Items.ELYTRA); case CHESTPLATE -> equipSlot(s) == EquipmentSlot.CHEST && !s.is(Items.ELYTRA);
            case FISHING_ROD -> s.is(Items.FISHING_ROD); case TORCH -> s.is(Items.TORCH);
            case ANVIL -> s.is(Items.ANVIL) || s.is(Items.CHIPPED_ANVIL) || s.is(Items.DAMAGED_ANVIL);
            case BED -> s.is(net.minecraft.tags.ItemTags.BEDS);
            case MACE -> s.is(Items.MACE); case TRIDENT -> s.is(Items.TRIDENT); case PEARL -> s.is(Items.ENDER_PEARL); case SHEARS -> s.is(Items.SHEARS);
            case FILLER_BLOCK -> s.is(Items.COBBLESTONE) || s.is(Items.STONE) || s.is(Items.DIRT) || s.is(Items.NETHERRACK) || s.is(Items.COBBLED_DEEPSLATE);
            default -> false;
        };
    }
    private static final ItemKind[] KINDS = {ItemKind.TOTEM, ItemKind.END_CRYSTAL, ItemKind.OBSIDIAN, ItemKind.GOLDEN_APPLE, ItemKind.WEB, ItemKind.ANVIL, ItemKind.BED, ItemKind.MACE, ItemKind.TRIDENT, ItemKind.PEARL, ItemKind.SHEARS, ItemKind.SWORD, ItemKind.AXE, ItemKind.PICKAXE,
        ItemKind.EXP_BOTTLE, ItemKind.GLOWSTONE, ItemKind.RESPAWN_ANCHOR, ItemKind.ELYTRA, ItemKind.CHESTPLATE, ItemKind.FISHING_ROD, ItemKind.TORCH, ItemKind.FILLER_BLOCK};
    private static ItemKind kind(ItemStack s) { if (s.isEmpty()) return ItemKind.NONE; for (ItemKind k : KINDS) if (matches(s, k)) return k; return ItemKind.OTHER; }
    @Override public int hotbarSlotOf(ItemKind k) { for (int i = 0; i < 9; i++) if (matches(p().getInventory().getItem(i), k)) return i; return -1; }
    @Override public int mainInvSlotOf(ItemKind k) { for (int i = 9; i < 36; i++) if (matches(p().getInventory().getItem(i), k)) return i; return -1; }
    @Override public int countItem(ItemKind k) { int n = 0; for (int i = 0; i < 36; i++) { ItemStack st = p().getInventory().getItem(i); if (matches(st, k)) n += st.getCount(); } ItemStack o = p().getOffhandItem(); if (matches(o, k)) n += o.getCount(); return n; }
    @Override public ItemKind mainHand() { return kind(p().getMainHandItem()); }
    @Override public ItemKind offhand() { return kind(p().getOffhandItem()); }

    private static int screenSlot(int inv) { return inv < 9 ? 36 + inv : inv; }
    private void click(int slot, int button, ClickType t) { mc.gameMode.handleInventoryMouseClick(p().inventoryMenu.containerId, slot, button, t, p()); }   // VERIFY name
    private void swapWithScreenSlot(int inv, int target) { int a = screenSlot(inv); click(a, 0, ClickType.PICKUP); click(target, 0, ClickType.PICKUP); click(a, 0, ClickType.PICKUP); }
    @Override public void swapWithOffhand(int inv) { click(screenSlot(inv), 40, ClickType.SWAP); }

    private InteractionHand crystalHand() { return p().getOffhandItem().is(Items.END_CRYSTAL) && !p().getMainHandItem().is(Items.END_CRYSTAL) ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND; }
    @Override public boolean placeCrystal(BlockPos b) {
        InteractionHand h = crystalHand();
        if (!p().getItemInHand(h).is(Items.END_CRYSTAL)) return false;
        mc.gameMode.useItemOn(p(), h, new BlockHitResult(new net.minecraft.world.phys.Vec3(b.x() + 0.5, b.y() + 1.0, b.z() + 0.5), Direction.UP, bp(b), false)); p().swing(h); return true;
    }
    @Override public boolean placeBlock(BlockPos at) {
        if (!mc.level.getBlockState(bp(at)).canBeReplaced()) return false;
        for (Direction d : Direction.values()) {
            net.minecraft.core.BlockPos n = bp(at).relative(d);
            if (!isSolid(n.getX(), n.getY(), n.getZ())) continue;
            Direction face = d.getOpposite();
            var hit = new net.minecraft.world.phys.Vec3(n.getX() + 0.5 + face.getStepX() * 0.5, n.getY() + 0.5 + face.getStepY() * 0.5, n.getZ() + 0.5 + face.getStepZ() * 0.5);
            mc.gameMode.useItemOn(p(), InteractionHand.MAIN_HAND, new BlockHitResult(hit, face, n, false)); p().swing(InteractionHand.MAIN_HAND); return true;
        }
        return false;
    }
    @Override public boolean attack(int id) { Entity e = mc.level.getEntity(id); if (e == null) return false; mc.gameMode.attack(p(), e); p().swing(InteractionHand.MAIN_HAND); return true; }
    @Override public void lookAt(Vec3 t) {
        var eye = p().getEyePosition(); double dx = t.x() - eye.x, dy = t.y() - eye.y, dz = t.z() - eye.z, h = Math.sqrt(dx * dx + dz * dz);
        p().setYRot((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0)); p().setXRot((float) -Math.toDegrees(Math.atan2(dy, h)));
    }
    @Override public void setVelocity(Vec3 vel) { p().setDeltaMovement(vel.x(), vel.y(), vel.z()); }
    @Override public void setSprinting(boolean on) { p().setSprinting(on); }
    @Override public void respawn() { p().respawn(); }

    @Override public boolean movingForward() { return mc.options.keyUp.isDown(); }
    @Override public boolean movingAny() { return mc.options.keyUp.isDown() || mc.options.keyDown.isDown() || mc.options.keyLeft.isDown() || mc.options.keyRight.isDown(); }
    @Override public boolean jumping() { return mc.options.keyJump.isDown(); }
    @Override public boolean sneaking() { return mc.options.keyShift.isDown(); }
    @Override public boolean usingItem() { return p().isUsingItem(); }
    @Override public boolean breakingBlock() { return mc.gameMode.isDestroying(); }
    @Override public float yaw() { return p().getYRot(); }
    @Override public float pitch() { return p().getXRot(); }
    @Override public float fallDistance() { return (float) p().fallDistance; }   // VERIFY type
    @Override public boolean inWater() { return p().isInWater(); }
    @Override public void sendOnGround(boolean g) { p().connection.send(new ServerboundMovePlayerPacket.StatusOnly(g, p().horizontalCollision)); }
    @Override public float attackCooldown() { return p().getAttackStrengthScale(0.5f); }
    @Override public void message(String t) { p().displayClientMessage(Component.literal("[UC] " + t), false); }
    @Override public int hunger() { return p().getFoodData().getFoodLevel(); }
    @Override public void setUseKey(boolean down) { mc.options.keyUse.setDown(down); }

    /** True if the user physically holds the key bound to this action (keyboard keys only). */
    private boolean physical(net.minecraft.client.KeyMapping kb) { return keyDown(net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.getBoundKeyOf(kb).getValue()); }
    @Override public void setForwardInput(boolean on) { mc.options.keyUp.setDown(on || physical(mc.options.keyUp)); }
    @Override public void setJumpInput(boolean on) { mc.options.keyJump.setDown(on || physical(mc.options.keyJump)); }
    @Override public void setSneakInput(boolean on) { mc.options.keyShift.setDown(on || physical(mc.options.keyShift)); }
    @Override public boolean keyDown(int code) { return code >= 0 && org.lwjgl.glfw.GLFW.glfwGetKey(mc.getWindow().handle(), code) == org.lwjgl.glfw.GLFW.GLFW_PRESS; }   // VERIFY: handle() vs getWindow()
    @Override public boolean screenOpen() { return mc.screen != null; }

    @Override public void setRotation(float yaw, float pitch) { p().setYRot(yaw); p().setXRot(pitch); }
    @Override public void useItem() { if (mc.gameMode.useItem(p(), InteractionHand.MAIN_HAND).consumesAction()) p().swing(InteractionHand.MAIN_HAND); }
    @Override public int crosshairEntity() { return mc.hitResult instanceof EntityHitResult r ? r.getEntity().getId() : -1; }
    @Override public boolean horizontalCollision() { return p().horizontalCollision; }
    @Override public boolean onClimbable() { return p().onClimbable(); }
    @Override public boolean gliding() { return p().isFallFlying(); }
    @Override public boolean breakBlock(BlockPos b) { boolean ok = mc.gameMode.continueDestroyBlock(bp(b), Direction.UP); if (ok) p().swing(InteractionHand.MAIN_HAND); return ok; }
    @Override public boolean interactBlock(BlockPos b) {
        boolean ok = mc.gameMode.useItemOn(p(), InteractionHand.MAIN_HAND, new BlockHitResult(new net.minecraft.world.phys.Vec3(b.x() + 0.5, b.y() + 1.0, b.z() + 0.5), Direction.UP, bp(b), false)).consumesAction();
        if (ok) p().swing(InteractionHand.MAIN_HAND); return ok;
    }
    @Override public boolean isLiquid(int x, int y, int z) { return isLoaded(x, z) && !mc.level.getFluidState(bp(x, y, z)).isEmpty(); }
    @Override public int lightLevel(int x, int y, int z) { return isLoaded(x, z) ? mc.level.getBrightness(LightLayer.BLOCK, bp(x, y, z)) : 15; }
    @Override public int anchorCharges(BlockPos b) { if (!isLoaded(b.x(), b.z())) return -1; BlockState st = mc.level.getBlockState(bp(b)); return st.is(Blocks.RESPAWN_ANCHOR) ? st.getValue(RespawnAnchorBlock.CHARGE) : -1; }
    @Override public BlockPos targetBlock() { if (mc.hitResult instanceof BlockHitResult r && r.getType() == HitResult.Type.BLOCK) { var q = r.getBlockPos(); return new BlockPos(q.getX(), q.getY(), q.getZ()); } return null; }
    @Override public int bestToolSlotFor(BlockPos b) {
        BlockState st = mc.level.getBlockState(bp(b)); int best = -1; float bestSpeed = p().getInventory().getItem(selectedSlot()).getDestroySpeed(st);
        for (int i = 0; i < 9; i++) { float sp = p().getInventory().getItem(i).getDestroySpeed(st); if (sp > bestSpeed + 0.01f) { bestSpeed = sp; best = i; } }
        return best;
    }
    private boolean ownNightVision;
    @Override public void setNightVision(boolean on) {
        if (on) {
            MobEffectInstance cur = p().getEffect(MobEffects.NIGHT_VISION);
            if (cur != null && !ownNightVision) return;
            if (cur == null || cur.getDuration() < 400) { p().addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 1200, 0, false, false, false)); ownNightVision = true; }
        } else if (ownNightVision) { p().removeEffect(MobEffects.NIGHT_VISION); ownNightVision = false; }
    }
    @Override public String itemId(int slot) { ItemStack st = p().getInventory().getItem(slot); return st.isEmpty() ? "" : BuiltInRegistries.ITEM.getKey(st.getItem()).toString(); }
    @Override public boolean isBreakable(int x, int y, int z) { return isLoaded(x, z) && mc.level.getBlockState(bp(x, y, z)).getDestroySpeed(mc.level, bp(x, y, z)) >= 0; }
    @Override public int fov() { return mc.options.fov().get(); }
    @Override public void setFov(int f) { mc.options.fov().set(Math.max(30, Math.min(110, f))); }
    @Override public float stepHeight() { return (float) p().getAttributeValue(Attributes.STEP_HEIGHT); }
    @Override public void setStepHeight(float h) { var inst = p().getAttribute(Attributes.STEP_HEIGHT); if (inst != null) inst.setBaseValue(h); }
    @Override public boolean raining() { return mc.level.isRaining(); }
    @Override public void sendChat(String t) { if (t.startsWith("/")) p().connection.sendCommand(t.substring(1)); else p().connection.sendChat(t); }
    @Override public boolean fishBobberOut() { return p().fishing != null; }
    @Override public boolean fishBobberDipping() { var h = p().fishing; return h != null && h.isInWater() && h.getDeltaMovement().y < -0.05; }
    @Override public float armorDurability() {
        float worst = 1f;
        for (EquipmentSlot es : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
            ItemStack st = p().getItemBySlot(es); if (!st.isEmpty() && st.isDamageableItem()) worst = Math.min(worst, 1f - (float) st.getDamageValue() / st.getMaxDamage());
        }
        return worst;
    }
    @Override public int stackCount(int slot) { return p().getInventory().getItem(slot).getCount(); }
    @Override public ItemKind kindAt(int slot) { return kind(p().getInventory().getItem(slot)); }
    @Override public void mergeIntoHotbar(int mainSlot, int hotbarSlot) { click(mainSlot, 0, ClickType.PICKUP); click(36 + hotbarSlot, 0, ClickType.PICKUP); click(mainSlot, 0, ClickType.PICKUP); }

    private static final EquipmentSlot[] ARMOR_BY_IDX = {EquipmentSlot.FEET, EquipmentSlot.LEGS, EquipmentSlot.CHEST, EquipmentSlot.HEAD};
    private static double armorScore(ItemStack st) {
        var mods = st.getOrDefault(DataComponents.ATTRIBUTE_MODIFIERS, net.minecraft.world.item.component.ItemAttributeModifiers.EMPTY); double score = 0;
        for (var e : mods.modifiers()) if (e.attribute().equals(Attributes.ARMOR) || e.attribute().equals(Attributes.ARMOR_TOUGHNESS)) score += e.modifier().amount();   // VERIFY amount()
        return score;
    }
    @Override public int betterArmorSlot(int idx) {
        EquipmentSlot es = ARMOR_BY_IDX[idx]; double cur = armorScore(p().getItemBySlot(es)); int best = -1;
        for (int i = 0; i < 36; i++) { ItemStack st = p().getInventory().getItem(i); if (st.isEmpty() || equipSlot(st) != es || st.is(Items.ELYTRA)) continue; double sc = armorScore(st); if (sc > cur + 0.01) { cur = sc; best = i; } }
        return best;
    }
    @Override public void equipArmor(int invSlot, int idx) { swapWithScreenSlot(invSlot, 8 - idx); }
    @Override public ItemKind chest() { ItemStack st = p().getItemBySlot(EquipmentSlot.CHEST); return st.isEmpty() ? ItemKind.NONE : st.is(Items.ELYTRA) ? ItemKind.ELYTRA : matches(st, ItemKind.CHESTPLATE) ? ItemKind.CHESTPLATE : ItemKind.OTHER; }
    @Override public void swapWithChest(int invSlot) { swapWithScreenSlot(invSlot, 6); }

    @Override public boolean isBlocking(int id) { return mc.level != null && mc.level.getEntity(id) instanceof LivingEntity le && le.isBlocking(); }
    private final IdentityHashMap<Block, String> blockIdCache = new IdentityHashMap<>();
    @Override public String blockId(int x, int y, int z) {
        if (!isLoaded(x, z)) return ""; BlockState st = mc.level.getBlockState(bp(x, y, z)); if (st.isAir()) return "";
        return blockIdCache.computeIfAbsent(st.getBlock(), b -> BuiltInRegistries.BLOCK.getKey(b).toString());
    }
    @Override public int fps() { return mc.getFps(); }   // VERIFY name
    @Override public int ping() { if (mc.getConnection() == null || p() == null) return -1; var e = mc.getConnection().getPlayerInfo(p().getUUID()); return e == null ? -1 : e.getLatency(); }

    // ---- v6 additions (UNVERIFIED names, see VERIFY marks) ----
    @Override public int hurtTime() { return p() == null ? 0 : p().hurtTime; } // VERIFY
    @Override public java.util.List<String> onlinePlayerNames() {
        java.util.List<String> out = new java.util.ArrayList<>();
        if (mc.getConnection() == null) return out;
        for (var e : mc.getConnection().getOnlinePlayers()) out.add(e.getProfile().name()); // VERIFY
        return out;
    }
    @Override public float sidewaysInput() { float l = mc.options.keyLeft.isDown() ? 1f : 0f, r = mc.options.keyRight.isDown() ? 1f : 0f; return r - l; } // VERIFY
    @Override public java.util.List<String> effectTimers() {
        java.util.List<String> out = new java.util.ArrayList<>();
        if (p() == null) return out;
        for (var e : p().getActiveEffects()) {
            int sec = e.isInfiniteDuration() ? -1 : e.getDuration() / 20;
            String time = sec < 0 ? "inf" : (sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + (sec % 60);
            out.add(e.getEffect().value().getDisplayName().getString() + " " + (e.getAmplifier() + 1) + " " + time); // VERIFY
        }
        return out;
    }
    @Override public String serverAddress() { var s = mc.getCurrentServer(); return s == null ? "" : s.ip; } // VERIFY

    // ---- v7 additions (UNVERIFIED names, see VERIFY marks) ----
    private net.minecraft.world.entity.Entity vehicle() { return p() == null ? null : p().getVehicle(); }
    @Override public boolean riding() { return vehicle() != null; }
    @Override public boolean vehicleIsBoat() { return vehicle() instanceof net.minecraft.world.entity.vehicle.boat.AbstractBoat; } // VERIFY package
    @Override public Vec3 vehicleVelocity() { var v = vehicle(); if (v == null) return Vec3.ZERO; var d = v.getDeltaMovement(); return new Vec3(d.x, d.y, d.z); }
    @Override public void setVehicleVelocity(Vec3 v) { var e = vehicle(); if (e != null) e.setDeltaMovement(v.x(), v.y(), v.z()); }
    @Override public boolean inventoryScreenOpen() { return mc.screen instanceof net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?>; }
    @Override public int hoveredSlot() {
        if (!(mc.screen instanceof net.minecraft.client.gui.screens.inventory.AbstractContainerScreen<?> hs) || p() == null) return -1;
        var slot = ((dev.ultimate.mixin.HandledScreenAccessor) hs).ultimateclient$hoveredSlot(); // VERIFY accessor target
        return slot != null && slot.container == p().getInventory() ? slot.getContainerSlot() : -1;
    }
    @Override public boolean interactEntity(int id) {
        var e = mc.level == null ? null : mc.level.getEntity(id); if (e == null || mc.gameMode == null) return false;
        boolean ok = mc.gameMode.interact(p(), e, net.minecraft.world.InteractionHand.MAIN_HAND).consumesAction(); if (ok) p().swing(net.minecraft.world.InteractionHand.MAIN_HAND); return ok;
    }
    @Override public java.util.List<BlockEntry> blockEntities() {
        java.util.List<BlockEntry> out = new java.util.ArrayList<>(); if (mc.level == null || p() == null) return out;
        int r = mc.options.renderDistance().get(), cx = p().chunkPosition().x, cz = p().chunkPosition().z;
        for (int x = cx - r; x <= cx + r; x++) for (int z = cz - r; z <= cz + r; z++) {
            var ch = mc.level.getChunkSource().getChunkNow(x, z); if (ch == null) continue; // VERIFY
            for (var be : ch.getBlockEntities().values()) out.add(new BlockEntry(new BlockPos(be.getBlockPos().getX(), be.getBlockPos().getY(), be.getBlockPos().getZ()), net.minecraft.core.registries.BuiltInRegistries.BLOCK_ENTITY_TYPE.getKey(be.getType()).toString()));
        }
        return out;
    }
    @Override public int itemUseCooldown() { return ((dev.ultimate.mixin.MinecraftClientAccessor) mc).ultimateclient$getItemUseCooldown(); }
    @Override public void setItemUseCooldown(int t) { ((dev.ultimate.mixin.MinecraftClientAccessor) mc).ultimateclient$setItemUseCooldown(t); }
    @Override public int breakCooldown() { return ((dev.ultimate.mixin.InteractionManagerAccessor) mc.gameMode).ultimateclient$getCooldown(); }
    @Override public void setBreakCooldown(int t) { ((dev.ultimate.mixin.InteractionManagerAccessor) mc.gameMode).ultimateclient$setCooldown(t); }
    @Override public float breakProgress() { return ((dev.ultimate.mixin.InteractionManagerAccessor) mc.gameMode).ultimateclient$getProgress(); }
    @Override public void setBreakProgress(float p) { ((dev.ultimate.mixin.InteractionManagerAccessor) mc.gameMode).ultimateclient$setProgress(p); }
    private net.minecraft.client.multiplayer.ServerData lastServer;
    /** Call once per client tick: remembers the server so Auto Reconnect can rejoin it. */
    public void track() { if (mc.level != null && mc.getCurrentServer() != null) lastServer = mc.getCurrentServer(); }
    @Override public boolean disconnectScreenShown() { return mc.level == null && mc.screen instanceof net.minecraft.client.gui.screens.DisconnectedScreen; }
    @Override public void reconnect() {
        if (lastServer == null || mc.level != null || !(mc.screen instanceof net.minecraft.client.gui.screens.DisconnectedScreen)) return;
        net.minecraft.client.gui.screens.ConnectScreen.startConnecting(new net.minecraft.client.gui.screens.TitleScreen(), mc,
            net.minecraft.client.multiplayer.resolver.ServerAddress.parse(lastServer.ip), lastServer, false, null); // VERIFY signature
    }
}
