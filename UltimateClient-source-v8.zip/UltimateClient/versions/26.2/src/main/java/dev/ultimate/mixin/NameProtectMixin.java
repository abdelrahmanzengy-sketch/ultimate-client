package dev.ultimate.mixin;

import dev.ultimate.core.NameState;
import net.minecraft.util.StringDecomposer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Name Protect: swaps your username in text before it is drawn. Does nothing while the module is off. */
@Mixin(StringDecomposer.class)
public abstract class NameProtectMixin {
    @ModifyVariable(method = "iterateFormatted(Ljava/lang/String;ILnet/minecraft/network/chat/Style;Lnet/minecraft/network/chat/Style;Lnet/minecraft/util/FormattedCharSink;)Z",
                    at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private static String ultimateclient$protect(String text) { return NameState.active() ? NameState.apply(text) : text; }
}
