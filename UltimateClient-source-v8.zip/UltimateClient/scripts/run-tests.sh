#!/bin/sh
# Compiles core + common + tests with a plain JDK 21 (no Gradle, no network, no Minecraft) and runs them.
# Usage: sh scripts/run-tests.sh      (needs `javac`; on a JRE-only box use: java -m jdk.compiler/com.sun.tools.javac.Main)
set -e
cd "$(dirname "$0")/.."
OUT=$(mktemp -d)
JAVAC=${JAVAC:-javac}
$JAVAC -d "$OUT" $(find core/src common/src -name '*.java')
java -cp "$OUT" dev.ultimate.core.CoreTest
java -cp "$OUT" dev.ultimate.modules.ModuleTest
