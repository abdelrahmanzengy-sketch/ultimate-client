#!/bin/sh
# Regenerates docs/MODULES.md and default-config/default.json from the code (plain JDK 21, no Minecraft).
set -e
cd "$(dirname "$0")/.."
OUT=$(mktemp -d); JAVAC=${JAVAC:-javac}
$JAVAC -d "$OUT" $(find core/src common/src -name '*.java')
java -cp "$OUT" dev.ultimate.modules.DocGen .
