> **Status:** 118 modules with tested logic, never compiled against Minecraft. Read STATUS.md and BUILDING.md first.

 # UltimateClient — updated source package
 
 This ZIP updates the existing starter project's version-specific build configuration and build/status documentation. It is **source only**: it does not contain built JARs and is not a complete or runtime-tested Minecraft client.

## Build targets

- **Minecraft 1.21.11** — Java 21, Fabric Loom remapping plugin, Yarn `1.21.11+build.6`, Fabric API `0.141.6+1.21.11`.
- **Minecraft 26.2** — Java 25, non-remapping Fabric Loom plugin, Mojang's built-in unobfuscated names (no Yarn dependency), Fabric API `0.161.0+26.2`.
- Both configurations pin Fabric Loader `0.19.5` and Loom `1.17.21`.

Install Gradle **9.5.1** and both JDK toolchains (21 and 25). From this directory run one target at a time:

```sh
gradle :versions:1.21.11:build
gradle :versions:26.2:build
gradle :core:runCoreTests
```

The expected JAR output locations are under each version project's `build/libs/`. Those commands are instructions only: they were **not run** while preparing this ZIP, so compilation is not verified. If Gradle reports mapping, API, source, or dependency errors, those still need to be fixed in a build-capable environment.

## What is in the source

- A pure-Java module/settings/event/config core and a small registered-module framework.
- Common module classes mostly contain configuration declarations and lifecycle shells.
- Separate Fabric entrypoint/build folders for the two Minecraft versions.
- `FEATURES.md`, the supplied first-pass reference inventory. It lists class names and metadata; it is **not** a behavioral audit of all five JARs.

## Not implemented or verified

The in-game Click GUI, HUD, game tick/event wiring, module behaviors, Baritone integration, broad requested feature set, multiplayer/server compatibility, and Pojav/Android ARM64 compatibility are not complete or tested. Registered names/settings are not proof of working gameplay behavior. No final client JAR is included.

See `IMPLEMENTATION.md` for the honest feature/status checklist. Do not treat this package as a finished client.


## Install (after a successful build)
1. Build with the GitHub Actions workflow (see BUILDING.md) and download `UltimateClient-1.21.11.jar` or `UltimateClient-26.2.jar` from the run artifacts. (No jar ships in this zip.)
2. Install Fabric Loader and Fabric API for your Minecraft version (1.21.11 needs Java 21+, 26.2 needs Java 25+). Put the UltimateClient jar in the `mods` folder.
   Baritone is optional: add the baritone-meteor (or baritone-api) jar to `mods` to use `/uc baritone <command>`.
3. In game, type `/uc help`. Copy `default-config/default.json` to `config/ultimateclient/default.json` for the documented defaults (it is what a fresh install uses anyway).
4. Module reference with every setting and default: `docs/MODULES.md` (regenerate with `sh scripts/gen-docs.sh`). Honest status and known gaps: `STATUS.md`.
