package dev.ultimate.modules;

import dev.ultimate.Shell;
import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;
import dev.ultimate.hud.Hud;
import dev.ultimate.modules.client.ClientBrand;
import dev.ultimate.modules.combat.*;
import dev.ultimate.modules.misc.*;
import dev.ultimate.modules.movement.*;
import dev.ultimate.modules.world.*;

import java.nio.file.Files;
import java.util.*;

/** Tests for keys, key polling, the /uc shell, ClientBrand and the v5 modules. */
final class V5Test {
    private V5Test() {}
    static void check(boolean c, String m) { ModuleTest.check(c, m); }
    static NewModuleTest.G world() { return NewModuleTest.world(); }
    static NewModuleTest.G foe(double x, double z) { return NewModuleTest.withFoe(x, z); }
    static ModuleManager reg(Module... ms) { return ModuleTest.reg(ms); }
    static long k(int x, int y, int z) { return ModuleTest.FakeGame.k(x, y, z); }
    static boolean has(List<String> l, String frag) { return l.stream().anyMatch(s -> s.contains(frag)); }

    static void run() throws Exception { keys(); brand(); shell(); modules(); }

    static void keys() {
        check(Keys.code("g") == 71 && Keys.code("G") == 71 && Keys.code("F5") == 294 && Keys.code("lshift") == 340, "key names map to GLFW codes");
        check(Keys.code("none") == -1 && Keys.code("bogus") == -2 && Keys.code("999") == -2 && Keys.code("65") == 65, "none / unknown / numeric keys");
        boolean rt = true; for (int c = 0; c < 512; c++) { String n = Keys.name(c); if (!n.startsWith("key") && Keys.code(n) != c) rt = false; } check(rt, "every named key round-trips through name()/code()");
        check(Keys.name(-1).equals("none") && Keys.name(71).equals("G"), "key display names");
        // poller
        NewModuleTest.G g = world(); ModuleManager mm = new ModuleManager(s -> {}); Fly f = new Fly(g); Sprint sp = new Sprint(g); mm.register(f); mm.register(sp); f.setKeybind(71); sp.setKeybind(71);
        boolean[] down = {false}; KeyPoller kp = new KeyPoller(mm, key -> key == 71 && down[0]);
        kp.poll(false); check(!f.isEnabled(), "poller idle with key up");
        down[0] = true; kp.poll(false); check(f.isEnabled() && sp.isEnabled(), "poller toggles on key press (both modules sharing the key, once)");
        kp.poll(false); kp.poll(false); check(f.isEnabled(), "holding the key does not repeat");
        down[0] = false; kp.poll(false); down[0] = true; kp.poll(false); check(!f.isEnabled() && !sp.isEnabled(), "a second press toggles back");
        down[0] = false; kp.poll(false); down[0] = true; kp.poll(true); check(!f.isEnabled(), "keys pressed while a screen is open are ignored");
        kp.poll(false); check(!f.isEnabled(), "key held across screen close does not fire"); down[0] = false; kp.poll(false);
        f.setKeybind(-1); sp.setKeybind(600); down[0] = true; kp.poll(false); check(!f.isEnabled() && !sp.isEnabled(), "unbound and out-of-range keybinds are ignored without errors");
    }

    static void brand() {
        BrandState.set(null);
        ClientBrand cb = new ClientBrand(); ModuleManager mm = reg(cb);
        check(BrandState.get() == null, "brand state untouched while disabled");
        cb.setEnabled(true); check("vanilla".equals(BrandState.get()), "brand: vanilla");
        cb.mode.set("Fabric"); check("fabric".equals(BrandState.get()), "brand follows mode changes while enabled");
        cb.mode.set("Custom"); cb.custom.set("My\u0007Cli\u00e9ent  "); check("MyClient".equals(BrandState.get()), "custom brand is stripped to printable ASCII, got " + BrandState.get());
        cb.custom.set("   "); check("vanilla".equals(BrandState.get()), "blank custom brand falls back to vanilla");
        cb.custom.set("x".repeat(80)); check(BrandState.get().length() <= 32, "custom brand length is capped");
        cb.setEnabled(false); check(BrandState.get() == null, "disabling restores the game's own brand");
        check(cb.category == Category.CLIENT && cb.description.contains("Not a stealth"), "client brand is honest about not being a stealth feature");
        BrandState.set(null);
    }

    /** Test module with every setting type. */
    static final class AllTypes extends Module {
        final Setting.Color color = add(new Setting.Color("color", "A color", 0xFF112233));
        final Setting.Key key = add(new Setting.Key("key", "A key", -1));
        final Setting.Str text = add(new Setting.Str("text", "Some text", "hi", 20));
        final Setting.Bool flag = add(new Setting.Bool("flag", "A flag", false));
        final Setting.Num num = add(Setting.Num.intg("num", "A number", 5, 1, 10));
        final Setting.Mode mode = add(new Setting.Mode("mode", "A mode", "A", "A", "B"));
        AllTypes() { super("all-types", "All Types", "Test module", Category.MISC); }
    }

    static void shell() throws Exception {
        NewModuleTest.G g = world(); ModuleManager mm = new ModuleManager(s -> {}); FriendManager fr = new FriendManager(); Hud hud = new Hud();
        Modules.registerAll(mm, g, fr); AllTypes at = new AllTypes(); mm.register(at);
        java.nio.file.Path dir = Files.createTempDirectory("uc-shell"); ConfigManager cfg = new ConfigManager(dir, mm); Shell sh = new Shell(mm, cfg, fr, hud);
        check(sh.exec("").size() > 3 && has(sh.exec("help"), "/uc toggle"), "empty line and help print the help text");
        check(has(sh.exec("list"), "Combat (") && has(sh.exec("list"), "Client (1)"), "list shows categories with counts");
        check(sh.exec("list movement").size() == 2 && has(sh.exec("list movement"), "fly"), "list <category> filters");
        check(has(sh.exec("list nonsense"), "Unknown category"), "list rejects unknown category");
        check(has(sh.exec("toggle fly"), "Fly enabled") && mm.get("fly").isEnabled(), "toggle enables a module");
        check(has(sh.exec("off fly"), "disabled") && !mm.get("fly").isEnabled(), "off disables a module");
        check(has(sh.exec("on FLY"), "enabled") && mm.get("fly").isEnabled(), "module ids are case-insensitive");
        check(has(sh.exec("toggle flyy"), "Unknown module"), "unknown module reports an error"); check(has(sh.exec("toggle crystal"), "Did you mean: crystal-aura"), "unknown module suggests a match");
        check(sh.exec("toggle").get(0).startsWith("Usage"), "missing argument prints usage");
        check(has(sh.exec("info fly"), "speed =") && has(sh.exec("info fly"), "[0.05..3]"), "info lists settings with ranges");
        check(sh.exec("set crystal-aura min-damage 9.5").get(0).contains("9.5") && ((Setting.Num) mm.get("crystal-aura").setting("min-damage")).get() == 9.5, "set number");
        check(sh.exec("set crystal-aura min-damage 999").get(0).contains("clamped"), "out-of-range number is clamped and says so");
        check(sh.exec("set crystal-aura min-damage abc").get(0).contains("Expected a number"), "bad number rejected");
        check(sh.exec("set crystal-aura min-damage NaN").get(0).contains("finite"), "NaN rejected");
        check(sh.exec("set fly mode glide").get(0).contains("Glide"), "mode matches case-insensitively"); check(sh.exec("set fly mode warp").get(0).contains("Choose one of"), "bad mode lists options");
        check(sh.exec("set all-types flag on").get(0).contains("true") && at.flag.get(), "set boolean"); check(sh.exec("set all-types flag maybe").get(0).contains("Expected on/off"), "bad boolean rejected");
        check(sh.exec("set all-types color #FF0000").get(0).contains("FFFF0000") && at.color.get() == 0xFFFF0000, "set color RRGGBB"); check(sh.exec("set all-types color zzz").get(0).contains("Expected #RRGGBB"), "bad color rejected");
        check(sh.exec("set all-types key f7").get(0).contains("F7") && at.key.get() == 296, "set key setting"); check(sh.exec("set all-types key nope").get(0).contains("Unknown key"), "bad key setting rejected");
        sh.exec("set all-types text hello there world"); check(at.text.get().equals("hello there world"), "string settings take the rest of the line");
        check(has(sh.exec("set all-types nothing 1"), "No setting"), "unknown setting reported");
        check(sh.exec("get all-types num").get(0).equals("num = 5"), "get a setting");
        sh.exec("set all-types num 9"); sh.exec("reset all-types num"); check(at.num.get() == 5.0, "reset one setting"); sh.exec("set all-types num 9"); sh.exec("reset all-types"); check(at.num.get() == 5.0 && !at.flag.get(), "reset all settings of a module");
        check(has(sh.exec("bind fly g"), "key: G") && mm.get("fly").keybind() == 71, "bind a key"); check(has(sh.exec("binds"), "G  ->  fly"), "binds lists keys");
        check(has(sh.exec("bind fly nokey"), "Unknown key") && mm.get("fly").keybind() == 71, "bad key leaves the old bind"); sh.exec("bind fly none"); check(mm.get("fly").keybind() == -1, "unbind");
        check(has(sh.exec("fav fly"), "added") && mm.isFavorite("fly") && has(sh.exec("favs"), "fly") && has(sh.exec("fav fly"), "removed"), "favorites toggle");
        check(has(sh.exec("recent"), "fly"), "recent lists enabled modules");
        check(has(sh.exec("friend add Bob"), "now a friend") && fr.isFriend("bob") && has(sh.exec("friend list"), "Bob") && has(sh.exec("friend add bob"), "Already"), "friend add/list");
        check(has(sh.exec("friend remove bob"), "removed") && !fr.isFriend("Bob") && has(sh.exec("friend remove bob"), "Not in") && has(sh.exec("friend list"), "No friends"), "friend remove works and reports unknown names"); sh.exec("friend add Bob");
        sh.exec("hud move watermark 0.5 0.5"); check(hud.get("watermark").x == 0.5, "hud move"); check(has(sh.exec("hud move watermark a b"), "numbers"), "hud move rejects text");
        sh.exec("hud move watermark 7 -3"); check(hud.get("watermark").x == 1.0 && hud.get("watermark").y == 0.0, "hud move clamps into the screen");
        sh.exec("hud toggle fps"); check(!hud.get("fps").enabled, "hud toggle"); check(has(sh.exec("hud toggle zzz"), "Usage"), "hud toggle unknown id");
        // persistence including friends and hud layout
        sh.exec("hud move watermark 0.5 0.25"); mm.get("fly").setKeybind(71); sh.exec("set crystal-aura min-damage 7");
        check(has(sh.exec("save p1"), "Saved") && has(sh.exec("profiles"), "p1"), "save a profile");
        fr.remove("bob"); sh.exec("hud reset"); mm.get("fly").setKeybind(-1); sh.exec("set crystal-aura min-damage 3"); mm.get("fly").setEnabled(false);
        check(has(sh.exec("load p1"), "Loaded"), "load a profile");
        check(fr.isFriend("Bob") && hud.get("watermark").x == 0.5 && hud.get("watermark").y == 0.25 && !hud.get("fps").enabled, "profile restores friends and HUD layout");
        check(mm.get("fly").keybind() == 71 && ((Setting.Num) mm.get("crystal-aura").setting("min-damage")).get() == 7.0 && mm.get("fly").isEnabled(), "profile restores keybinds, settings and enabled state");
        check(has(sh.exec("load nothere"), "does not exist"), "loading a missing profile reports it"); check(has(sh.exec("save ../evil"), "Save failed"), "path traversal in profile names is rejected");
        check(has(sh.exec("delete p1"), "Deleted") && !cfg.profiles().contains("p1"), "delete a profile");
        sh.exec("panic"); boolean any = false; for (Module m : mm.all()) any |= m.isEnabled(); check(!any, "panic disables everything");
        check(has(sh.exec("resetall"), "reset"), "resetall"); check(has(sh.exec("wat"), "Unknown command"), "unknown command");
        check(sh.exec("search crystal").size() >= 1 && has(sh.exec("search crystal"), "crystal-aura"), "search finds modules");
    }

    static void modules() {
        FriendManager fr = new FriendManager();
        // AutoCity
        NewModuleTest.G g = foe(3.5, 0.5); for (int[] s : new int[][]{{4, 0}, {2, 0}, {3, 1}, {3, -1}}) g.walls.add(k(s[0], 64, s[1]));
        AutoCity ac = new AutoCity(g, fr); ModuleManager mm = reg(ac); ac.setEnabled(true); mm.tick();
        check(g.count("break 2,64,0") == 1, "auto city mines the nearest block of the enemy's surround"); mm.tick(); check(g.count("break") == 1, "auto city stops once the enemy is exposed");
        ac.onlyIfSurrounded.set(false); mm.tick(); check(g.count("break") == 2, "auto city continues when only-if-surrounded is off");
        g = foe(3.5, 0.5); for (int[] s : new int[][]{{4, 0}, {2, 0}, {3, 1}}) g.walls.add(k(s[0], 64, s[1])); ac = new AutoCity(g, fr); mm = reg(ac); ac.setEnabled(true); mm.tick(); check(g.count("break") == 0, "auto city waits while a side is open");
        g = foe(3.5, 0.5); for (int[] s : new int[][]{{4, 0}, {2, 0}, {3, 1}, {3, -1}}) { g.walls.add(k(s[0], 64, s[1])); g.unbreakable.add(s[0] + ",64," + s[1]); } ac = new AutoCity(g, fr); mm = reg(ac); ac.setEnabled(true); mm.tick(); check(g.count("break") == 0, "auto city never tries unbreakable blocks");
        g = foe(3.5, 0.5); for (int[] s : new int[][]{{4, 0}, {2, 0}, {3, 1}, {3, -1}}) g.walls.add(k(s[0], 64, s[1])); fr.add("foe"); ac = new AutoCity(g, fr); mm = reg(ac); ac.setEnabled(true); mm.tick(); check(g.count("break") == 0, "auto city spares friends"); fr.clear();
        // ShieldBreaker
        g = foe(0.5, 2.5); g.crosshair = 9; g.blocking.add(9); g.hotbar[3] = ItemKind.AXE; ShieldBreaker sb = new ShieldBreaker(g, fr); mm = reg(sb); sb.setEnabled(true); mm.tick();
        check(g.count("select 3") == 1 && g.count("attack 9") == 1 && g.sel == 0, "shield breaker swaps to an axe, hits, and restores the slot");
        g.log.clear(); g.blocking.clear(); mm.tick(); check(g.count("attack") == 0, "shield breaker ignores players who are not blocking");
        g = foe(0.5, 2.5); g.crosshair = 9; g.blocking.add(9); sb = new ShieldBreaker(g, fr); mm = reg(sb); sb.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "shield breaker needs an axe");
        g = foe(0.5, 2.5); g.crosshair = 9; g.blocking.add(9); g.hotbar[3] = ItemKind.AXE; g.cooldown = 0.3f; sb = new ShieldBreaker(g, fr); mm = reg(sb); sb.setEnabled(true); mm.tick(); check(g.count("attack") == 0, "shield breaker waits for the cooldown");
        g = foe(0.5, 2.5); g.crosshair = 9; g.blocking.add(9); g.hotbar[3] = ItemKind.AXE; fr.add("foe"); sb = new ShieldBreaker(g, fr); mm = reg(sb); sb.setEnabled(true); mm.tick(); check(g.count("attack") == 0, "shield breaker spares friends"); fr.clear();
        // Jesus
        g = world(); g.liquids.add("0,64,0"); g.inWater = true; Jesus je = new Jesus(g); mm = reg(je); je.setEnabled(true); mm.tick(); check(g.vel != null && g.vel.y() >= 0.1, "jesus lifts you at the surface");
        g.vel = null; g.sneaking = true; mm.tick(); check(g.vel == null, "jesus lets you sink while sneaking"); g.sneaking = false;
        g.liquids.add("0,65,0"); mm.tick(); check(g.vel == null, "jesus does nothing when you are fully submerged"); g.liquids.remove("0,65,0");
        g.inWater = false; mm.tick(); check(g.vel == null, "jesus ignores lava by default"); je.lava.set(true); mm.tick(); check(g.vel != null, "jesus floats on lava when enabled");
        g = world(); je = new Jesus(g); mm = reg(je); je.setEnabled(true); mm.tick(); check(g.vel == null, "jesus idle on dry land");
        // ReverseStep
        g = world(); ReverseStep rs = new ReverseStep(g); mm = reg(rs); rs.setEnabled(true); mm.tick(); g.me = NewModuleTest.body(0.5, 64, 0.5, 0, -0.08, 0, false); g.removed.add("0,63,0"); mm.tick();
        check(g.vel != null && g.vel.y() <= -0.79, "reverse step pulls you down off a short ledge");
        g = world(); rs = new ReverseStep(g); mm = reg(rs); rs.setEnabled(true); mm.tick(); g.me = NewModuleTest.body(0.5, 64, 0.5, 0, 0.42, 0, false); g.removed.add("0,63,0"); mm.tick(); check(g.vel == null, "reverse step ignores jumps");
        g = world(); rs = new ReverseStep(g); mm = reg(rs); rs.maxDrop.set(1.0); rs.setEnabled(true); mm.tick(); g.me = NewModuleTest.body(0.5, 64, 0.5, 0, -0.08, 0, false); g.removed.add("0,63,0"); g.removed.add("0,62,0"); mm.tick(); check(g.vel == null, "reverse step ignores drops bigger than max-drop");
        g = world(); rs = new ReverseStep(g); mm = reg(rs); rs.setEnabled(true); mm.tick(); g.me = NewModuleTest.body(0.5, 64, 0.5, 0, -0.08, 0, false); mm.tick(); check(g.vel == null, "reverse step does nothing when ground is directly below");
        // ElytraAutopilot
        g = world(); g.glide = true; g.yaw = 90; g.me = NewModuleTest.body(0.5, 100, 0.5, 0, -0.5, 0, false); ElytraAutopilot ea = new ElytraAutopilot(g); mm = reg(ea); ea.targetX.set(0.5); ea.targetZ.set(300.0); ea.setEnabled(true); mm.tick();
        check(Math.abs(g.lastYaw - 84f) < 0.5f && g.lastPitch < 0 && g.lastPitch >= -6.01f, "autopilot turns toward the target by the turn rate and pulls up when sinking (yaw " + g.lastYaw + ", pitch " + g.lastPitch + ")");
        g = world(); g.glide = true; ea = new ElytraAutopilot(g); mm = reg(ea); ea.targetX.set(3.0); ea.targetZ.set(3.0); ea.setEnabled(true); mm.tick(); check(!ea.isEnabled() && g.isEnabledMsg("arrived"), "autopilot announces arrival and turns off");
        g = world(); ea = new ElytraAutopilot(g); mm = reg(ea); ea.targetZ.set(500.0); ea.setEnabled(true); mm.tick(); check(g.log.isEmpty() && ea.isEnabled(), "autopilot waits until you are gliding");
        // TunnelMiner
        g = world(); g.yaw = 0; g.walls.add(k(0, 64, 1)); g.walls.add(k(0, 65, 1)); g.walls.add(k(0, 64, 2)); TunnelMiner tm = new TunnelMiner(g); mm = reg(tm); tm.setEnabled(true); mm.tick();
        check(g.count("break 0,65,1") == 1, "tunnel miner digs the nearest block in front first"); mm.tick(); mm.tick(); mm.tick(); check(g.removed.containsAll(List.of("0,64,1", "0,65,1", "0,64,2")) && g.count("break") == 3, "tunnel miner clears the whole tunnel, one block per tick");
        g = world(); g.yaw = -90; g.walls.add(k(1, 64, 0)); tm = new TunnelMiner(g); mm = reg(tm); tm.setEnabled(true); mm.tick(); check(g.count("break 1,64,0") == 1, "tunnel miner follows the facing direction (+X at yaw -90)");
        g = world(); g.yaw = 0; g.walls.add(k(1, 64, 1)); tm = new TunnelMiner(g); mm = reg(tm); tm.setEnabled(true); mm.tick(); check(g.count("break") == 0, "tunnel miner (width 1) ignores blocks beside the tunnel");
        tm.width.set(3.0); mm.tick(); check(g.count("break 1,64,1") == 1, "tunnel miner width 3 includes side blocks");
        g = world(); g.yaw = 0; g.walls.add(k(0, 64, 1)); g.unbreakable.add("0,64,1"); tm = new TunnelMiner(g); mm = reg(tm); tm.setEnabled(true); mm.tick(); check(g.count("break") == 0, "tunnel miner skips unbreakable blocks");
        g = world(); g.yaw = 0; g.walls.add(k(0, 64, 1)); tm = new TunnelMiner(g); mm = reg(tm); tm.walk.set(true); tm.setEnabled(true); mm.tick(); check(!g.forced, "tunnel miner does not walk while blocks are in the way");
        mm.tick(); check(g.forced, "tunnel miner walks once the way ahead is clear"); tm.setEnabled(false); check(!g.forced, "tunnel miner releases forward on disable");
        // VeinMiner
        g = world(); g.target = new BlockPos(1, 64, 0); g.mining = true;
        for (int[] b : new int[][]{{1, 64, 0}, {2, 64, 0}, {1, 65, 0}, {2, 66, 1}}) { g.walls.add(k(b[0], b[1], b[2])); g.blockIdMap.put(b[0] + "," + b[1] + "," + b[2], "minecraft:diamond_ore"); }
        g.walls.add(k(2, 65, 1)); VeinMiner vm = new VeinMiner(g); mm = reg(vm); vm.setEnabled(true); mm.tick(); check(g.count("break") == 0, "vein miner waits for you to break the first block");
        g.removed.add("1,64,0"); g.mining = false; g.target = null; mm.tick(); mm.tick(); mm.tick();
        check(g.removed.contains("2,64,0") && g.removed.contains("1,65,0") && g.count("break") == 3 || (g.removed.contains("2,64,0") && g.removed.contains("1,65,0") && g.removed.contains("2,66,1")), "vein miner mines the connected ore after your first break");
        check(!g.removed.contains("2,65,1"), "vein miner never touches different blocks");
        g = world(); g.target = new BlockPos(1, 64, 0); g.mining = true; g.walls.add(k(1, 64, 0)); g.walls.add(k(2, 64, 0)); g.blockIdMap.put("1,64,0", "minecraft:dirt"); g.blockIdMap.put("2,64,0", "minecraft:dirt"); vm = new VeinMiner(g); mm = reg(vm); vm.setEnabled(true); mm.tick(); g.removed.add("1,64,0"); g.mining = false; mm.tick(); mm.tick(); check(g.count("break") == 0, "vein miner ignores blocks that do not match the filter");
        g = world(); g.target = new BlockPos(1, 64, 0); g.mining = true; for (int x = 1; x <= 4; x++) { g.walls.add(k(x, 64, 0)); g.blockIdMap.put(x + ",64,0", "minecraft:iron_ore"); } vm = new VeinMiner(g); mm = reg(vm); vm.maxBlocks.set(2.0); vm.setEnabled(true); mm.tick(); g.removed.add("1,64,0"); g.mining = false; g.target = null; for (int i = 0; i < 6; i++) mm.tick(); check(g.count("break") == 2, "vein miner honours max-blocks, got " + g.count("break"));
        g = world(); g.target = new BlockPos(1, 64, 0); g.mining = true; g.walls.add(k(1, 64, 0)); g.walls.add(k(2, 64, 0)); g.blockIdMap.put("1,64,0", "minecraft:gold_ore"); g.blockIdMap.put("2,64,0", "minecraft:gold_ore"); vm = new VeinMiner(g); mm = reg(vm); vm.setEnabled(true); mm.tick(); g.mining = false; g.target = null; mm.tick(); mm.tick(); check(g.count("break") == 0, "vein miner does nothing if you stop mining before the block breaks");
        // BlockNotifier
        g = world(); g.walls.add(k(5, 64, 5)); g.blockIdMap.put("5,64,5", "minecraft:diamond_ore"); BlockNotifier bn = new BlockNotifier(g); mm = reg(bn); bn.range.set(8.0); bn.perTick.set(500.0); bn.setEnabled(true);
        for (int i = 0; i < 12; i++) mm.tick(); check(g.count("msg Found diamond_ore at 5 64 5") == 1, "block notifier reports a matching block once");
        for (int i = 0; i < 30; i++) mm.tick(); check(g.count("msg Found") == 1, "block notifier does not repeat itself on later sweeps");
        g = world(); g.walls.add(k(8, 72, 8)); g.blockIdMap.put("8,72,8", "minecraft:diamond_ore"); bn = new BlockNotifier(g); mm = reg(bn); bn.range.set(8.0); bn.perTick.set(500.0); bn.setEnabled(true);
        for (int i = 0; i < 5; i++) mm.tick(); check(g.count("msg Found") == 0, "block notifier spreads the scan over several ticks (per-tick budget)"); for (int i = 0; i < 8; i++) mm.tick(); check(g.count("msg Found") == 1, "block notifier finds the block once the sweep reaches it");
        g = world(); g.walls.add(k(5, 64, 5)); g.blockIdMap.put("5,64,5", "minecraft:diamond_ore"); bn = new BlockNotifier(g); mm = reg(bn); bn.range.set(8.0); bn.perTick.set(2000.0); bn.blocks.set("emerald"); bn.setEnabled(true); for (int i = 0; i < 5; i++) mm.tick(); check(g.count("msg Found") == 0, "block notifier only reports configured blocks");
        bn.blocks.set(""); for (int i = 0; i < 5; i++) mm.tick(); check(g.count("msg") == 0 && bn.isEnabled(), "block notifier with an empty list is idle");
        g = world(); g.walls.add(k(5, 64, 5)); g.blockIdMap.put("5,64,5", "minecraft:diamond_ore"); g.unloadedChunks.add(0L); bn = new BlockNotifier(g); mm = reg(bn); bn.range.set(8.0); bn.perTick.set(2000.0); bn.setEnabled(true); for (int i = 0; i < 5; i++) mm.tick(); check(g.count("msg Found") == 0 && bn.isEnabled(), "block notifier skips unloaded chunks");
        // Hud additions
        g = world(); ModuleManager hm = new ModuleManager(s -> {}); Fly fl = new Fly(g); hm.register(fl); fl.setKeybind(71); fl.setEnabled(true); Hud hud = new Hud(); Hud.Ctx ctx = new Hud.Ctx(g, hm);
        check(hud.get("keybinds").lines(ctx).equals(List.of("Fly [G]")), "HUD keybind list shows enabled bound modules"); check(hud.get("ping").lines(ctx).equals(List.of("Ping: n/a")), "HUD ping without a value"); check(hud.get("fps").lines(ctx).size() == 1, "HUD fps element");
        g.armorDur = 0.5f; check(hud.get("durability").lines(ctx).equals(List.of("Armor: 50%")), "HUD armor durability"); g.inWorld = false; check(hud.get("fps").lines(ctx).isEmpty() && hud.get("durability").lines(ctx).isEmpty(), "HUD elements are empty outside a world");
    }
}
