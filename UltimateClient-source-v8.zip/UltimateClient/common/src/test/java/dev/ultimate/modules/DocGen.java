package dev.ultimate.modules;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import java.nio.file.*;
import java.util.*;

/** Generates docs/MODULES.md and default-config/default.json from the real module registry, so the docs cannot drift from the code. */
public final class DocGen {
    public static void main(String[] a) throws Exception {
        Path root = Path.of(a[0]);
        ModuleManager mm = new ModuleManager(s -> {}); Modules.registerAll(mm, new ModuleTest.FakeGame(), new FriendManager());
        StringBuilder sb = new StringBuilder("# Module reference (generated from the code)\n\n" + mm.all().size() + " modules. All start disabled with no keybind. Set values with `/uc set <module> <setting> <value>`.\n"
            + "Visual (Render) modules describe what to draw; **a world renderer is not written yet, so ESP-style modules show nothing in-game** (see STATUS.md).\n");
        for (Category c : Category.values()) {
            List<Module> l = mm.inCategory(c); if (l.isEmpty()) continue;
            sb.append("\n## ").append(c.label).append(" (").append(l.size()).append(")\n");
            for (Module m : l) {
                sb.append("\n### ").append(m.name).append(" (`").append(m.id).append("`)\n").append(m.description).append("\n\n");
                if (m.settings().isEmpty()) sb.append("_No settings._\n");
                for (Setting<?> s : m.settings()) {
                    String range = s instanceof Setting.Num n ? " [" + fmt(n.min) + " to " + fmt(n.max) + "]" : s instanceof Setting.Mode md ? " " + md.modes : "";
                    Object d = s.defaultValue(); String dv = d instanceof Double x ? fmt(x) : String.valueOf(d);
                    if (s instanceof Setting.Color) dv = String.format("#%08X", ((Integer) d));
                    sb.append("- `").append(s.id).append("` = ").append(dv).append(range).append(" - ").append(s.description).append('\n');
                }
            }
        }
        Files.createDirectories(root.resolve("docs")); Files.writeString(root.resolve("docs/MODULES.md"), sb.toString());
        Path cfg = root.resolve("default-config"); Files.createDirectories(cfg); Files.deleteIfExists(cfg.resolve("default.json"));
        new ConfigManager(cfg, mm).save("default");
        System.out.println(mm.all().size() + " modules documented");
    }
    static String fmt(double d) { return d == Math.rint(d) ? String.valueOf((long) d) : String.valueOf(d); }
}
