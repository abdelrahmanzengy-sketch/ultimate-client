package dev.ultimate.modules;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;
import dev.ultimate.modules.combat.*;
import dev.ultimate.modules.movement.*;
import dev.ultimate.modules.player.*;
import dev.ultimate.modules.world.*;
import dev.ultimate.modules.render.*;
import dev.ultimate.modules.misc.*;

import java.util.*;

/** Behaviour tests for the v4 modules, run against a fake Game (no Minecraft involved). */
final class NewModuleTest {
    private NewModuleTest() {}
    static void check(boolean c, String m) { ModuleTest.check(c, m); }

    /** FakeGame plus everything the v4 Game methods need. */
    static class G extends ModuleTest.FakeGame {
        float pitch; boolean jumpIn, sneakIn, hcol, climb, glide, raining, dark, voidWorld, bobberOut, bobberDip, nv;
        int crosshair = -1, bestTool = -1, fovVal = 70; float stepH = 0.6f, armorDur = 1f; BlockPos target;
        Map<BlockPos, Integer> charges = new HashMap<>(); Set<String> liquids = new HashSet<>(), removed = new HashSet<>(), unbreakable = new HashSet<>();
        List<String> chat = new ArrayList<>(); String[] ids = new String[36]; int[] counts = new int[36]; int[] betterArmor = {-1, -1, -1, -1};
        ItemKind chestKind = ItemKind.CHESTPLATE; float lastYaw = Float.NaN, lastPitch = Float.NaN; int swapChest = -1;
        G() { Arrays.fill(ids, ""); }
        static String key(int x, int y, int z) { return x + "," + y + "," + z; }
        @Override public boolean isSolid(int x, int y, int z) {
            if (removed.contains(key(x, y, z))) return false;
            if (voidWorld && y < 64) return walls.contains(k(x, y, z));
            return super.isSolid(x, y, z);
        }
        Set<Integer> blocking = new HashSet<>(); Map<String, String> blockIdMap = new HashMap<>(); boolean screen; Set<Integer> heldKeys = new HashSet<>();
        @Override public boolean isBlocking(int id) { return blocking.contains(id); }
        @Override public String blockId(int x, int y, int z) { String o = blockIdMap.get(key(x, y, z)); if (o != null) return isSolid(x, y, z) ? o : ""; return isSolid(x, y, z) ? "minecraft:stone" : ""; }
        @Override public boolean keyDown(int k) { return heldKeys.contains(k); } @Override public boolean screenOpen() { return screen; }
        @Override public float pitch() { return pitch; }
        @Override public void setRotation(float y, float p) { yaw = y; pitch = p; lastYaw = y; lastPitch = p; log.add("rot " + (int) y + "," + (int) p); }
        @Override public void setJumpInput(boolean on) { jumpIn = on; }
        @Override public void setSneakInput(boolean on) { sneakIn = on; }
        @Override public void useItem() { log.add("use"); }
        @Override public int crosshairEntity() { return crosshair; }
        @Override public boolean horizontalCollision() { return hcol; }
        @Override public boolean onClimbable() { return climb; }
        @Override public boolean gliding() { return glide; }
        @Override public boolean breakBlock(BlockPos p) { log.add("break " + p.x() + "," + p.y() + "," + p.z()); removed.add(key(p.x(), p.y(), p.z())); return true; }
        @Override public boolean interactBlock(BlockPos p) {
            log.add("interact " + p.x() + "," + p.y() + "," + p.z());
            Integer c = charges.get(p); if (c == null) return false;
            if (mainHand() == ItemKind.GLOWSTONE) charges.put(p, Math.min(4, c + 1)); else charges.remove(p);
            return true;
        }
        @Override public boolean isLiquid(int x, int y, int z) { return liquids.contains(key(x, y, z)); }
        @Override public boolean isBreakable(int x, int y, int z) { return !unbreakable.contains(key(x, y, z)); }
        @Override public int lightLevel(int x, int y, int z) { return dark ? 0 : 15; }
        @Override public int anchorCharges(BlockPos p) { return charges.getOrDefault(p, -1); }
        @Override public BlockPos targetBlock() { return target; }
        @Override public int bestToolSlotFor(BlockPos p) { return bestTool; }
        @Override public void setNightVision(boolean on) { nv = on; }
        @Override public int fov() { return fovVal; } @Override public void setFov(int f) { fovVal = f; }
        @Override public float stepHeight() { return stepH; } @Override public void setStepHeight(float h) { stepH = h; log.add("step " + h); }
        @Override public boolean raining() { return raining; }
        @Override public void sendChat(String t) { chat.add(t); }
        @Override public boolean fishBobberDipping() { return bobberDip; } @Override public boolean fishBobberOut() { return bobberOut; }
        @Override public float armorDurability() { return armorDur; }
        @Override public int stackCount(int s) { return counts[s]; }
        @Override public ItemKind kindAt(int s) { return s < 9 ? hotbar[s] : main[s - 9]; }
        @Override public String itemId(int s) { return ids[s]; }
        @Override public void mergeIntoHotbar(int m, int h) { log.add("merge " + m + "->" + h); }
        @Override public int betterArmorSlot(int i) { return betterArmor[i]; }
        @Override public void equipArmor(int s, int i) { log.add("equip " + s + " " + i); }
        @Override public ItemKind chest() { return chestKind; }
        @Override public void swapWithChest(int s) { swapChest = s; log.add("chest " + s); }
    }

    static EntityInfo body(double x, double y, double z, double vx, double vy, double vz, boolean ground) {
        return new EntityInfo(0, EntityInfo.Kind.PLAYER, "me", new Vec3(x, y, z), new Vec3(vx, vy, vz), 0.6, 1.8, 20f, 0f, 0, 0, 0, -1, ground);
    }
    static G world() { G g = new G(); g.me = body(0.5, 64, 0.5, 0, 0, 0, true); return g; }
    static G geared(G g) { g.me = new EntityInfo(0, EntityInfo.Kind.PLAYER, "me", new Vec3(.5, 64, .5), Vec3.ZERO, .6, 1.8, 20f, 0f, 20, 12, 16, -1, true); return g; }
    static G withFoe(double x, double z) { G g = world(); g.ents.add(ModuleTest.FakeGame.player(9, "foe", x, 64, z)); return g; }
    static ModuleManager reg(Module... ms) { return ModuleTest.reg(ms); }

    static void run() {
        combat(); movement(); player(); misc(); worldMods(); sweep();
    }

    // ------------------------------------------------------------------------------------------------ combat
    static void combat() {
        FriendManager fr = new FriendManager();
        // AutoWeapon
        G g = withFoe(0.5, 2.5); g.hotbar[1] = ItemKind.SWORD; g.crosshair = 9; AutoWeapon aw = new AutoWeapon(g); ModuleManager mm = reg(aw); aw.setEnabled(true); mm.tick();
        check(g.sel == 1, "auto weapon selects sword when aiming at entity");
        g.crosshair = -1; mm.tick(); check(g.sel == 0, "auto weapon restores slot afterwards");
        g = withFoe(0.5, 2.5); g.crosshair = 9; aw = new AutoWeapon(g); mm = reg(aw); aw.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "auto weapon: no weapon in hotbar does nothing");
        g = withFoe(0.5, 2.5); g.hotbar[5] = ItemKind.SWORD; g.crosshair = 9; aw = new AutoWeapon(g); mm = reg(aw); aw.prefer.set("Axe"); aw.setEnabled(true); mm.tick(); check(g.sel == 5, "auto weapon falls back to the other weapon type");
        aw.setEnabled(false); check(g.sel == 0, "auto weapon restores slot on disable");

        // AimAssist
        g = withFoe(0.5, 4.5); AimAssist aa = new AimAssist(g, fr); mm = reg(aa); aa.setEnabled(true); mm.tick();
        check(g.lastPitch > 0 && g.lastPitch <= 4.01f && Math.abs(g.lastYaw) < 0.01f, "aim assist nudges pitch toward target, limited to speed (pitch " + g.lastPitch + ")");
        g = withFoe(4.5, 0.5); aa = new AimAssist(g, fr); mm = reg(aa); aa.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "aim assist ignores targets outside the fov cone");
        aa.fov.set(360.0); mm.tick(); check(g.lastYaw < -3.9f && g.lastYaw >= -4.01f, "aim assist turns toward target by max speed (yaw " + g.lastYaw + ")");
        fr.add("foe"); g.log.clear(); mm.tick(); check(g.log.isEmpty(), "aim assist ignores friends"); fr.clear();
        g = withFoe(0.5, 30.5); aa = new AimAssist(g, fr); mm = reg(aa); aa.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "aim assist ignores far players");
        g = withFoe(0.5, 4.5); aa = new AimAssist(g, fr); mm = reg(aa); aa.onlyWithWeapon.set(true); aa.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "aim assist weapon-only mode");

        // TriggerBot
        g = withFoe(0.5, 2.5); g.crosshair = 9; TriggerBot tb = new TriggerBot(g, fr); mm = reg(tb); tb.setEnabled(true); mm.tick(); check(g.count("attack 9") == 1, "trigger bot hits crosshair player");
        g.log.clear(); g.cooldown = 0.5f; mm.tick(); check(g.count("attack") == 0, "trigger bot waits for cooldown");
        g.cooldown = 1f; fr.add("foe"); mm.tick(); check(g.count("attack") == 0, "trigger bot spares friends"); fr.clear();
        g.crosshair = 77; g.ents.add(new EntityInfo(77, EntityInfo.Kind.HOSTILE, "zombie", new Vec3(0.5, 64, 2.5), Vec3.ZERO, .6, 1.8, 20, 0, 0, 0, 0, -1, true));
        mm.tick(); check(g.count("attack") == 0, "trigger bot ignores mobs by default"); tb.mobs.set(true); mm.tick(); check(g.count("attack 77") == 1, "trigger bot hits mobs when enabled");

        // AutoEXP
        g = world(); g.armorDur = 0.5f; g.hotbar[4] = ItemKind.EXP_BOTTLE; AutoEXP ae = new AutoEXP(g); mm = reg(ae); ae.setEnabled(true); mm.tick();
        check(g.count("use") == 1 && g.count("rot 0,90") == 1 && g.sel == 0 && g.pitch == 0f, "auto exp throws a bottle downward and restores slot and view");
        g.log.clear(); g.tick = 1; ae.delay.set(5.0); mm.tick(); check(g.count("use") == 0, "auto exp delay honoured");
        g = world(); g.armorDur = 1f; g.hotbar[4] = ItemKind.EXP_BOTTLE; ae = new AutoEXP(g); mm = reg(ae); ae.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "auto exp idle with undamaged armor");
        g = withFoe(3.5, 0.5); g.armorDur = 0.2f; g.hotbar[4] = ItemKind.EXP_BOTTLE; ae = new AutoEXP(g); mm = reg(ae); ae.setEnabled(true); mm.tick(); check(g.count("use") == 0, "auto exp pauses with an enemy close");
        g = world(); g.armorDur = 0.2f; ae = new AutoEXP(g); mm = reg(ae); ae.setEnabled(true); mm.tick(); check(g.log.isEmpty() && ae.isEnabled(), "auto exp without bottles: nothing, no error");

        // AutoArmor
        g = world(); g.betterArmor[3] = 20; AutoArmor ar = new AutoArmor(g); mm = reg(ar); ar.setEnabled(true); mm.tick(); check(g.count("equip 20 3") == 1, "auto armor equips better helmet");
        g.betterArmor[3] = 21; g.tick = 1; ar.delay.set(5.0); g.log.clear(); mm.tick(); check(g.log.isEmpty(), "auto armor delay honoured"); g.tick = 9; mm.tick(); check(g.count("equip 21 3") == 1, "auto armor continues after delay");
        g = world(); g.chestKind = ItemKind.ELYTRA; g.betterArmor[2] = 12; ar = new AutoArmor(g); mm = reg(ar); ar.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "auto armor never replaces an elytra");
        g = world(); g.using = true; g.betterArmor[1] = 13; ar = new AutoArmor(g); mm = reg(ar); ar.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "auto armor waits while using an item");
        g = world(); g.betterArmor[0] = 14; ar = new AutoArmor(g); mm = reg(ar); ar.feet.set(false); ar.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "auto armor respects slot toggles");

        // AnchorAura
        g = geared(withFoe(4.5, 0.5)); g.hotbar[2] = ItemKind.RESPAWN_ANCHOR; AnchorAura an = new AnchorAura(g, fr); mm = reg(an); an.setEnabled(true);
        an.minDamage.set(1.0); an.maxSelfDamage.set(36.0); an.range.set(6.0); mm.tick();
        check(g.count("block ") == 1 && g.count("select 2") == 1 && g.sel == 0, "anchor aura places an anchor from the hotbar and restores slot");
        check(an.hudTarget.isEmpty() || an.hudTarget.equals("foe"), "anchor aura hud sane");
        g = geared(withFoe(4.5, 0.5)); g.hotbar[2] = ItemKind.RESPAWN_ANCHOR; an = new AnchorAura(g, fr); mm = reg(an); an.setEnabled(true); an.maxSelfDamage.set(0.0); an.range.set(6.0); an.minDamage.set(1.0); mm.tick();
        check(g.count("block ") == 0, "anchor aura self-damage limit blocks placement");
        // existing anchor: charge then detonate
        g = geared(withFoe(4.5, 0.5)); g.hotbar[6] = ItemKind.GLOWSTONE; BlockPos ap = new BlockPos(5, 64, 0); g.charges.put(ap, 0);
        an = new AnchorAura(g, fr); mm = reg(an); an.setEnabled(true); an.minDamage.set(1.0); an.maxSelfDamage.set(36.0); an.range.set(6.0); an.delay.set(0.0); mm.tick();
        check(g.charges.get(ap) == 1 && g.count("select 6") == 1 && g.sel == 0, "anchor aura charges with glowstone");
        g.log.clear(); mm.tick(); check(g.count("interact 5,64,0") == 1 && !g.charges.containsKey(ap), "anchor aura detonates a charged anchor with a non-glowstone item");
        g = geared(withFoe(4.5, 0.5)); g.charges.put(ap, 0); an = new AnchorAura(g, fr); mm = reg(an); an.setEnabled(true); an.minDamage.set(1.0); an.maxSelfDamage.set(36.0); an.range.set(6.0); mm.tick();
        check(g.isEnabledMsg("no glowstone") && an.isEnabled(), "anchor aura reports missing glowstone without crashing");
        g = world(); an = new AnchorAura(g, fr); mm = reg(an); an.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "anchor aura: no target does nothing");
        g = withFoe(4.5, 0.5); g.hotbar[2] = ItemKind.RESPAWN_ANCHOR; an = new AnchorAura(g, fr); mm = reg(an); an.setEnabled(true); an.minDamage.set(1.0); an.maxSelfDamage.set(36.0); an.range.set(6.0); mm.tick();
        check(g.count("block ") == 0, "anchor aura refuses when the blast would kill an ungeared player (vanilla formula: 27 dmg at 5 blocks)");

        // 
    }

    // ---------------------------------------------------------------------------------------------- movement
    static void movement() {
        // Step
        G g = world(); Step st = new Step(g); ModuleManager mm = reg(st); st.setEnabled(true); mm.tick(); check(g.stepH == 1.0f, "step raises step height");
        st.setEnabled(false); check(Math.abs(g.stepH - 0.6f) < 1e-6, "step restores original height on disable");
        // SafeWalk
        g = world(); g.me = body(0.5, 64, 0.5, 0.4, 0, 0, true); g.fwd = true; g.removed.add("1,63,0"); g.removed.add("1,62,0");
        SafeWalk sw = new SafeWalk(g); mm = reg(sw); sw.setEnabled(true); mm.tick(); check(g.sneakIn, "safe walk sneaks at a ledge");
        g.removed.clear(); mm.tick(); check(!g.sneakIn, "safe walk releases sneak when ground is back");
        g.removed.add("1,63,0"); g.removed.add("1,62,0"); mm.tick(); sw.setEnabled(false); check(!g.sneakIn, "safe walk releases sneak on disable");
        g.fwd = false; mm.tick(); check(!g.sneakIn, "safe walk idle when not moving");
        // AutoJump
        g = world(); g.fwd = true; g.walls.add(ModuleTest.FakeGame.k(0, 64, 1)); AutoJump aj = new AutoJump(g); mm = reg(aj); aj.setEnabled(true); mm.tick(); check(g.jumpIn, "auto jump hops a one-block wall");
        mm.tick(); check(!g.jumpIn, "auto jump releases the key next tick");
        g.walls.add(ModuleTest.FakeGame.k(0, 65, 1)); g.walls.add(ModuleTest.FakeGame.k(0, 66, 1)); mm.tick(); mm.tick(); check(!g.jumpIn, "auto jump ignores walls that are too tall");
        // Spider
        g = world(); g.fwd = true; Spider sp = new Spider(g); mm = reg(sp); sp.setEnabled(true); mm.tick(); check(g.vel == null, "spider idle without wall contact");
        g.hcol = true; mm.tick(); check(g.vel != null && g.vel.y() > 0.19, "spider climbs when pushing on a wall");
        g.sneaking = true; mm.tick(); check(g.vel.y() == 0, "spider holds position while sneaking");
        // Sneak
        g = world(); Sneak sn = new Sneak(g); mm = reg(sn); sn.setEnabled(true); mm.tick(); check(g.sneakIn, "sneak holds sneak"); sn.setEnabled(false); check(!g.sneakIn, "sneak releases on disable");
        g = world(); sn = new Sneak(g); mm = reg(sn); sn.onlyWhenMoving.set(true); sn.setEnabled(true); mm.tick(); check(!g.sneakIn, "sneak (moving-only) idle while standing"); g.fwd = true; mm.tick(); check(g.sneakIn, "sneak (moving-only) sneaks while moving");
        // AntiVoid
        g = world(); g.voidWorld = true; g.me = body(0.5, -60, 0.5, 0.1, -1, 0, false); AntiVoid av = new AntiVoid(g); mm = reg(av); av.setEnabled(true); mm.tick();
        check(g.vel != null && g.vel.y() > 0.7 && Math.abs(g.vel.x() - 0.1) < 1e-9, "anti void lifts you and keeps horizontal speed");
        g = world(); g.me = body(0.5, -60, 0.5, 0, -1, 0, false); av = new AntiVoid(g); mm = reg(av); av.setEnabled(true); mm.tick(); check(g.vel == null, "anti void idle when ground is right below");
        g = world(); g.voidWorld = true; g.me = body(0.5, 10, 0.5, 0, -1, 0, false); av = new AntiVoid(g); mm = reg(av); av.setEnabled(true); mm.tick(); check(g.vel == null, "anti void idle above the trigger height");
        // ElytraFly
        g = world(); g.glide = true; g.fwd = true; g.yaw = 0; g.pitch = 0; ElytraFly ef = new ElytraFly(g); mm = reg(ef); ef.setEnabled(true); mm.tick();
        check(g.vel != null && Math.abs(g.vel.z() - 1.2) < 1e-6 && Math.abs(g.vel.y()) < 1e-6, "elytra fly flies along the view direction");
        g.pitch = 90; mm.tick(); check(g.vel.y() < -1.1, "elytra fly dives when looking down");
        g.fwd = false; g.jumping = true; mm.tick(); check(g.vel.y() > 0.4 && g.vel.z() == 0, "elytra fly climbs on jump"); g.jumping = false; mm.tick(); check(g.vel.y() < 0 && g.vel.y() > -0.05, "elytra fly hovers with a small sink");
        g.glide = false; g.vel = null; mm.tick(); check(g.vel == null, "elytra fly idle when not gliding");
        // FastClimb
        g = world(); g.climb = true; g.jumping = true; FastClimb fc = new FastClimb(g); mm = reg(fc); fc.setEnabled(true); mm.tick(); check(g.vel != null && g.vel.y() == 0.3, "fast climb speeds up ladders");
        g = world(); g.jumping = true; fc = new FastClimb(g); mm = reg(fc); fc.setEnabled(true); mm.tick(); check(g.vel == null, "fast climb idle off ladders");
        // Parkour
        g = world(); g.me = body(0.5, 64, 0.9, 0, 0, 0, true); g.fwd = true; g.removed.add("0,63,1"); g.removed.add("0,62,1"); Parkour pk = new Parkour(g); mm = reg(pk); pk.setEnabled(true); mm.tick();
        check(g.jumpIn, "parkour jumps at a ledge"); mm.tick(); check(!g.jumpIn, "parkour releases jump");
        g = world(); g.me = body(0.5, 64, 0.9, 0, 0, 0, true); g.fwd = true; pk = new Parkour(g); mm = reg(pk); pk.setEnabled(true); mm.tick(); check(!g.jumpIn, "parkour does not jump with ground ahead");
        // AirJump
        g = world(); g.me = body(0.5, 70, 0.5, 0.1, -0.2, 0, false); AirJump ajp = new AirJump(g); mm = reg(ajp); ajp.setEnabled(true); mm.tick(); check(g.vel == null, "air jump needs a jump press");
        g.jumping = true; mm.tick(); check(g.vel != null && g.vel.y() > 0.41, "air jump gives an extra jump");
        g.vel = null; g.jumping = false; mm.tick(); g.jumping = true; mm.tick(); check(g.vel == null, "air jump limited to configured jumps");
        g.me = body(0.5, 64, 0.5, 0, 0, 0, true); mm.tick(); g.me = body(0.5, 70, 0.5, 0, -0.2, 0, false); g.jumping = false; mm.tick(); g.jumping = true; mm.tick(); check(g.vel != null, "air jump resets after landing");
        // LongJump
        g = world(); g.fwd = true; LongJump lj = new LongJump(g); mm = reg(lj); lj.setEnabled(true); mm.tick();
        g.me = body(0.5, 64.1, 0.5, 0.0, 0.42, 0.2, false); mm.tick(); check(g.vel != null && Math.abs(g.vel.z() - 0.32) < 1e-9, "long jump boosts at take-off");
        g.vel = null; mm.tick(); check(g.vel == null, "long jump boosts only once per jump");
        // SlowFall
        g = world(); g.me = body(0.5, 80, 0.5, 0.1, -0.5, 0, false); SlowFall sf = new SlowFall(g); mm = reg(sf); sf.setEnabled(true); mm.tick(); check(g.vel != null && Math.abs(g.vel.y() + 0.1) < 1e-9 && g.vel.x() == 0.1, "slow fall caps fall speed");
        g.vel = null; g.me = body(0.5, 80, 0.5, 0, -0.05, 0, false); mm.tick(); check(g.vel == null, "slow fall leaves slow falls alone");
        g.me = body(0.5, 64, 0.5, 0, -0.5, 0, true); mm.tick(); check(g.vel == null, "slow fall idle on ground");
    }

    // -------------------------------------------------------------------------------------------------- player
    static void player() {
        FriendManager fr = new FriendManager();
        // AutoClicker
        G g = withFoe(0.5, 2.5); g.crosshair = 9; AutoClicker ac = new AutoClicker(g, fr); ModuleManager mm = reg(ac); ac.setEnabled(true); mm.tick(); check(g.count("attack 9") == 1, "auto clicker clicks target");
        mm.tick(); check(g.count("attack 9") == 1, "auto clicker rate limited"); g.tick = 4; mm.tick(); check(g.count("attack 9") == 2, "auto clicker clicks again after delay");
        g.tick = 20; fr.add("foe"); mm.tick(); check(g.count("attack") == 2, "auto clicker spares friends"); fr.clear();
        g = world(); g.ents.add(ModuleTest.FakeGame.crystal(20, 2, 64, 0)); g.crosshair = 20; ac = new AutoClicker(g, fr); mm = reg(ac); ac.setEnabled(true); mm.tick(); check(g.count("attack") == 0, "auto clicker never hits crystals");
        // AutoGap
        g = world(); g.me = new EntityInfo(0, EntityInfo.Kind.PLAYER, "me", new Vec3(.5, 64, .5), Vec3.ZERO, .6, 1.8, 8f, 0f, 0, 0, 0, -1, true); g.hotbar[3] = ItemKind.GOLDEN_APPLE;
        AutoGap ag = new AutoGap(g); mm = reg(ag); ag.setEnabled(true); mm.tick(); check(g.sel == 3 && g.useKey, "auto gap starts eating when hurt");
        for (int i = 0; i < 6; i++) mm.tick(); check(g.sel == 0 && !g.useKey, "auto gap stops and restores slot");
        g = world(); g.hotbar[3] = ItemKind.GOLDEN_APPLE; ag = new AutoGap(g); mm = reg(ag); ag.setEnabled(true); mm.tick(); check(g.sel == 0 && !g.useKey, "auto gap idle at full health");
        g = world(); g.me = new EntityInfo(0, EntityInfo.Kind.PLAYER, "me", new Vec3(.5, 64, .5), Vec3.ZERO, .6, 1.8, 8f, 4f, 0, 0, 0, -1, true); g.hotbar[3] = ItemKind.GOLDEN_APPLE; ag = new AutoGap(g); mm = reg(ag); ag.setEnabled(true); mm.tick(); check(!g.useKey, "auto gap skips while absorption is up");
        // AutoTool
        g = world(); g.mining = true; g.target = new BlockPos(1, 64, 0); g.bestTool = 4; AutoTool at = new AutoTool(g); mm = reg(at); at.setEnabled(true); mm.tick(); check(g.sel == 4, "auto tool picks best tool");
        g.mining = false; mm.tick(); check(g.sel == 0, "auto tool restores slot after mining");
        g = world(); g.mining = true; g.target = null; g.bestTool = 4; at = new AutoTool(g); mm = reg(at); at.setEnabled(true); mm.tick(); check(g.sel == 0, "auto tool without a target block does nothing");
        // AutoReplenish
        g = world(); g.ids[2] = "minecraft:obsidian"; g.counts[2] = 3; g.ids[13] = "minecraft:obsidian"; g.counts[13] = 64; g.ids[10] = "minecraft:stone"; g.counts[10] = 64;
        AutoReplenish rp = new AutoReplenish(g); mm = reg(rp); rp.setEnabled(true); mm.tick(); check(g.count("merge 13->2") == 1, "auto replenish refills from the identical stack");
        g = world(); g.ids[2] = "minecraft:obsidian"; g.counts[2] = 3; g.ids[10] = "minecraft:stone"; g.counts[10] = 64; rp = new AutoReplenish(g); mm = reg(rp); rp.setEnabled(true); mm.tick(); check(g.count("merge") == 0, "auto replenish never merges different items");
        g = world(); g.ids[2] = "minecraft:obsidian"; g.counts[2] = 40; g.ids[13] = "minecraft:obsidian"; g.counts[13] = 64; rp = new AutoReplenish(g); mm = reg(rp); rp.setEnabled(true); mm.tick(); check(g.count("merge") == 0, "auto replenish leaves full-enough stacks");
        // ChestSwap
        g = world(); g.chestKind = ItemKind.ELYTRA; g.main[2] = ItemKind.CHESTPLATE; ChestSwap cs = new ChestSwap(g); mm = reg(cs); cs.setEnabled(true); check(g.swapChest == 11 && !cs.isEnabled(), "chest swap elytra -> chestplate, then turns off");
        g = world(); g.chestKind = ItemKind.CHESTPLATE; g.hotbar[8] = ItemKind.ELYTRA; cs = new ChestSwap(g); mm = reg(cs); cs.setEnabled(true); check(g.swapChest == 8, "chest swap chestplate -> elytra from hotbar");
        g = world(); g.chestKind = ItemKind.CHESTPLATE; cs = new ChestSwap(g); mm = reg(cs); cs.setEnabled(true); check(g.swapChest == -1 && g.isEnabledMsg("no elytra") && !cs.isEnabled(), "chest swap reports a missing item");
        // AutoFish
        g = world(); g.hotbar[0] = ItemKind.FISHING_ROD; AutoFish af = new AutoFish(g); mm = reg(af); af.setEnabled(true); mm.tick(); check(g.count("use") == 1, "auto fish casts when no bobber is out");
        g.bobberOut = true; g.tick = 5; mm.tick(); check(g.count("use") == 1, "auto fish waits while the bobber floats");
        g.bobberDip = true; mm.tick(); check(g.count("use") == 2, "auto fish reels in on a bite");
        g.bobberOut = false; g.bobberDip = false; g.tick = 10; mm.tick(); check(g.count("use") == 2, "auto fish respects the recast delay"); g.tick = 40; mm.tick(); check(g.count("use") == 3, "auto fish recasts after the delay");
        g = world(); af = new AutoFish(g); mm = reg(af); af.setEnabled(true); mm.tick(); check(g.count("use") == 0, "auto fish needs a rod in hand");
    }

    // ----------------------------------------------------------------------------------------------- render/misc
    static void misc() {
        FriendManager fr = new FriendManager();
        G g = world(); Fullbright fb = new Fullbright(g);  ModuleManager mm = reg(fb); fb.setEnabled(true); check(g.nv, "fullbright on at enable"); g.nv = false; mm.tick(); check(g.nv, "fullbright refreshes each tick"); fb.setEnabled(false); check(!g.nv, "fullbright off at disable");
        g = world(); g.dark = false; fb = new Fullbright(g); mm = reg(fb); fb.darkBelow.set(8.0); fb.setEnabled(true); mm.tick(); check(!g.nv, "fullbright dark-only mode stays off in bright areas"); g.dark = true; mm.tick(); check(g.nv, "fullbright dark-only mode turns on in the dark");
        g = world(); Zoom z = new Zoom(g); mm = reg(z); z.setEnabled(true); mm.tick(); check(g.fovVal == 58, "zoom eases toward target (fov " + g.fovVal + ")");
        for (int i = 0; i < 5; i++) mm.tick(); check(g.fovVal == 30, "zoom reaches its target"); z.setEnabled(false); check(g.fovVal == 70, "zoom restores the original fov");
        // ChatMacro
        g = world(); ChatMacro cm = new ChatMacro(g); mm = reg(cm); cm.message.set("hello"); cm.setEnabled(true); check(g.chat.equals(List.of("hello")) && !cm.isEnabled(), "chat macro once: sends and turns off");
        g = world(); cm = new ChatMacro(g); mm = reg(cm); cm.setEnabled(true); check(g.chat.isEmpty() && g.isEnabledMsg("empty") && !cm.isEnabled(), "chat macro refuses an empty message");
        g = world(); cm = new ChatMacro(g); mm = reg(cm); cm.message.set("/spawn"); cm.mode.set("Repeat"); cm.interval.set(40.0); cm.setEnabled(true);
        g.tick = 10; mm.tick(); check(g.chat.size() == 1, "chat macro repeat waits for the interval"); g.tick = 40; mm.tick(); check(g.chat.size() == 2, "chat macro repeats after the interval");
        g.inWorld = false; g.tick = 200; mm.tick(); check(g.chat.size() == 2 && cm.isEnabled(), "chat macro sends nothing outside a world");
        // PlayerDetection
        g = world(); PlayerDetection pd = new PlayerDetection(g, fr); mm = reg(pd); pd.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "player detection quiet when alone");
        g.ents.add(ModuleTest.FakeGame.player(9, "foe", 20.5, 64, 0.5)); mm.tick(); check(g.isEnabledMsg("foe entered"), "player detection announces arrival"); g.log.clear(); mm.tick(); check(g.log.isEmpty(), "player detection announces once");
        g.ents.clear(); mm.tick(); check(g.isEnabledMsg("foe left"), "player detection announces departure");
        g.log.clear(); fr.add("pal"); g.ents.add(ModuleTest.FakeGame.player(10, "pal", 5, 64, 0)); mm.tick(); check(g.log.isEmpty(), "player detection ignores friends by default"); fr.clear();
        g.ents.clear(); g.ents.add(ModuleTest.FakeGame.player(11, "far", 500, 64, 0)); mm.tick(); check(g.log.isEmpty(), "player detection ignores far players");
        // WeatherNotifier
        g = world(); WeatherNotifier wn = new WeatherNotifier(g); mm = reg(wn); wn.setEnabled(true); mm.tick(); check(g.log.isEmpty(), "weather notifier silent on first reading");
        g.raining = true; mm.tick(); check(g.isEnabledMsg("started raining"), "weather notifier reports rain"); g.raining = false; mm.tick(); check(g.isEnabledMsg("rain stopped"), "weather notifier reports clearing");
        g.log.clear(); wn.rainStop.set(false); g.raining = true; mm.tick(); g.log.clear(); g.raining = false; mm.tick(); check(g.log.isEmpty(), "weather notifier honours announce-clear");
    }

    // ---------------------------------------------------------------------------------------------------- world
    static void worldMods() {
        // Nuker
        G g = world(); g.walls.add(ModuleTest.FakeGame.k(1, 64, 0)); g.walls.add(ModuleTest.FakeGame.k(0, 64, 1)); g.walls.add(ModuleTest.FakeGame.k(0, 64, 40));
        Nuker nk = new Nuker(g); ModuleManager mm = reg(nk); nk.mode.set("Flatten"); nk.setEnabled(true); mm.tick(); mm.tick(); mm.tick();
        check(g.count("break ") == 2 && g.removed.contains("1,64,0") && g.removed.contains("0,64,1"), "nuker breaks blocks in range one after another, got " + g.count("break "));
        check(!g.removed.contains("0,64,40") && g.log.stream().noneMatch(s -> s.startsWith("break") && s.contains(",63,")), "nuker leaves far blocks and ground (flatten) alone");
        g = world(); g.walls.add(ModuleTest.FakeGame.k(1, 64, 0)); g.unbreakable.add("1,64,0"); nk = new Nuker(g); mm = reg(nk); nk.mode.set("Flatten"); nk.setEnabled(true); mm.tick(); check(g.count("break") == 0, "nuker skips unbreakable blocks");
        g = world(); nk = new Nuker(g); mm = reg(nk); nk.setEnabled(true); mm.tick(); check(g.count("break 0,63,0") == 1 || g.count("break ") == 1, "nuker mode All also mines the ground below");
        g = world(); g.walls.add(ModuleTest.FakeGame.k(1, 64, 0)); g.liquids.add("1,64,0"); nk = new Nuker(g); mm = reg(nk); nk.mode.set("Flatten"); nk.setEnabled(true); mm.tick(); check(g.count("break") == 0, "nuker skips liquids when asked");
        g = world(); g.walls.add(ModuleTest.FakeGame.k(1, 64, 0)); g.unloadedChunks.add(0L); nk = new Nuker(g); mm = reg(nk); nk.mode.set("Flatten"); nk.setEnabled(true); mm.tick(); check(g.count("break") == 0 && nk.isEnabled(), "nuker ignores unloaded chunks");
        g = world(); g.walls.add(ModuleTest.FakeGame.k(1, 64, 0)); g.using = true; nk = new Nuker(g); mm = reg(nk); nk.mode.set("Flatten"); nk.setEnabled(true); mm.tick(); check(g.count("break") == 0, "nuker pauses while using an item");
        // LiquidFiller
        g = world(); g.liquids.add("1,64,0"); g.hotbar[3] = ItemKind.FILLER_BLOCK; LiquidFiller lf = new LiquidFiller(g); mm = reg(lf); lf.setEnabled(true); mm.tick();
        check(g.count("block 1,64,0") == 1 && g.sel == 0, "liquid filler plugs a source block and restores the slot");
        g = world(); g.liquids.add("1,64,0"); lf = new LiquidFiller(g); mm = reg(lf); lf.setEnabled(true); mm.tick(); mm.tick(); check(g.count("msg") == 1 && lf.isEnabled(), "liquid filler warns once when it has no blocks");
        g = world(); g.liquids.add("30,64,0"); g.hotbar[3] = ItemKind.FILLER_BLOCK; lf = new LiquidFiller(g); mm = reg(lf); lf.setEnabled(true); mm.tick(); check(g.count("block") == 0, "liquid filler ignores far liquids");
        g = world(); for (int i = 1; i <= 4; i++) g.liquids.add("" + i + ",64,0"); g.hotbar[3] = ItemKind.FILLER_BLOCK; lf = new LiquidFiller(g); mm = reg(lf); lf.perTick.set(3.0); lf.setEnabled(true); mm.tick(); check(g.count("block") == 3, "liquid filler honours per-tick limit");
        // SpawnProofer
        g = world(); g.dark = true; g.hotbar[1] = ItemKind.TORCH; SpawnProofer sp = new SpawnProofer(g); mm = reg(sp); sp.setEnabled(true); mm.tick(); check(g.count("block ") == 1 && g.sel == 0, "spawn proofer places one torch per tick by default");
        sp.perTick.set(3.0); g.log.clear(); mm.tick(); check(g.count("block ") == 3, "spawn proofer per-tick setting");
        g = world(); g.dark = false; g.hotbar[1] = ItemKind.TORCH; sp = new SpawnProofer(g); mm = reg(sp); sp.setEnabled(true); mm.tick(); check(g.count("block") == 0, "spawn proofer leaves lit areas alone");
        g = world(); g.dark = true; sp = new SpawnProofer(g); mm = reg(sp); sp.setEnabled(true); mm.tick(); mm.tick(); check(g.count("msg") == 1, "spawn proofer warns once about missing torches");
    }

    // ----------------------------------------------------------------------------- everything, hostile conditions
    static void sweep() {
        FriendManager fr = new FriendManager();
        ModuleManager probe = new ModuleManager(s -> {}); Modules.registerAll(probe, world(), fr);
        int total = probe.all().size();
        check(total >= 50, "at least 50 modules registered, got " + total);
        Set<String> ids = new HashSet<>(), names = new HashSet<>(); boolean allDescribed = true, settingsDescribed = true;
        for (Module m : probe.all()) {
            check(ids.add(m.id), "unique module id " + m.id); check(names.add(m.name), "unique module name " + m.name);
            if (m.description == null || m.description.length() < 8) allDescribed = false;
            for (Setting<?> st : m.settings()) if (st.description == null || st.description.isBlank()) settingsDescribed = false;
        }
        check(allDescribed, "every module has a description"); check(settingsDescribed, "every setting has a description");
        for (Category c : Category.values()) if (c != Category.CLIENT) check(!probe.inCategory(c).isEmpty(), "category " + c.label + " is not empty");

        // each module alone under four hostile worlds, with and without enemies, never errors out
        String[] scenes = {"normal", "no-world", "dead", "unloaded", "crowded", "void"};
        for (String scene : scenes) for (Module proto : probe.all()) {
            G g = scene.equals("crowded") || scene.equals("normal") ? withFoe(2.5, 0.5) : world();
            g.hotbar[0] = ItemKind.SWORD; g.hotbar[1] = ItemKind.TORCH; g.hotbar[2] = ItemKind.END_CRYSTAL; g.hotbar[3] = ItemKind.OBSIDIAN; g.hotbar[4] = ItemKind.GLOWSTONE; g.hotbar[5] = ItemKind.RESPAWN_ANCHOR;
            g.hotbar[6] = ItemKind.FILLER_BLOCK; g.hotbar[7] = ItemKind.EXP_BOTTLE; g.hotbar[8] = ItemKind.FISHING_ROD; g.armorDur = 0.3f; g.betterArmor[3] = 15; g.crosshair = 9; g.target = new BlockPos(1, 64, 0);
            g.liquids.add("1,64,0"); g.walls.add(ModuleTest.FakeGame.k(1, 64, 0)); g.hunger = 5; g.dark = true; g.hcol = true; g.climb = true; g.glide = true; g.mining = true; g.bestTool = 3;
            for (int i = 0; i < 3; i++) g.ents.add(ModuleTest.FakeGame.player(30 + i, "p" + i, 3 + i, 64, 1)); if (scene.equals("crowded")) for (int i = 0; i < 40; i++) g.ents.add(ModuleTest.FakeGame.crystal(100 + i, i % 7, 64, i % 5));
            if (scene.equals("no-world")) g.inWorld = false; if (scene.equals("dead")) g.dead = true;
            if (scene.equals("unloaded")) for (int cx = -4; cx <= 4; cx++) for (int cz = -4; cz <= 4; cz++) g.unloadedChunks.add(((long) cx << 32) | (cz & 0xFFFFFFFFL));
            if (scene.equals("void")) { g.voidWorld = true; g.me = body(0.5, -60, 0.5, 0, -1, 0, false); }
            ModuleManager mm = new ModuleManager(s -> {}); Modules.registerAll(mm, g, fr);
            Module m = mm.get(proto.id);
            if (m instanceof ChatMacro cm) cm.message.set("x");
            m.setEnabled(true);
            for (int t = 0; t < 12; t++) { g.tick = t * 3L; mm.tick(); }
            mm.onWorldLeave(); g.inWorld = true; mm.tick();
            m.setEnabled(false);
            check(m.lastError() == null, m.name + " [" + scene + "] ran without errors: " + m.lastError());
        }

        // all modules together, many ticks, then disconnect and switch off cleanly
        G g = withFoe(2.5, 0.5); g.hotbar[2] = ItemKind.END_CRYSTAL; g.hotbar[3] = ItemKind.OBSIDIAN; g.hotbar[5] = ItemKind.RESPAWN_ANCHOR; g.hotbar[4] = ItemKind.GLOWSTONE; g.dark = true; g.crosshair = 9; g.armorDur = 0.4f; g.hotbar[7] = ItemKind.EXP_BOTTLE;
        ModuleManager mm = new ModuleManager(s -> {}); Modules.registerAll(mm, g, fr);
        for (Module m : mm.all()) if (m instanceof ChatMacro cm) cm.message.set("x");
        for (Module m : mm.all()) m.setEnabled(true);
        for (int t = 0; t < 200; t++) { g.tick = t; g.fwd = (t / 10) % 2 == 0; g.jumping = t % 7 == 0; mm.tick(); }
        mm.onWorldLeave(); g.inWorld = false; for (int t = 0; t < 10; t++) mm.tick(); g.inWorld = true;
        int broken = 0; for (Module m : mm.all()) if (m.lastError() != null) { broken++; System.out.println("  combo error in " + m.name + ": " + m.lastError()); }
        check(broken == 0, "all modules enabled together ran 200 ticks with no module failing");
        mm.disableAll(); boolean anyOn = false; for (Module m : mm.all()) anyOn |= m.isEnabled(); check(!anyOn, "disableAll turns every module off");
        check(!g.sneakIn && !g.jumpIn && !g.nv && g.fovVal == 70, "disabling everything releases forced input, night vision and fov");

        // settings JSON round trip and reset for every v4 module
        ModuleManager a = new ModuleManager(s -> {}), b = new ModuleManager(s -> {}); Modules.registerAll(a, world(), fr); Modules.registerAll(b, world(), fr);
        boolean roundTrip = true;
        try {
            java.nio.file.Path dir = java.nio.file.Files.createTempDirectory("uc-test");
            for (Module m : a.all()) for (Setting<?> st : m.settings()) if (st instanceof Setting.Num n && n.max > n.min) n.set(n.max);
            ConfigManager ca = new ConfigManager(dir, a); ca.save("v4");
            ConfigManager cb = new ConfigManager(dir, b); String err = cb.load("v4"); if (err != null) { roundTrip = false; System.out.println("  load error: " + err); }
            for (Module m : a.all()) for (Setting<?> st : m.settings()) if (!Objects.equals(st.get(), b.get(m.id).setting(st.id).get())) { roundTrip = false; System.out.println("  mismatch " + m.id + "." + st.id); }
        } catch (Exception e) { roundTrip = false; System.out.println("  " + e); }
        check(roundTrip, "all module settings survive a JSON profile save/load");
    }
}
