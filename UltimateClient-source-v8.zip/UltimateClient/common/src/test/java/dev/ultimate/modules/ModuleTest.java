package dev.ultimate.modules;

import dev.ultimate.combat.Explosion;
import dev.ultimate.core.ConfigManager;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.ModuleManager;
import dev.ultimate.game.*;
import dev.ultimate.modules.combat.*;
import dev.ultimate.modules.movement.*;
import dev.ultimate.modules.player.*;
import dev.ultimate.modules.movement.*;

import java.nio.file.*;
import java.util.*;

/** Behaviour tests for the Minecraft-independent module logic, run against a fake Game. No real Minecraft involved. */
public final class ModuleTest {
    static int checks, fails;
    static void check(boolean c, String m) { checks++; if (!c) { fails++; System.out.println("FAIL: " + m); } }

    /** Flat world: solid ground below y=64, obsidian floor at y=63 (configurable), everything else air. */
    static class FakeGame implements Game {
        boolean inWorld = true, dead, using, mining, jumping, sneaking, fwd, inWater;
        long tick; int diff = 2; float yaw, cooldown = 1f, fall;
        EntityInfo me = player(0, "me", 0, 64, 0);
        List<EntityInfo> ents = new ArrayList<>();
        Set<Long> walls = new HashSet<>(), unloadedChunks = new HashSet<>();
        ItemKind[] hotbar = new ItemKind[9], main = new ItemKind[27]; ItemKind off = ItemKind.NONE; int sel;
        List<String> log = new ArrayList<>(); Vec3 vel; boolean groundSent; Set<String> placedBlocks = new HashSet<>();
        FakeGame() { Arrays.fill(hotbar, ItemKind.NONE); Arrays.fill(main, ItemKind.NONE); }
        static long k(int x, int y, int z) { return ((long) x & 0xFFFFF) << 40 | ((long) y & 0xFFFFF) << 20 | ((long) z & 0xFFFFF); }
        static EntityInfo player(int id, String n, double x, double y, double z) {
            return new EntityInfo(id, EntityInfo.Kind.PLAYER, n, new Vec3(x, y, z), Vec3.ZERO, 0.6, 1.8, 20f, 0f, 0, 0, 0, -1, true);
        }
        static EntityInfo crystal(int id, double x, double y, double z) {
            return new EntityInfo(id, EntityInfo.Kind.CRYSTAL, "crystal", new Vec3(x, y, z), Vec3.ZERO, 2, 2, 1f, 0f, 0, 0, 0, -1, false);
        }
        public boolean inWorld() { return inWorld; } public boolean selfDead() { return dead; }
        public EntityInfo self() { return me; } public List<EntityInfo> entities() { return ents; }
        public long tick() { return tick; } public int difficulty() { return diff; }
        public boolean isLoaded(int x, int z) { return !unloadedChunks.contains(((long) (x >> 4) << 32) | ((z >> 4) & 0xFFFFFFFFL)); }
        public boolean isSolid(int x, int y, int z) { return y < 64 && isLoaded(x, z) || walls.contains(k(x, y, z)) || placedBlocks.contains(x + "," + y + "," + z); }
        public boolean isAir(int x, int y, int z) { return !isSolid(x, y, z); }
        public boolean isCrystalBase(int x, int y, int z) { return y == 63 && isLoaded(x, z); }
        public boolean canPlaceCrystal(BlockPos b) { return isAir(b.x(), b.y() + 1, b.z()) && isAir(b.x(), b.y() + 2, b.z()); }
        public int selectedSlot() { return sel; } public void selectSlot(int s) { sel = s; log.add("select " + s); }
        public int hotbarSlotOf(ItemKind kd) { for (int i = 0; i < 9; i++) if (hotbar[i] == kd) return i; return -1; }
        public int mainInvSlotOf(ItemKind kd) { for (int i = 0; i < 27; i++) if (main[i] == kd) return 9 + i; return -1; }
        public ItemKind mainHand() { return hotbar[sel]; } public ItemKind offhand() { return off; }
        public void swapWithOffhand(int s) { ItemKind[] arr = s < 9 ? hotbar : main; int i = s < 9 ? s : s - 9; ItemKind t = arr[i]; arr[i] = off; off = t; log.add("swap " + s); }
        public boolean placeCrystal(BlockPos b) { if (mainHand() != ItemKind.END_CRYSTAL && off != ItemKind.END_CRYSTAL) return false; log.add("crystal " + b.x() + "," + b.y() + "," + b.z()); return true; }
        public boolean placeBlock(BlockPos b) { log.add("block " + b.x() + "," + b.y() + "," + b.z()); placedBlocks.add(b.x() + "," + b.y() + "," + b.z()); return true; }
        public boolean attack(int id) { log.add("attack " + id); return true; }
        public void lookAt(Vec3 p) { log.add("look"); }
        public void setVelocity(Vec3 v) { vel = v; } public void setSprinting(boolean on) { log.add("sprint " + on); }
        public void respawn() { log.add("respawn"); }
        public boolean movingForward() { return fwd; } public boolean movingAny() { return fwd; } public boolean jumping() { return jumping; }
        public boolean sneaking() { return sneaking; } public boolean usingItem() { return using; } public boolean breakingBlock() { return mining; }
        public float yaw() { return yaw; } public float fallDistance() { return fall; } public boolean inWater() { return inWater; }
        public void sendOnGround(boolean g) { groundSent = g; } public float attackCooldown() { return cooldown; }
        public void message(String t) { log.add("msg " + t); }
        int hunger = 20; boolean useKey, forced;
        public void setForwardInput(boolean on) { forced = on; } public int hunger() { return hunger; } public void setUseKey(boolean d) { useKey = d; }
        public int countItem(ItemKind kd) { int n = off == kd ? 1 : 0; for (ItemKind i : hotbar) if (i == kd) n++; for (ItemKind i : main) if (i == kd) n++; return n; }
        boolean isEnabledMsg(String t) { return log.stream().anyMatch(x -> x.startsWith("msg") && x.contains(t)); }
        long count(String prefix) { return log.stream().filter(s -> s.startsWith(prefix)).count(); }
    }

    static EntityInfo withHealth(EntityInfo e, float h) {
        return new EntityInfo(e.id(), e.kind(), e.name(), e.pos(), e.velocity(), e.width(), e.height(), h, e.absorption(), e.armor(), e.armorToughness(), e.blastProtectionEpf(), e.resistanceAmplifier(), e.onGround());
    }

    public static void main(String[] a) throws Exception {
        explosionTests(); crystalTests(); newModuleTests(); hudTests(); killAuraTests(); simpleModuleTests(); integrationTests(); NewModuleTest.run(); V5Test.run(); V6Test.run(); V7Test.run();
        System.out.println(checks + " checks, " + fails + " failures");
        if (fails > 0) System.exit(1);
    }

    static void explosionTests() {
        Explosion.Blocks open = (x, y, z) -> false;
        EntityInfo p = FakeGame.player(1, "p", 0.5, 64, 0.5);
        Vec3 here = new Vec3(0.5, 64, 0.5);
        check(Explosion.damage(Explosion.Kind.CRYSTAL, here, p, p.pos(), 2, open) == 85f, "point blank unarmored normal = 85 per formula");
        check(Explosion.damage(Explosion.Kind.CRYSTAL, here.add(13, 0, 0), p, p.pos(), 2, open) == 0f, "beyond 12 blocks = 0");
        float near = Explosion.damage(Explosion.Kind.CRYSTAL, here.add(2, 0, 0), p, p.pos(), 2, open);
        float far = Explosion.damage(Explosion.Kind.CRYSTAL, here.add(6, 0, 0), p, p.pos(), 2, open);
        check(near > far && far > 0, "damage falls with distance (" + near + " > " + far + ")");
        Explosion.Blocks wall = (x, y, z) -> x == 2 && y >= 60 && y <= 70 && z >= -10 && z <= 10;
        float walled = Explosion.damage(Explosion.Kind.CRYSTAL, here.add(4, 0, 0), p, p.pos(), 2, wall);
        float clear = Explosion.damage(Explosion.Kind.CRYSTAL, here.add(4, 0, 0), p, p.pos(), 2, open);
        check(walled < clear * 0.2f, "solid wall removes most damage (" + walled + " vs " + clear + ")");
        check(Math.abs(Explosion.afterArmor(10, 20, 8) - 3f) < 1e-4, "armor formula example");
        EntityInfo armored = new EntityInfo(1, EntityInfo.Kind.PLAYER, "p", p.pos(), Vec3.ZERO, 0.6, 1.8, 20, 0, 20, 8, 0, -1, true);
        check(Explosion.damage(Explosion.Kind.CRYSTAL, here.add(1, 0, 0), armored, p.pos(), 2, open) < Explosion.damage(Explosion.Kind.CRYSTAL, here.add(1, 0, 0), p, p.pos(), 2, open), "armor reduces");
        float normal = Explosion.damage(Explosion.Kind.CRYSTAL, here.add(3, 0, 0), p, p.pos(), 2, open);
        check(Explosion.damage(Explosion.Kind.CRYSTAL, here.add(3, 0, 0), p, p.pos(), 3, open) > normal, "hard > normal");
        check(Explosion.damage(Explosion.Kind.CRYSTAL, here.add(3, 0, 0), p, p.pos(), 0, open) == 0f, "peaceful = 0");
        EntityInfo res = new EntityInfo(1, EntityInfo.Kind.PLAYER, "p", p.pos(), Vec3.ZERO, 0.6, 1.8, 20, 0, 0, 0, 0, 4, true);
        check(Explosion.damage(Explosion.Kind.CRYSTAL, here.add(3, 0, 0), res, p.pos(), 2, open) == 0f, "resistance V fully blocks");
        EntityInfo epf = new EntityInfo(1, EntityInfo.Kind.PLAYER, "p", p.pos(), Vec3.ZERO, 0.6, 1.8, 20, 0, 0, 0, 20, -1, true);
        check(Explosion.damage(Explosion.Kind.CRYSTAL, here.add(3, 0, 0), epf, p.pos(), 2, open) < normal * 0.25f, "blast prot reduces");
        check(Explosion.damage(Explosion.Kind.ANCHOR, here.add(3, 0, 0), p, p.pos(), 2, open) < normal, "anchor power 5 < crystal power 6");
    }

    static FakeGame duel() {
        FakeGame g = new FakeGame();
        g.hotbar[2] = ItemKind.END_CRYSTAL;
        g.ents.add(FakeGame.player(10, "enemy", 4.5, 64, 0.5));
        g.me = new EntityInfo(0, EntityInfo.Kind.PLAYER, "me", new Vec3(0.5, 64, 0.5), Vec3.ZERO, 0.6, 1.8, 20f, 0f, 20, 12, 16, -1, true); // blast-prot gear
        return g;
    }

    static void crystalTests() {
        FriendManager friends = new FriendManager();
        // place
        FakeGame g = duel(); CrystalAura ca = new CrystalAura(g, friends);
        ModuleManager mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.setEnabled(true); ca.minDamage.set(3.0); ca.maxSelfDamage.set(30.0); mm.tick();
        check(g.count("crystal ") == 1, "places one crystal");
        check(g.sel == 0 && g.count("select 2") == 1 && g.count("select 0") == 1, "switched to crystal slot and back");
        check(ca.hudTarget.equals("enemy") && ca.hudTargetDamage >= 3f, "HUD info set");
        String pos = g.log.stream().filter(s -> s.startsWith("crystal ")).findFirst().get().substring(8);
        int bx = Integer.parseInt(pos.split(",")[0]);
        check(bx >= 1 && bx <= 5, "placed between/near players, base x=" + bx);
        // self damage protection
        g = duel(); ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.setEnabled(true); ca.maxSelfDamage.set(0.0); mm.tick();
        check(g.count("crystal ") == 0, "max-self-damage 0 prevents placing when self would be hurt");
        // low self health protection
        g = duel(); g.me = withHealth(g.me, 6f); ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.setEnabled(true); ca.minDamage.set(1.0); ca.maxSelfDamage.set(36.0); mm.tick();
        check(g.count("crystal ") == 0, "low self health: refuses placements that could kill me");
        // friend protection
        g = duel(); g.ents.add(FakeGame.player(11, "buddy", 4.5, 64, 2.5)); friends.add("buddy");
        ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.setEnabled(true); ca.minDamage.set(3.0); ca.maxSelfDamage.set(30.0); ca.friendMaxDamage.set(1.0); mm.tick();
        FakeGame g2 = duel(); CrystalAura c2 = new CrystalAura(g2, new FriendManager()); ModuleManager m2 = new ModuleManager(s -> {}); m2.register(c2);
        c2.setEnabled(true); c2.minDamage.set(3.0); c2.maxSelfDamage.set(30.0); m2.tick();
        check(g2.count("crystal ") == 1, "control: places without friend nearby");
        if (g.count("crystal ") == 1) {
            String[] b = g.log.stream().filter(s -> s.startsWith("crystal ")).findFirst().get().substring(8).split(",");
            check(new Vec3(Integer.parseInt(b[0]) + .5, 64, Integer.parseInt(b[2]) + .5).distanceTo(new Vec3(4.5, 64, 2.5)) > 3, "friend not hurt by chosen placement");
        } else check(true, "friend protection blocked placement entirely");
        friends.clear();
        // friend is never a target
        g = new FakeGame(); g.hotbar[2] = ItemKind.END_CRYSTAL; g.ents.add(FakeGame.player(12, "buddy", 3.5, 64, 0.5)); friends.add("buddy");
        ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca); ca.setEnabled(true); ca.minDamage.set(1.0); ca.maxSelfDamage.set(30.0); mm.tick();
        check(g.log.isEmpty(), "friends are not targeted"); friends.clear();
        // break
        g = duel(); g.ents.add(FakeGame.crystal(20, 3.5, 64, 0.5)); ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.setEnabled(true); ca.place.set(false); ca.minDamage.set(3.0); ca.maxSelfDamage.set(30.0); mm.tick();
        check(g.count("attack 20") == 1, "breaks a good crystal");
        g.tick = 1; ca.breakDelay.set(5.0); mm.tick(); check(g.count("attack 20") == 1, "break delay respected");
        g.tick = 7; mm.tick(); check(g.count("attack 20") == 2, "break resumes after delay");
        // far crystal ignored
        g = duel(); g.ents.add(FakeGame.crystal(21, 40, 64, 0)); ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.setEnabled(true); ca.place.set(false); mm.tick(); check(g.count("attack") == 0, "out-of-range crystal ignored");
        // no crystals in inventory
        g = duel(); g.hotbar[2] = ItemKind.NONE; ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.setEnabled(true); mm.tick(); check(g.log.isEmpty() && ca.isEnabled(), "no crystals: nothing happens, no error");
        // offhand crystal needs no switch
        g = duel(); g.hotbar[2] = ItemKind.NONE; g.off = ItemKind.END_CRYSTAL; ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.setEnabled(true); ca.minDamage.set(3.0); ca.maxSelfDamage.set(30.0); mm.tick(); check(g.count("crystal ") == 1 && g.count("select") == 0, "offhand crystal used without slot switching");
        // pause on eat, dead, not in world, unloaded chunks
        g = duel(); ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca); ca.setEnabled(true); ca.minDamage.set(3.0); ca.maxSelfDamage.set(30.0);
        g.using = true; mm.tick(); check(g.log.isEmpty(), "paused while eating");
        g.using = false; g.dead = true; mm.tick(); check(g.log.isEmpty(), "idle when dead");
        g.dead = false; g.inWorld = false; mm.tick(); check(g.log.isEmpty() && ca.isEnabled(), "idle outside world, stays enabled");
        g.inWorld = true; for (int cx = -2; cx <= 2; cx++) for (int cz = -2; cz <= 2; cz++) g.unloadedChunks.add(((long) cx << 32) | (cz & 0xFFFFFFFFL));
        mm.tick(); check(g.count("crystal ") == 0, "unloaded chunks: no placement");
        // multiple targets
        g = duel(); g.ents.add(FakeGame.player(13, "enemy2", 4.5, 64, -2.5)); ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.maxTargets.set(2.0); ca.setEnabled(true); ca.minDamage.set(3.0); ca.maxSelfDamage.set(30.0); mm.tick(); check(g.count("crystal ") == 1, "multi-target placement works");
        // face place
        g = duel(); EntityInfo w = g.ents.get(0); g.ents.set(0, new EntityInfo(w.id(), w.kind(), w.name(), w.pos(), w.velocity(), w.width(), w.height(), 3f, 0f, 0, 0, 0, 2, true)); ca = new CrystalAura(g, friends); mm = new ModuleManager(s -> {}); mm.register(ca);
        ca.setEnabled(true); ca.minDamage.set(36.0); ca.maxSelfDamage.set(30.0); mm.tick(); check(g.count("crystal ") == 1, "face place on low-health target despite high min damage");
        ca.facePlace.set(false); g.log.clear(); g.tick = 50; mm.tick(); check(g.count("crystal ") == 0, "face place off respects min damage");
        // disable clears hud
        ca.setEnabled(false); check(ca.hudTarget.isEmpty(), "disable clears HUD target");
    }

    static void killAuraTests() {
        FriendManager fr = new FriendManager();
        FakeGame g = new FakeGame(); g.ents.add(FakeGame.player(1, "foe", 2.5, 64, 0.5)); g.me = FakeGame.player(0, "me", 0.5, 64, 0.5);
        KillAura k = new KillAura(g, fr); ModuleManager mm = new ModuleManager(s -> {}); mm.register(k); k.setEnabled(true); mm.tick();
        check(g.count("attack 1") == 1 && g.count("look") == 1, "attacks player in range and rotates");
        g.log.clear(); g.cooldown = 0.3f; mm.tick(); check(g.count("attack") == 0, "waits for cooldown");
        g.cooldown = 1f; fr.add("foe"); mm.tick(); check(g.count("attack") == 0, "never hits friends"); fr.clear();
        g.ents.set(0, FakeGame.player(1, "foe", 9.5, 64, 0.5)); mm.tick(); check(g.count("attack") == 0, "out of range");
        g.ents.set(0, FakeGame.player(1, "foe", 2.5, 64, 0.5)); for (int y = 62; y < 68; y++) g.walls.add(FakeGame.k(1, y, 0));
        mm.tick(); check(g.count("attack") == 0, "no hit through wall when wall-range 0");
        k.wallRange.set(5.0); mm.tick(); check(g.count("attack") == 1, "wall-range allows");
        g.walls.clear(); g.log.clear(); g.ents.clear();
        g.ents.add(FakeGame.player(5, "a", 3, 64, 0)); g.ents.add(FakeGame.player(6, "b", 1.5, 64, 0)); g.ents.add(withHealth(FakeGame.player(7, "c", 2.5, 64, 0), 4f));
        mm.tick(); check(g.count("attack 6") == 1, "distance priority hits nearest");
        g.log.clear(); k.priority.set("Health"); mm.tick(); check(g.count("attack 7") == 1, "health priority hits weakest");
        g.log.clear(); k.maxTargets.set(3.0); mm.tick(); check(g.count("attack") == 3, "multi-target hits N entities");
        g.log.clear(); g.using = true; mm.tick(); check(g.count("attack") == 0, "paused while using item");
    }

    static void simpleModuleTests() {
        FakeGame g = new FakeGame(); ModuleManager mm = new ModuleManager(s -> {});
        // AutoTotem
        AutoTotem t = new AutoTotem(g); mm.register(t); t.setEnabled(true);
        mm.tick(); check(g.count("swap") == 0, "no totem anywhere: nothing");
        g.main[3] = ItemKind.TOTEM; mm.tick(); check(g.off == ItemKind.TOTEM && g.count("swap 12") == 1, "takes totem from inventory");
        g.log.clear(); mm.tick(); check(g.log.isEmpty(), "already has totem");
        g.off = ItemKind.NONE; g.hotbar[7] = ItemKind.TOTEM; t.delay.set(5.0); g.tick = 100; mm.tick(); check(g.count("swap 7") == 1, "prefers hotbar");
        g.off = ItemKind.NONE; g.hotbar[1] = ItemKind.TOTEM; g.tick = 102; g.log.clear(); mm.tick(); check(g.log.isEmpty(), "delay honoured"); g.tick = 106; mm.tick(); check(g.count("swap") == 1, "after delay");
        t.setEnabled(false);
        // Surround
        g = new FakeGame(); mm = new ModuleManager(s -> {}); Surround s = new Surround(g); mm.register(s); s.setEnabled(true); s.blocksPerTick.set(8.0); s.autoDisable.set(true);
        mm.tick(); check(g.isEnabledMsg("no obsidian") && !s.isEnabled(), "no obsidian: message + disabled");
        g = new FakeGame(); mm = new ModuleManager(s2 -> {}); s = new Surround(g); mm.register(s); g.hotbar[4] = ItemKind.OBSIDIAN; s.setEnabled(true); s.blocksPerTick.set(8.0); s.autoDisable.set(true);
        mm.tick(); check(g.count("block ") == 4, "places 4 side blocks, got " + g.count("block "));
        check(g.sel == 0, "slot restored"); mm.tick(); check(!s.isEnabled(), "auto-disable once complete");
        g = new FakeGame(); mm = new ModuleManager(s2 -> {}); s = new Surround(g); mm.register(s); g.hotbar[4] = ItemKind.OBSIDIAN; s.setEnabled(true); s.blocksPerTick.set(1.0); mm.tick();
        check(g.count("block ") == 1, "blocks-per-tick limit"); 
        g.me = FakeGame.player(0, "me", 0.5, 70, 0.5); ((FakeGame) g).me = new EntityInfo(0, EntityInfo.Kind.PLAYER, "me", new Vec3(.5, 64, .5), Vec3.ZERO, .6, 1.8, 20, 0, 0, 0, 0, -1, false); g.log.clear(); mm.tick(); check(g.count("block") == 0, "only-on-ground respected");
        // Fly
        g = new FakeGame(); mm = new ModuleManager(s2 -> {}); Fly f = new Fly(g); mm.register(f); f.setEnabled(true);
        mm.tick(); check(g.vel.equals(Vec3.ZERO), "hover holds still");
        g.jumping = true; mm.tick(); check(g.vel.y() > 0, "jump rises"); g.jumping = false; g.sneaking = true; mm.tick(); check(g.vel.y() < 0, "sneak descends");
        g.sneaking = false; g.fwd = true; g.yaw = 0; mm.tick(); check(Math.abs(g.vel.z() - f.speed.get()) < 1e-9 && Math.abs(g.vel.x()) < 1e-9, "yaw 0 flies +Z");
        g.yaw = 90; mm.tick(); check(g.vel.x() < -0.4, "yaw 90 flies -X");
        f.setEnabled(false); check(g.vel.equals(Vec3.ZERO), "disable stops motion");
        // NoFall
        g = new FakeGame(); mm = new ModuleManager(s2 -> {}); NoFall n = new NoFall(g); mm.register(n); n.setEnabled(true);
        g.fall = 1; mm.tick(); check(!g.groundSent, "short fall ignored"); g.fall = 5; mm.tick(); check(g.groundSent, "long fall acts"); g.groundSent = false; g.inWater = true; mm.tick(); check(!g.groundSent, "not in water");
        // Sprint
        g = new FakeGame(); mm = new ModuleManager(s2 -> {}); Sprint sp = new Sprint(g); mm.register(sp); sp.setEnabled(true);
        mm.tick(); check(g.count("sprint") == 0, "idle: no sprint"); g.fwd = true; mm.tick(); check(g.count("sprint true") == 1, "sprints moving forward"); g.sneaking = true; g.log.clear(); mm.tick(); check(g.log.isEmpty(), "no sprint while sneaking");
        // AutoRespawn
        g = new FakeGame(); mm = new ModuleManager(s2 -> {}); AutoRespawn ar = new AutoRespawn(g); mm.register(ar); ar.setEnabled(true); ar.delay.set(0.1);
        g.dead = true; mm.tick(); check(g.count("respawn") == 0, "waits"); mm.tick(); check(g.count("respawn") == 1, "respawns after 2 ticks"); g.dead = false; mm.tick(); check(g.count("respawn") == 1, "alive: nothing");
    }

    static FakeGame foeGame(double fx, double fz) {
        FakeGame g = new FakeGame(); g.hotbar[3] = ItemKind.OBSIDIAN; g.hotbar[5] = ItemKind.WEB; g.me = FakeGame.player(0, "me", 0.5, 64, 0.5);
        g.ents.add(FakeGame.player(9, "foe", fx, 64, fz)); return g;
    }
    static ModuleManager reg(Module... ms) { ModuleManager mm = new ModuleManager(s -> {}); for (Module m : ms) mm.register(m); return mm; }

    static void newModuleTests() {
        FriendManager fr = new FriendManager();
        // AutoTrap: 4 sides x2 + top = 9 blocks around foe at (3,64,0)
        FakeGame g = foeGame(3.5, 0.5); AutoTrap at = new AutoTrap(g, fr); ModuleManager mm = reg(at); at.setEnabled(true); at.blocksPerTick.set(8.0);
        mm.tick(); mm.tick(); check(g.count("block ") == 9, "auto trap places 9 blocks, got " + g.count("block "));
        check(g.placedBlocks.contains("3,66,0") && g.placedBlocks.contains("4,65,0"), "trap covers top and head-height side");
        g = foeGame(3.5, 0.5); fr.add("foe"); at = new AutoTrap(g, fr); mm = reg(at); at.setEnabled(true); mm.tick(); check(g.count("block") == 0, "auto trap ignores friends"); fr.clear();
        g = foeGame(30.5, 0.5); at = new AutoTrap(g, fr); mm = reg(at); at.setEnabled(true); mm.tick(); check(g.count("block") == 0, "auto trap out of range");
        g = foeGame(3.5, 0.5); g.hotbar[3] = ItemKind.NONE; at = new AutoTrap(g, fr); mm = reg(at); at.setEnabled(true); mm.tick(); check(!at.isEnabled() && g.isEnabledMsg("no obsidian"), "auto trap without obsidian disables with message");
        // SelfTrap
        g = foeGame(30.5, 0.5); SelfTrap st = new SelfTrap(g); mm = reg(st); st.setEnabled(true); st.mode.set("Full"); st.blocksPerTick.set(8.0); mm.tick();
        check(g.count("block ") == 5 && g.placedBlocks.contains("0,66,0"), "self trap full = 4 sides + top");
        // Webs
        g = foeGame(3.5, 0.5); AutoWeb aw = new AutoWeb(g, fr); mm = reg(aw); aw.setEnabled(true); mm.tick(); check(g.placedBlocks.containsAll(List.of("3,64,0", "3,65,0")), "auto web feet+head");
        g = foeGame(30.5, 0.5); SelfWeb sw = new SelfWeb(g); mm = reg(sw); sw.setEnabled(true); mm.tick(); check(g.placedBlocks.contains("0,64,0") && !sw.isEnabled(), "self web places and auto-disables");
        // HoleFiller
        g = foeGame(6.5, 0.5); for (int[] d : new int[][]{{4, 0}, {2, 0}, {3, 1}, {3, -1}}) for (int y = 64; y < 66; y++) g.walls.add(FakeGame.k(d[0], y, d[1]));
        HoleFiller hf = new HoleFiller(g, fr); mm = reg(hf); hf.setEnabled(true); mm.tick(); check(g.placedBlocks.contains("3,64,0"), "hole filler fills the 1x1 hole");
        g = foeGame(6.5, 0.5); hf = new HoleFiller(g, fr); mm = reg(hf); hf.setEnabled(true); mm.tick(); check(g.count("block") == 0, "no holes: nothing placed");
        // AutoOffhand
        g = foeGame(30.5, 0.5); g.hotbar[1] = ItemKind.GOLDEN_APPLE; g.hotbar[2] = ItemKind.TOTEM; AutoOffhand oh = new AutoOffhand(g); mm = reg(oh); oh.setEnabled(true); g.tick = 10; mm.tick();
        check(g.off == ItemKind.GOLDEN_APPLE, "offhand gets preferred item"); g.me = withHealth(g.me, 6f); g.tick = 20; mm.tick(); check(g.off == ItemKind.TOTEM, "low health -> totem");
        // Speed / AutoWalk / HighJump
        g = new FakeGame(); Speed sp = new Speed(g); mm = reg(sp); sp.setEnabled(true); mm.tick(); check(g.vel == null, "speed idle");
        g.fwd = true; mm.tick(); check(Math.abs(g.vel.z() - sp.speed.get()) < 1e-9, "speed sets forward velocity"); g.vel = null; g.inWater = true; mm.tick(); check(g.vel == null, "speed off in water");
        g = new FakeGame(); AutoWalk aw2 = new AutoWalk(g); mm = reg(aw2); aw2.setEnabled(true); mm.tick(); check(g.forced, "auto walk forces forward"); aw2.setEnabled(false); check(!g.forced, "auto walk releases");
        g = new FakeGame(); HighJump hj = new HighJump(g); mm = reg(hj); hj.setEnabled(true); g.jumping = true; mm.tick(); check(g.vel != null && g.vel.y() == hj.power.get(), "high jump");
        // AntiAFK
        g = new FakeGame(); AntiAFK af = new AntiAFK(g); mm = reg(af); af.setEnabled(true); af.interval.set(20.0); for (int i = 0; i < 45; i++) mm.tick(); check(g.count("look") == 2, "anti afk looks every interval");
        // AutoEat
        g = new FakeGame(); g.hotbar[6] = ItemKind.FOOD; g.sel = 1; AutoEat ae = new AutoEat(g); mm = reg(ae); ae.setEnabled(true);
        mm.tick(); check(g.sel == 1 && !g.useKey, "full: no eating"); g.hunger = 10; mm.tick(); check(g.sel == 6 && g.useKey, "hungry: select food and hold use");
        g.using = true; mm.tick(); check(g.useKey, "keeps eating"); g.hunger = 20; mm.tick(); check(!g.useKey && g.sel == 1, "done: release and restore slot");
        g = new FakeGame(); g.hunger = 5; ae = new AutoEat(g); mm = reg(ae); ae.setEnabled(true); mm.tick(); check(!g.useKey, "no food: nothing");
        g = new FakeGame(); g.hotbar[6] = ItemKind.FOOD; g.hunger = 5; ae = new AutoEat(g); mm = reg(ae); ae.setEnabled(true); mm.tick(); ae.setEnabled(false); check(!g.useKey && g.sel == 0, "disable mid-meal restores");
    }

    static void hudTests() throws Exception {
        FakeGame g = new FakeGame(); g.me = FakeGame.player(0, "me", 1.5, 70, -2.25); g.hotbar[0] = ItemKind.TOTEM; g.yaw = 180;
        ModuleManager mm = new ModuleManager(s -> {}); Modules.registerAll(mm, g, new FriendManager());
        dev.ultimate.hud.Hud hud = new dev.ultimate.hud.Hud(); var ctx = new dev.ultimate.hud.Hud.Ctx(g, mm);
        mm.get("sprint").setEnabled(true); mm.get("fly").setEnabled(true);
        check(hud.get("modules").lines(ctx).equals(List.of("Sprint", "Fly")) || hud.get("modules").lines(ctx).size() == 2, "active modules list");
        check(hud.get("coords").lines(ctx).get(0).equals("XYZ 1.5 70.0 -2.3") || hud.get("coords").lines(ctx).get(0).startsWith("XYZ 1.5 70.0 -2."), "coordinates");
        check(hud.get("totems").lines(ctx).get(0).equals("Totems: 1"), "totem count");
        check(dev.ultimate.hud.Hud.direction(0).startsWith("South") && dev.ultimate.hud.Hud.direction(180).startsWith("North") && dev.ultimate.hud.Hud.direction(-90).startsWith("East"), "direction names");
        g.inWorld = false; check(hud.get("coords").lines(ctx).isEmpty(), "no HUD text outside a world"); g.inWorld = true;
        var e = hud.get("coords"); e.moveTo(5, -3); check(e.x == 1 && e.y == 0, "drag clamps to screen"); e.setScale(99); check(e.scale == 3.0, "scale clamps"); e.moveTo(0.4, 0.6); e.enabled = false;
        check(e.lines(ctx).isEmpty(), "disabled element hidden");
        Path dir = Files.createTempDirectory("uc-hud"); ConfigManager cm = new ConfigManager(dir, mm);
        hud.save(mm.layout); cm.save("h"); var hud2 = new dev.ultimate.hud.Hud(); mm.layout.clear(); check(cm.load("h") == null, "layout loads"); hud2.load(mm.layout);
        check(hud2.get("coords").x == 0.4 && hud2.get("coords").y == 0.6 && !hud2.get("coords").enabled, "HUD layout persists through profile");
    }

    static void integrationTests() throws Exception {
        FakeGame g = new FakeGame(); FriendManager fr = new FriendManager();
        ModuleManager mm = new ModuleManager(s -> {}); Modules.registerAll(mm, g, fr);
        check(mm.all().size() == 118, "118 modules registered, got " + mm.all().size());
        // enable/disable churn in world and outside, with enemies present
        g.hotbar[2] = ItemKind.END_CRYSTAL; g.hotbar[4] = ItemKind.OBSIDIAN; g.ents.add(FakeGame.player(10, "enemy", 4.5, 64, 0.5));
        for (int i = 0; i < 300; i++) { for (Module m : mm.all()) m.toggle(); g.inWorld = (i % 3 != 0); mm.tick(); if (i % 50 == 0) mm.onWorldLeave(); }
        for (Module m : mm.all()) check(m.lastError() == null, m.name + " no error after churn: " + m.lastError());
        mm.disableAll(); for (Module m : mm.all()) check(mm.bus().listenerCount(m) == 0, "no leaked listeners " + m.id);
        // all modules enabled together, many ticks
        g.inWorld = true; for (Module m : mm.all()) m.setEnabled(true);
        for (int i = 0; i < 200; i++) { g.tick++; mm.tick(); }
        for (Module m : mm.all()) check(m.lastError() == null, m.name + " no error in combined run: " + m.lastError());
        check(g.count("crystal ") > 0 || g.count("attack") >= 0, "combined run produced activity");
        // config roundtrip
        Path dir = Files.createTempDirectory("uc-test"); ConfigManager cm = new ConfigManager(dir, mm);
        CrystalAura ca = (CrystalAura) mm.get("crystal-aura"); ca.minDamage.set(9.5); ca.setKeybind(67); mm.setFavorite("crystal-aura", true);
        cm.save("pvp"); ca.minDamage.set(1.0); ca.setKeybind(-1); mm.setFavorite("crystal-aura", false);
        check(cm.load("pvp") == null && ca.minDamage.get() == 9.5 && ca.keybind() == 67 && mm.isFavorite("crystal-aura"), "profile roundtrip incl. keybind/favorite");
        // every module has metadata
        for (Module m : mm.all()) check(!m.description.isBlank() && !m.settings().isEmpty(), "metadata+settings " + m.id);
    }
}
