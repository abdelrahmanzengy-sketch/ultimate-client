package dev.ultimate.modules;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;
import dev.ultimate.hud.Hud;
import dev.ultimate.modules.combat.JumpReset;
import dev.ultimate.modules.misc.StaffList;
import dev.ultimate.modules.movement.Strafe;

import java.util.*;

/** Tests for the v6 modules (Jump Reset, Strafe, Staff List) and HUD elements (compass, hole, potions, server). */
final class V6Test {
    private V6Test() {}
    static void check(boolean c, String m) { ModuleTest.check(c, m); }

    static class G6 extends NewModuleTest.G {
        int hurt; List<String> players = new ArrayList<>(); float side; List<String> effects = new ArrayList<>(); String addr = ""; boolean hardWalls;
        List<String> msgs() { List<String> o = new ArrayList<>(); for (String l : log) if (l.startsWith("msg ")) o.add(l.substring(4)); return o; }
        @Override public int hurtTime() { return hurt; }
        @Override public List<String> onlinePlayerNames() { return players; }
        @Override public float sidewaysInput() { return side; }
        @Override public List<String> effectTimers() { return effects; }
        @Override public String serverAddress() { return addr; }
        @Override public boolean isCrystalBase(int x, int y, int z) { return hardWalls ? walls.contains(k(x, y, z)) || super.isCrystalBase(x, y, z) : super.isCrystalBase(x, y, z); }
    }
    static G6 world() { G6 g = new G6(); g.me = NewModuleTest.body(0.5, 64, 0.5, 0, 0, 0, true); return g; }

    static void run() { jumpReset(); strafe(); staffList(); hud(); }

    static void jumpReset() {
        G6 g = world(); JumpReset j = new JumpReset(g); ModuleManager mm = ModuleTest.reg(j); j.setEnabled(true);
        mm.tick(); check(!g.jumpIn, "jump reset idle when not hurt");
        g.hurt = 10; mm.tick(); check(g.jumpIn, "jump reset presses jump on the first hurt tick");
        mm.tick(); check(!g.jumpIn, "jump reset releases jump the next tick");
        g.hurt = 9; mm.tick(); check(!g.jumpIn, "jump reset does not re-fire while the same hit's timer runs down");
        g.hurt = 0; mm.tick(); g.hurt = 10; mm.tick(); check(g.jumpIn, "jump reset fires again for a new hit");
        mm.tick(); g.hurt = 0; mm.tick();
        g.me = NewModuleTest.body(0.5, 65, 0.5, 0, -0.1, 0, false); g.hurt = 10; mm.tick(); check(!g.jumpIn, "no jump while airborne");
        g.hurt = 0; mm.tick(); g.me = NewModuleTest.body(0.5, 64, 0.5, 0, 0, 0, true); g.sneaking = true; g.hurt = 10; mm.tick(); check(!g.jumpIn, "no jump while sneaking");
        g.sneaking = false; g.hurt = 0; mm.tick(); g.screen = true; g.hurt = 10; mm.tick(); check(!g.jumpIn, "no jump while a screen is open");
        g.screen = false; g.hurt = 0; mm.tick(); j.needSprint.set(true); g.hurt = 10; mm.tick(); check(!g.jumpIn, "only-moving: no jump while standing still");
        g.hurt = 0; mm.tick(); j.needSprint.set(false); j.chance.set(1.0); int fired = 0; for (int i = 0; i < 200; i++) { g.hurt = 0; mm.tick(); g.hurt = 10; mm.tick(); if (g.jumpIn) fired++; mm.tick(); }
        check(fired < 40, "chance 1% reacts rarely (" + fired + "/200)");
        j.chance.set(100.0); g.hurt = 0; mm.tick(); g.hurt = 10; mm.tick(); check(g.jumpIn, "chance 100% always reacts"); j.setEnabled(false); check(!g.jumpIn, "disabling releases a held jump");
        g.inWorld = false; j.setEnabled(true); mm.tick(); check(j.isEnabled() && j.lastError() == null, "jump reset is safe outside a world");
    }

    static void strafe() {
        G6 g = world(); g.me = NewModuleTest.body(0.5, 66, 0.5, 0, -0.1, 0, false); Strafe s = new Strafe(g); ModuleManager mm = ModuleTest.reg(s); s.setEnabled(true);
        mm.tick(); check(g.vel == null, "strafe idle without input");
        g.fwd = true; g.yaw = 0; mm.tick(); check(g.vel != null && Math.abs(g.vel.x()) < 1e-9 && Math.abs(g.vel.z() - 0.26) < 1e-9 && g.vel.y() == -0.1, "forward at yaw 0 goes +Z at min speed, y untouched");
        g.vel = null; g.yaw = 90; mm.tick(); check(Math.abs(g.vel.x() + 0.26) < 1e-9 && Math.abs(g.vel.z()) < 1e-9, "forward at yaw 90 goes -X");
        g.vel = null; g.fwd = false; g.yaw = 0; g.side = 1f; mm.tick(); check(Math.abs(g.vel.x() + 0.26) < 1e-9 && Math.abs(g.vel.z()) < 1e-9, "pressing right at yaw 0 goes -X (right of a south-facing player)");
        g.vel = null; g.fwd = true; g.side = -1f; mm.tick(); double l = Math.hypot(g.vel.x(), g.vel.z()); check(Math.abs(l - 0.26) < 1e-9 && g.vel.x() > 0 && g.vel.z() > 0, "diagonal input keeps the same speed");
        g.vel = null; g.me = NewModuleTest.body(0.5, 66, 0.5, 0, -0.1, 0.5, false); g.side = 0f; g.yaw = 0; mm.tick(); check(Math.abs(g.vel.z() - 0.5) < 1e-9, "keep-speed preserves faster motion");
        s.keepSpeed.set(false); g.vel = null; mm.tick(); check(Math.abs(g.vel.z() - 0.26) < 1e-9, "keep-speed off clamps to the setting");
        g.vel = null; g.me = NewModuleTest.body(0.5, 64, 0.5, 0, 0, 0, true); mm.tick(); check(g.vel == null, "strafe does nothing on the ground");
        g.me = NewModuleTest.body(0.5, 66, 0.5, 0, -0.1, 0, false); g.inWater = true; mm.tick(); check(g.vel == null, "strafe does nothing in water");
        g.inWater = false; g.glide = true; mm.tick(); check(g.vel == null, "strafe does nothing while gliding");
        g.glide = false; g.dead = true; mm.tick(); check(g.vel == null, "strafe does nothing when dead");
    }

    static void staffList() {
        G6 g = world(); StaffList sl = new StaffList(g); ModuleManager mm = ModuleTest.reg(sl); sl.interval.set(5.0); sl.setEnabled(true);
        g.players.addAll(List.of("Alice", "Bob")); for (int i = 0; i < 5; i++) mm.tick(); check(g.chat.isEmpty() && g.msgs().isEmpty(), "no names configured, nothing announced");
        sl.names.set("alice, CAROL ,"); for (int i = 0; i < 5; i++) mm.tick(); check(g.msgs().stream().anyMatch(m -> m.contains("Staff online: Alice")) && sl.present.equals(List.of("Alice")), "watched name found case-insensitively");
        int n = g.msgs().size(); for (int i = 0; i < 10; i++) mm.tick(); check(g.msgs().size() == n, "no repeat announcement while still online");
        g.players.add("carol"); for (int i = 0; i < 5; i++) mm.tick(); check(g.msgs().stream().anyMatch(m -> m.contains("Staff online: carol")) && sl.present.size() == 2, "second name announced");
        g.players.remove("Alice"); for (int i = 0; i < 5; i++) mm.tick(); check(g.msgs().stream().anyMatch(m -> m.contains("Staff left: Alice")) && sl.present.equals(List.of("carol")), "leave announced and list updated");
        sl.leaves.set(false); g.players.remove("carol"); int m2 = g.msgs().size(); for (int i = 0; i < 5; i++) mm.tick(); check(g.msgs().size() == m2 && sl.present.isEmpty(), "announce-leave off stays silent but list updates");
        g.players.add(null); for (int i = 0; i < 5; i++) mm.tick(); check(sl.isEnabled() && sl.lastError() == null, "null names in the list do not crash");
        g.inWorld = false; for (int i = 0; i < 5; i++) mm.tick(); check(sl.isEnabled(), "staff list safe outside a world");
        check(StaffList.parse(" a,, B ,a").equals(Set.of("a", "b")), "name list parsing trims, lowercases, drops blanks");
    }

    static void hud() {
        G6 g = world(); ModuleManager mm = ModuleTest.reg(); Hud hud = new Hud(); Hud.Ctx c = new Hud.Ctx(g, mm);
        check(Hud.compass(0).equals("E  [S]  SW") || Hud.compass(0).contains("[S]"), "compass marks south at yaw 0: " + Hud.compass(0));
        check(Hud.compass(180).contains("[N]") && Hud.compass(-90).contains("[E]") && Hud.compass(90).contains("[W]") && Hud.compass(720 + 45).contains("[SW]"), "compass facings, incl. wraparound");
        check(Hud.compass(Float.NaN).contains("["), "compass survives NaN yaw");
        g.yaw = 180; check(hud.get("compass").lines(c).get(0).contains("[N]"), "compass element draws from the player's yaw");
        // hole
        check(Hud.holeInfo(g).isEmpty(), "open ground is not a hole");
        int[][] d = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}; for (int i = 0; i < 2; i++) g.walls.add(ModuleTest.FakeGame.k(d[i][0], 64, d[i][1]));
        check(Hud.holeInfo(g).equals("Hole: 2/4 sides covered"), "two walls: " + Hud.holeInfo(g));
        for (int i = 2; i < 4; i++) g.walls.add(ModuleTest.FakeGame.k(d[i][0], 64, d[i][1]));
        check(Hud.holeInfo(g).equals("Hole: enclosed (breakable sides)"), "four non-hard walls: " + Hud.holeInfo(g));
        g.hardWalls = true; check(Hud.holeInfo(g).equals("Hole: safe (obsidian/bedrock all sides)"), "four obsidian/bedrock walls: " + Hud.holeInfo(g));
        g.walls.add(ModuleTest.FakeGame.k(0, 65, 0)); check(Hud.holeInfo(g).isEmpty(), "a block over your head is not a hole");
        g.walls.remove(ModuleTest.FakeGame.k(0, 65, 0)); g.unloadedChunks.add(((long) (1 >> 4) << 32) | ((0 >> 4) & 0xFFFFFFFFL)); g.unloadedChunks.add(((long) (0 >> 4) << 32) | ((0 >> 4) & 0xFFFFFFFFL));
        check(Hud.holeInfo(g).isEmpty(), "unloaded chunks give no hole info instead of guessing");
        g.inWorld = false; check(hud.get("hole").lines(c).isEmpty() && hud.get("compass").lines(c).isEmpty() && hud.get("potions").lines(c).isEmpty() && hud.get("server").lines(c).isEmpty(), "new elements are empty outside a world");
        g.inWorld = true; g.unloadedChunks.clear(); g.effects.add("Speed II 0:42"); check(hud.get("potions").lines(c).equals(List.of("Speed II 0:42")), "potion timers pass through");
        check(hud.get("server").lines(c).get(0).contains("Singleplayer"), "server element handles unknown address"); g.addr = "play.example.net"; check(hud.get("server").lines(c).equals(List.of("play.example.net")), "server element shows the address");
        hud.get("compass").enabled = false; check(hud.get("compass").lines(c).isEmpty(), "disabled HUD element draws nothing");
    }
}
