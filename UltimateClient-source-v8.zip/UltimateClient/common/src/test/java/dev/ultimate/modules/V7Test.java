package dev.ultimate.modules;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;
import dev.ultimate.hud.Hud;
import dev.ultimate.modules.combat.*;
import dev.ultimate.modules.misc.*;
import dev.ultimate.modules.movement.*;
import dev.ultimate.modules.player.*;
import dev.ultimate.modules.render.*;
import dev.ultimate.modules.world.*;
import dev.ultimate.util.BaritoneBridge;
import dev.ultimate.util.Holes;

import java.util.*;

/** Behaviour tests for the v7 batch. */
final class V7Test {
    private V7Test() {}
    static void check(boolean c, String m) { ModuleTest.check(c, m); }

    static final class G7 extends V6Test.G6 {
        boolean riding, boat, invScreen, disc; Vec3 vvel = Vec3.ZERO; int hovered = -1, useCd, brkCd, reconnects, interacted = -1; float prog; String reason = ""; List<BlockEntry> entries = new ArrayList<>(); long pktMs;
        @Override public boolean riding() { return riding; } @Override public boolean vehicleIsBoat() { return boat; }
        @Override public Vec3 vehicleVelocity() { return vvel; } @Override public void setVehicleVelocity(Vec3 v) { vvel = v; }
        @Override public boolean inventoryScreenOpen() { return invScreen; } @Override public int hoveredSlot() { return hovered; }
        @Override public boolean interactEntity(int id) { interacted = id; log.add("interact " + id); return true; }
        @Override public List<BlockEntry> blockEntities() { return entries; }
        @Override public int itemUseCooldown() { return useCd; } @Override public void setItemUseCooldown(int t) { useCd = t; }
        @Override public int breakCooldown() { return brkCd; } @Override public void setBreakCooldown(int t) { brkCd = t; }
        @Override public float breakProgress() { return prog; } @Override public void setBreakProgress(float p) { prog = p; }
        @Override public boolean disconnectScreenShown() { return disc; } @Override public String disconnectReason() { return reason; } @Override public void reconnect() { reconnects++; }
        @Override public long msSincePacket() { return pktMs; }
        @Override public ItemKind kindAt(int s) { return s < 9 ? hotbar[s] : main[s - 9]; }
    }
    static G7 world() { G7 g = new G7(); g.me = NewModuleTest.body(0.5, 64, 0.5, 0, 0, 0, true); return g; }
    static ModuleManager reg(Module... m) { return ModuleTest.reg(m); }
    static void ticks(ModuleManager mm, G7 g, int n) { for (int i = 0; i < n; i++) { g.tick++; mm.tick(); } }

    static void run() { states(); combat(); movement(); player(); render(); worldMods(); misc(); hud(); }

    static void states() {
        NameState.set("Steve", "Alex"); check(NameState.apply("Steve joined, steve left").equals("Alex joined, Alex left"), "name protect replaces all, case-insensitive");
        check(NameState.apply("St").equals("St") && NameState.apply(null) == null, "name protect handles short/null text"); NameState.clear(); check(NameState.apply("Steve").equals("Steve"), "name protect inactive passes text through");
        NameState.set("", "x"); check(!NameState.active(), "blank real name stays inactive");
        FriendManager fr = new FriendManager(); fr.add("pal"); FriendGuardState.set(fr, true, true);
        check(FriendGuardState.shouldBlock("pal", false) && !FriendGuardState.shouldBlock("pal", true) && !FriendGuardState.shouldBlock("foe", false) && !FriendGuardState.shouldBlock(null, false), "friend guard blocks friends only; sneak override lets it through");
        FriendGuardState.set(null, false, false); check(!FriendGuardState.shouldBlock("pal", false), "friend guard off blocks nothing");
        List<String> sent = new ArrayList<>(); BaritoneBridge.setBackend(new BaritoneBridge.Backend() { public boolean available() { return true; } public boolean execute(String c) { sent.add(c); return !c.startsWith("bad"); } });
        check(BaritoneBridge.execute("goto 1 64 1") == null && sent.equals(List.of("goto 1 64 1")), "baritone bridge forwards commands");
        check(BaritoneBridge.execute("bad x") != null && BaritoneBridge.execute("") != null && BaritoneBridge.execute("a\nb") != null, "baritone bridge reports rejected/empty/multiline commands");
        BaritoneBridge.setBackend(new BaritoneBridge.Backend() { public boolean available() { return false; } public boolean execute(String c) { return true; } });
        check(BaritoneBridge.execute("cancel").contains("not installed"), "baritone bridge explains when Baritone is missing");
        BaritoneBridge.setBackend(null); check(!BaritoneBridge.available(), "no Baritone class in the test JVM");
        G7 g = world(); sent.clear(); BaritoneBridge.setBackend(new BaritoneBridge.Backend() { public boolean available() { return true; } public boolean execute(String c) { sent.add(c); return true; } });
        Baritone b = new Baritone(g); ModuleManager mm = reg(b); b.setEnabled(true); ticks(mm, g, 2);
        check(sent.contains("set allowBreak true") && sent.contains("set allowParkour false") && sent.size() == 6, "baritone module pushes its 6 settings once: " + sent);
        sent.clear(); b.allowParkour.set(true); check(sent.equals(List.of("set allowBreak true", "set allowPlace true", "set allowSprint true", "set allowParkour true", "set freeLook false", "set chatControl false")), "changing a setting re-sends");
        sent.clear(); b.setEnabled(false); check(sent.equals(List.of("cancel")), "disabling cancels the path"); BaritoneBridge.setBackend(null);
        g = world(); b = new Baritone(g); mm = reg(b); b.setEnabled(true); ticks(mm, g, 3); check(g.msgs().stream().filter(m -> m.contains("not installed")).count() == 1 && b.isEnabled(), "missing Baritone: one message, no crash");
    }

    static void combat() {
        FriendManager fr = new FriendManager();
        // Crystal optimizer / macro
        G7 g = world(); g.ents.add(ModuleTest.FakeGame.crystal(50, 12.5, 64, 0.5)); g.crosshair = 50;
        CrystalOptimizer co = new CrystalOptimizer(g); ModuleManager mm = reg(co); co.setEnabled(true); ticks(mm, g, 1); check(g.count("attack 50") == 1, "optimizer hits the aimed crystal");
        g.log.clear(); g.crosshair = -1; ticks(mm, g, 1); check(g.count("attack") == 0, "optimizer ignores empty crosshair");
        g.crosshair = 50; g.ents.clear(); g.ents.add(ModuleTest.FakeGame.crystal(50, 1.5, 64, 0.5)); co.maxSelf.set(0.0); ticks(mm, g, 1); check(g.count("attack") == 0, "optimizer refuses crystals that would hurt me");
        g = world(); g.ents.add(ModuleTest.FakeGame.crystal(50, 12.5, 64, 0.5)); g.crosshair = 50; CrystalMacro cm = new CrystalMacro(g); mm = reg(cm); cm.setEnabled(true); ticks(mm, g, 1); check(g.count("attack 50") == 1, "macro hits aimed crystal");
        g = world(); g.hotbar[3] = ItemKind.END_CRYSTAL; g.target = new BlockPos(12, 63, 0); cm = new CrystalMacro(g); mm = reg(cm); cm.setEnabled(true); ticks(mm, g, 1);
        check(g.count("crystal 12,63,0") == 1 && g.sel == 3, "macro places on aimed obsidian and switches to crystals");
        g = world(); g.target = new BlockPos(12, 63, 0); cm = new CrystalMacro(g); mm = reg(cm); cm.setEnabled(true); ticks(mm, g, 1); check(g.count("crystal") == 0, "macro without crystals does nothing");
        // anchor macro
        g = world(); g.hotbar[2] = ItemKind.GLOWSTONE; g.hotbar[0] = ItemKind.SWORD; g.target = new BlockPos(20, 64, 0); g.charges.put(g.target, 0);
        SingleAnchorMacro sa = new SingleAnchorMacro(g); mm = reg(sa); sa.setEnabled(true); ticks(mm, g, 3); check(g.count("select 2") >= 1, "anchor macro charges with glowstone");
        g = world(); g.hotbar[2] = ItemKind.GLOWSTONE; g.target = new BlockPos(20, 64, 0); g.charges.put(g.target, 1); sa = new SingleAnchorMacro(g); mm = reg(sa); sa.setEnabled(true); ticks(mm, g, 3); check(g.count("select 0") >= 1, "anchor macro detonates with the detonate slot");
        g = world(); g.hotbar[0] = ItemKind.GLOWSTONE; g.target = new BlockPos(20, 64, 0); g.charges.put(g.target, 1); sa = new SingleAnchorMacro(g); mm = reg(sa); sa.setEnabled(true); ticks(mm, g, 3); check(g.sel != 0 || g.count("select 0") == 0, "anchor macro never detonates holding glowstone");
        // anti anchor / guard / bed / anvil
        g = world(); g.hotbar[3] = ItemKind.FILLER_BLOCK; g.charges.put(new BlockPos(3, 64, 0), 2); AntiAnchor af = new AntiAnchor(g); mm = reg(af); af.setEnabled(true); ticks(mm, g, 1); check(g.count("block 1,64,0") == 1, "anti anchor falls back to cobblestone-type blocks");
        g = world(); g.hotbar[3] = ItemKind.OBSIDIAN; g.charges.put(new BlockPos(3, 64, 0), 2); AntiAnchor aa = new AntiAnchor(g); mm = reg(aa); aa.setEnabled(true); ticks(mm, g, 1);
        check(g.count("block 1,64,0") == 1 && g.count("block 1,65,0") == 1, "anti anchor blocks toward the anchor at foot and head");
        g = world(); g.hotbar[3] = ItemKind.OBSIDIAN; AntiAnchor aa2 = new AntiAnchor(g); mm = reg(aa2); aa2.setEnabled(true); ticks(mm, g, 3); check(g.count("block") == 0, "anti anchor idle without anchors");
        g = world(); g.hotbar[3] = ItemKind.OBSIDIAN; g.charges.put(new BlockPos(5, 64, 5), 0); AnchorGuard ag = new AnchorGuard(g); mm = reg(ag); ag.setEnabled(true); ag.perTick.set(5.0); ticks(mm, g, 1);
        check(g.count("block") == 5 && g.count("block 0,66,0") == 1, "anchor guard seals 4 sides and the roof");
        g = world(); g.hotbar[3] = ItemKind.OBSIDIAN; g.blockIdMap.put("2,64,0", "minecraft:red_bed"); g.walls.add(ModuleTest.FakeGame.k(2, 64, 0)); AntiBed ab = new AntiBed(g); mm = reg(ab); ab.setEnabled(true); ticks(mm, g, 1); check(g.count("block 1,64,0") == 1, "anti bed blocks toward a bed");
        g = world(); g.hotbar[3] = ItemKind.OBSIDIAN; g.walls.add(ModuleTest.FakeGame.k(0, 66, 0)); g.blockIdMap.put("0,66,0", "minecraft:anvil"); AntiAnvil an = new AntiAnvil(g); mm = reg(an); an.setEnabled(true); g.walls.remove(ModuleTest.FakeGame.k(0, 66, 0)); ticks(mm, g, 1);
        check(g.count("block 0,66,0") == 0, "anti anvil does not place into an occupied cap spot");
        g = world(); g.hotbar[3] = ItemKind.OBSIDIAN; an = new AntiAnvil(g); mm = reg(an); an.always.set(true); an.setEnabled(true); ticks(mm, g, 1); check(g.count("block 0,66,0") == 1, "anti anvil always-mode caps the head");
        g = world(); g.hotbar[3] = ItemKind.OBSIDIAN; an = new AntiAnvil(g); mm = reg(an); an.setEnabled(true); ticks(mm, g, 2); check(g.count("block") == 0, "anti anvil idle without anvils");
        // auto anvil needs a hole target
        g = world(); g.hotbar[4] = ItemKind.ANVIL; g.ents.add(ModuleTest.FakeGame.player(9, "foe", 3.5, 64, 0.5)); int[][] d = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}; for (int[] o : d) g.walls.add(ModuleTest.FakeGame.k(3 + o[0], 64, o[1]));
        AutoAnvil aan = new AutoAnvil(g, fr); mm = reg(aan); aan.setEnabled(true); ticks(mm, g, 1); check(g.count("block 3,67,0") == 1, "auto anvil drops an anvil above an enemy in a hole");
        g = world(); g.hotbar[4] = ItemKind.ANVIL; g.ents.add(ModuleTest.FakeGame.player(9, "foe", 3.5, 64, 0.5)); aan = new AutoAnvil(g, fr); mm = reg(aan); aan.setEnabled(true); ticks(mm, g, 1); check(g.count("block") == 0, "auto anvil ignores enemies outside holes");
        // bed aura
        g = world(); g.me = new EntityInfo(0, EntityInfo.Kind.PLAYER, "me", new Vec3(0.5, 64, 0.5), Vec3.ZERO, 0.6, 1.8, 20f, 200f, 20, 12, 16, -1, true); g.hotbar[5] = ItemKind.BED; g.ents.add(ModuleTest.FakeGame.player(9, "foe", 3.5, 64, 0.5)); BedAura ba = new BedAura(g, fr); mm = reg(ba); ba.setEnabled(true); ba.minDamage.set(0.0); ba.maxSelf.set(36.0); ticks(mm, g, 1);
        check(g.count("block ") == 1, "bed aura places a bed next to the enemy"); ticks(mm, g, 2); check(g.sel == 0, "bed aura restores the slot after the detonate step");
        g = world(); g.ents.add(ModuleTest.FakeGame.player(9, "foe", 3.5, 64, 0.5)); ba = new BedAura(g, fr); mm = reg(ba); ba.setEnabled(true); ticks(mm, g, 3); check(g.count("block") == 0, "bed aura without beds does nothing");
        // criticals
        g = world(); g.crosshair = 9; Criticals cr = new Criticals(g); mm = reg(cr); cr.setEnabled(true); ticks(mm, g, 1); check(g.jumpIn, "criticals hops when charged and aiming at an entity");
        ticks(mm, g, 1); check(!g.jumpIn, "criticals releases jump"); g.cooldown = 0.4f; ticks(mm, g, 1); check(!g.jumpIn, "criticals waits for charge"); g.cooldown = 1f; g.crosshair = -1; ticks(mm, g, 1); check(!g.jumpIn, "criticals needs a target");
        // wtap
        g = world(); g.fwd = true; WTap wt = new WTap(g); mm = reg(wt); wt.setEnabled(true); g.cooldown = 1f; ticks(mm, g, 1); g.cooldown = 0.1f; ticks(mm, g, 1); check(g.count("sprint false") == 1, "w-tap drops sprint after a swing"); ticks(mm, g, 3); check(g.count("sprint true") == 1, "w-tap resumes sprint");
        g.log.clear(); g.cooldown = 1f; ticks(mm, g, 3); check(g.count("sprint") == 0, "w-tap idle without swings");
        // mace
        g = world(); g.hotbar[6] = ItemKind.MACE; g.crosshair = 9; g.fall = 3f; g.me = NewModuleTest.body(0.5, 70, 0.5, 0, -0.5, 0, false); Mace mc = new Mace(g); mm = reg(mc); mc.setEnabled(true); ticks(mm, g, 1); check(g.sel == 6, "mace equips while falling at a target");
        g.me = NewModuleTest.body(0.5, 64, 0.5, 0, 0, 0, true); ticks(mm, g, 1); check(g.sel == 0, "mace restores slot on landing");
        // totems
        g = world(); g.main[3] = ItemKind.TOTEM; AutoInvTotem ait = new AutoInvTotem(g); mm = reg(ait); ait.setEnabled(true); ticks(mm, g, 1); check(g.count("swap") == 0, "inventory totem waits for an open inventory"); g.invScreen = true; ticks(mm, g, 1); check(g.off == ItemKind.TOTEM, "inventory totem fills the offhand");
        g = world(); g.main[3] = ItemKind.TOTEM; g.invScreen = true; HoverTotem ht = new HoverTotem(g); mm = reg(ht); ht.setEnabled(true); ticks(mm, g, 1); check(g.off != ItemKind.TOTEM, "hover totem needs a hovered totem"); g.hovered = 12; ticks(mm, g, 1); check(g.off == ItemKind.TOTEM, "hover totem equips the hovered totem");
        FriendGuard fg = new FriendGuard(fr); mm = reg(fg); fg.setEnabled(true); fr.add("pal"); check(FriendGuardState.shouldBlock("pal", false), "friend guard module arms the state"); fg.setEnabled(false); check(!FriendGuardState.shouldBlock("pal", false), "friend guard module disarms the state");
    }

    static void movement() {
        G7 g = world(); g.me = NewModuleTest.body(0.5, 64, 0.5, 1, 0.4, 1, true); Velocity v = new Velocity(g); ModuleManager mm = reg(v); v.setEnabled(true); ticks(mm, g, 1); check(g.vel == null, "velocity idle until hit");
        g.hurt = 10; ticks(mm, g, 1); check(g.vel != null && g.vel.x() == 0 && g.vel.z() == 0 && g.vel.y() == 0.4, "velocity removes horizontal, keeps vertical"); g.vel = null; ticks(mm, g, 1); check(g.vel == null, "velocity acts once per hit");
        g = world(); g.glide = true; g.fwd = true; g.me = NewModuleTest.body(0.5, 80, 0.5, 0, 0, 0.5, false); ElytraBoost eb = new ElytraBoost(g); mm = reg(eb); eb.setEnabled(true); ticks(mm, g, 1); check(g.vel != null && g.vel.z() > 0.5, "elytra boost accelerates along view");
        g.vel = null; g.me = NewModuleTest.body(0.5, 80, 0.5, 0, 0, 2.0, false); ticks(mm, g, 1); check(g.vel == null, "elytra boost respects the speed cap"); g.glide = false; g.me = NewModuleTest.body(0.5, 80, 0.5, 0, 0, 0.1, false); ticks(mm, g, 1); check(g.vel == null, "elytra boost only while gliding");
        g = world(); g.riding = g.boat = true; g.jumping = true; BoatFly bf = new BoatFly(g); mm = reg(bf); bf.setEnabled(true); ticks(mm, g, 1); check(g.vvel.y() == 0.3, "boat fly climbs on jump");
        g.jumping = false; g.sneaking = true; ticks(mm, g, 1); check(g.vvel.y() == -0.3, "boat fly descends on sneak"); g.sneaking = false; ticks(mm, g, 1); check(g.vvel.y() == 0, "boat fly hovers"); g.fwd = true; g.yaw = 0; ticks(mm, g, 1); check(Math.abs(g.vvel.z() - 0.8) < 1e-9, "boat fly drives forward");
        g.boat = false; g.vvel = Vec3.ZERO; ticks(mm, g, 1); check(g.vvel.equals(Vec3.ZERO), "boat fly ignores non-boats");
        g = world(); g.riding = true; g.fwd = true; EntitySpeed es = new EntitySpeed(g); mm = reg(es); es.setEnabled(true); ticks(mm, g, 1); check(Math.abs(g.vvel.z() - 0.5) < 1e-9, "entity speed drives the mount"); g.riding = false; g.vvel = Vec3.ZERO; ticks(mm, g, 1); check(g.vvel.equals(Vec3.ZERO), "entity speed needs a mount");
        g = world(); g.invScreen = true; g.heldKeys.addAll(List.of(87, 32)); GuiMove gm = new GuiMove(g); mm = reg(gm); gm.setEnabled(true); ticks(mm, g, 1); check(g.forced && g.jumpIn && !g.sneakIn, "gui move forwards held keys while the inventory is open");
        g.invScreen = false; ticks(mm, g, 1); check(!g.forced && !g.jumpIn, "gui move hands control back when the screen closes"); g.invScreen = true; ticks(mm, g, 1); gm.setEnabled(false); check(!g.forced, "gui move releases on disable");
    }

    static void player() {
        G7 g = world(); g.useCd = 4; FastUse fu = new FastUse(g); ModuleManager mm = reg(fu); fu.setEnabled(true); ticks(mm, g, 1); check(g.useCd == 0, "fast use clears the delay");
        g = world(); g.useCd = 4; FastXp fx = new FastXp(g); mm = reg(fx); fx.setEnabled(true); ticks(mm, g, 1); check(g.useCd == 4, "fast xp leaves other items alone"); g.hotbar[0] = ItemKind.EXP_BOTTLE; ticks(mm, g, 1); check(g.useCd == 0, "fast xp speeds up bottles");
        g = world(); g.brkCd = 5; BreakDelay bd = new BreakDelay(g); mm = reg(bd); bd.setEnabled(true); bd.delay.set(2.0); ticks(mm, g, 1); check(g.brkCd == 2, "break delay caps the delay");
        g = world(); g.mining = true; g.prog = 0.5f; SpeedMine sm = new SpeedMine(g); mm = reg(sm); sm.setEnabled(true); ticks(mm, g, 1); check(Math.abs(g.prog - 0.55f) < 1e-5, "speed mine adds progress"); g.prog = 0.99f; ticks(mm, g, 1); check(g.prog < 1f, "speed mine never completes the block itself");
        g.mining = false; g.prog = 0.5f; ticks(mm, g, 1); check(g.prog == 0.5f, "speed mine only while mining");
    }

    static void render() {
        FriendManager fr = new FriendManager(); fr.add("pal"); G7 g = world(); RenderQueue q = new RenderQueue();
        g.ents.add(ModuleTest.FakeGame.player(1, "foe", 5.5, 64, 0.5)); g.ents.add(ModuleTest.FakeGame.player(2, "pal", 8.5, 64, 0.5)); g.ents.add(ModuleTest.FakeGame.player(3, "far", 150.5, 64, 0.5));
        PlayerEsp pe = new PlayerEsp(g, fr); ModuleManager mm = reg(pe); pe.setEnabled(true); mm.render(q);
        check(q.boxes().size() == 2 && q.labels().size() == 2, "player esp draws near players only (" + q.boxes().size() + ")"); check(q.boxes().get(0).argb() != q.boxes().get(1).argb(), "friends use their own colour");
        check((q.boxes().get(0).argb() >>> 24) == Math.round(0.6 * 255), "opacity setting controls alpha");
        q.clear(); pe.labels.set(false); pe.distance.set(6.0); mm.render(q); check(q.boxes().size() == 1 && q.labels().isEmpty(), "distance limit and labels toggle work");
        q.clear(); pe.distance.set(256.0); pe.maxDraw.set(10.0); for (int i = 0; i < 40; i++) g.ents.add(ModuleTest.FakeGame.player(100 + i, "p" + i, 5 + i % 9, 64, 5)); mm.render(q); check(q.boxes().size() <= 10, "max-draw caps shapes");
        pe.style.set("Fill"); q.clear(); mm.render(q); check(q.boxes().get(0).style() == RenderQueue.Style.FILL, "style setting is passed to the renderer");
        pe.setEnabled(false); q.clear(); mm.render(q); check(q.size() == 0, "disabled esp draws nothing"); g.inWorld = false; pe.setEnabled(true); mm.render(q); check(q.size() == 0, "esp draws nothing outside a world");
        RenderQueue big = new RenderQueue(); for (int i = 0; i < RenderQueue.MAX + 10; i++) big.line(Vec3.ZERO, Vec3.ZERO, 0, 1); check(big.size() == RenderQueue.MAX, "render queue is bounded");
        // entity / item / tracers / nametags / target
        g = world(); g.ents.add(new EntityInfo(7, EntityInfo.Kind.HOSTILE, "Zombie", new Vec3(4.5, 64, 0.5), Vec3.ZERO, .6, 1.8, 20, 0, 0, 0, 0, -1, true)); g.ents.add(new EntityInfo(8, EntityInfo.Kind.ITEM, "Diamond", new Vec3(2.5, 64, 0.5), Vec3.ZERO, .25, .25, 1, 0, 0, 0, 0, -1, false));
        g.ents.add(ModuleTest.FakeGame.player(1, "foe", 5.5, 64, 0.5)); EntityEsp ee = new EntityEsp(g); ItemEsp ie = new ItemEsp(g); Tracers tr = new Tracers(g, fr); Nametags nt = new Nametags(g, fr); TargetEsp te = new TargetEsp(g, fr); mm = reg(ee, ie, tr, nt, te);
        for (Module m : List.of(ee, ie, tr, nt, te)) m.setEnabled(true); q = new RenderQueue(); mm.render(q); check(q.boxes().size() == 3 && q.lines().size() == 1, "entity/item/target boxes + one tracer: " + q.boxes().size() + "/" + q.lines().size());
        check(q.labels().stream().anyMatch(l -> l.text().startsWith("foe")) && q.labels().stream().anyMatch(l -> l.text().contains("Zombie")), "labels carry names");
        // storage + block esp + scan
        g = world(); g.entries.add(new BlockEntry(new BlockPos(3, 64, 3), "minecraft:chest")); g.entries.add(new BlockEntry(new BlockPos(4, 64, 3), "minecraft:sign")); StorageEsp se = new StorageEsp(g); mm = reg(se); se.setEnabled(true); q = new RenderQueue(); mm.render(q); check(q.boxes().size() == 1, "storage esp filters by type");
        g = world(); g.walls.add(ModuleTest.FakeGame.k(4, 70, 4)); g.blockIdMap.put("4,70,4", "minecraft:diamond_ore"); BlockEsp be = new BlockEsp(g); mm = reg(be); be.setEnabled(true); be.budget.set(5000.0); ticks(mm, g, 12); q = new RenderQueue(); mm.render(q);
        check(q.boxes().size() == 1, "block esp finds ore within its scan (" + q.boxes().size() + ")"); be.blocks.set("emerald"); ticks(mm, g, 12); q.clear(); mm.render(q); check(q.boxes().isEmpty(), "changing the block list drops old results");
        g = world(); g.walls.add(ModuleTest.FakeGame.k(4, 70, 4)); g.blockIdMap.put("4,70,4", "minecraft:ancient_debris"); NetheriteFinder nf = new NetheriteFinder(g); mm = reg(nf); nf.setEnabled(true); nf.budget.set(5000.0); ticks(mm, g, 12); q = new RenderQueue(); mm.render(q); check(q.boxes().size() == 1, "netherite finder finds debris");
        g = world(); g.walls.add(ModuleTest.FakeGame.k(4, 70, 4)); g.blockIdMap.put("4,70,4", "minecraft:spawner"); SpawnerEsp sp = new SpawnerEsp(g); mm = reg(sp); sp.setEnabled(true); sp.budget.set(5000.0); ticks(mm, g, 12); q = new RenderQueue(); mm.render(q); check(q.boxes().size() == 1, "spawner esp finds spawners");
        // holes
        g = world(); for (int[] o : d4()) g.walls.add(ModuleTest.FakeGame.k(o[0], 64, o[1])); check(Holes.classify(g, 0, 64, 0) == Holes.MIXED, "hole with stone sides is mixed"); g.hardWalls = true; check(Holes.classify(g, 0, 64, 0) == Holes.SAFE, "hole with obsidian sides is safe");
        HoleEsp he = new HoleEsp(g); mm = reg(he); he.setEnabled(true); ticks(mm, g, 1); q = new RenderQueue(); mm.render(q); check(q.boxes().size() >= 1, "hole esp marks the hole");
        // city esp
        g = world(); g.ents.add(ModuleTest.FakeGame.player(9, "foe", 4.5, 64, 0.5)); for (int[] o : d4()) g.walls.add(ModuleTest.FakeGame.k(4 + o[0], 64, o[1])); CityEsp ce = new CityEsp(g, fr); mm = reg(ce); ce.setEnabled(true); q = new RenderQueue(); mm.render(q); check(q.boxes().size() == 4, "city esp marks the 4 sides of a holed enemy");
        // trajectories
        double[] ph = Trajectories.physics("minecraft:ender_pearl"); check(ph != null && ph[0] == 1.5 && Trajectories.physics("minecraft:stick") == null && Trajectories.physics(null) == null, "projectile physics table");
        g = world(); List<Vec3> pts = Trajectories.simulate(g, new Vec3(0.5, 66, 0.5), new Vec3(1, 0, 0), 0.03, 0.99, 100); check(pts.size() > 3 && pts.size() < 101 && pts.get(pts.size() - 1).y() < 64.5, "projectile falls and stops in the ground");
        g.walls.clear(); List<Vec3> flat = Trajectories.simulate(g, new Vec3(0.5, 100, 0.5), new Vec3(0, 0, 1), 0, 1, 5); check(flat.size() == 6, "projectile runs the full step count in open air");
        g = world(); g.ids[0] = "minecraft:ender_pearl"; Trajectories tj = new Trajectories(g); mm = reg(tj); tj.setEnabled(true); q = new RenderQueue(); mm.render(q); check(q.lines().size() > 3 && q.boxes().size() == 1, "trajectories draw a path and landing box");
        g.ids[0] = "minecraft:stick"; q.clear(); mm.render(q); check(q.size() == 0, "trajectories draw nothing for non-projectiles");
        g = world(); g.ents.add(new EntityInfo(60, EntityInfo.Kind.OTHER, "Ender Pearl", new Vec3(0.5, 70, 0.5), new Vec3(0.8, 0.2, 0), .25, .25, 1, 0, 0, 0, 0, -1, false)); PearlTrajectory pt = new PearlTrajectory(g); mm = reg(pt); pt.setEnabled(true); q = new RenderQueue(); mm.render(q); check(q.boxes().size() == 1 && q.labels().size() == 1, "pearl trajectory marks the landing of a flying pearl");
        // breadcrumbs
        g = world(); Breadcrumbs bc = new Breadcrumbs(g); mm = reg(bc); bc.setEnabled(true); for (int i = 0; i < 6; i++) { g.me = NewModuleTest.body(0.5 + i * 2, 64, 0.5, 0, 0, 0, true); ticks(mm, g, 1); } q = new RenderQueue(); mm.render(q); check(q.lines().size() == 5, "breadcrumbs connect recorded points"); bc.length.set(20.0); mm.onWorldLeave(); q.clear(); mm.render(q); check(q.lines().isEmpty(), "breadcrumbs clear when leaving the world");
        // logout spots
        g = world(); g.ents.add(ModuleTest.FakeGame.player(1, "foe", 5.5, 64, 0.5)); g.players.add("foe"); LogoutSpots ls = new LogoutSpots(g); mm = reg(ls); ls.setEnabled(true); ticks(mm, g, 1);
        g.ents.clear(); ticks(mm, g, 1); check(ls.count() == 0, "leaving render range while still online is not a logout"); g.ents.add(ModuleTest.FakeGame.player(1, "foe", 5.5, 64, 0.5)); ticks(mm, g, 1); g.ents.clear(); g.players.clear(); g.players.add("other"); ticks(mm, g, 1); check(ls.count() == 1, "vanishing from the player list records a logout spot");
        q = new RenderQueue(); mm.render(q); check(q.boxes().size() == 1 && q.labels().get(0).text().startsWith("foe"), "logout spot is drawn and labelled");
        g = world(); g.ents.add(ModuleTest.FakeGame.player(1, "foe", 5.5, 64, 0.5)); ls = new LogoutSpots(g); mm = reg(ls); ls.setEnabled(true); ticks(mm, g, 1); g.ents.clear(); ticks(mm, g, 1); check(ls.count() == 0, "no player list means no guessing");
        // waypoints
        g = world(); g.me = NewModuleTest.body(10.5, 70, -3.5, 0, 0, 0, true); Waypoints wp = new Waypoints(g); mm = reg(wp); wp.setEnabled(true);
        check(wp.addHere("base") == null && wp.addHere("Base") != null && wp.addHere("") != null && wp.addHere(null) != null, "waypoint add / duplicate / empty handling");
        check(Waypoints.cleanName("a b|c;d").equals("abcd"), "waypoint names lose separators");
        check(wp.list().size() >= 1 && wp.find("BASE").x() == 10 && wp.find("base").y() == 70 && wp.find("base").z() == -4, "waypoint stored with block coordinates");
        String saved = wp.data.get(); Waypoints wp2 = new Waypoints(g); wp2.data.set(saved); check(wp2.find("base") != null, "waypoints persist through the setting string"); wp2.data.set("junk;a|1|2;b|x|y|z;ok|1|2|3;"); check(wp2.list().size() == 1, "corrupt waypoint entries are skipped");
        check(wp.remove("base") && !wp.remove("base"), "waypoint removal"); wp.addHere("home"); q = new RenderQueue(); mm.render(q); check(q.boxes().size() == 1 && q.labels().get(0).text().startsWith("home"), "waypoints are drawn with a distance label");
        // block overlay / light overlay
        g = world(); g.target = new BlockPos(2, 64, 0); BlockOverlay bo = new BlockOverlay(g); mm = reg(bo); bo.setEnabled(true); q = new RenderQueue(); mm.render(q); check(q.boxes().size() == 1, "block overlay outlines the aimed block"); g.target = null; q.clear(); mm.render(q); check(q.size() == 0, "block overlay needs a target");
        g = world(); g.dark = true; LightOverlay lo = new LightOverlay(g); mm = reg(lo); lo.setEnabled(true); ticks(mm, g, 1); q = new RenderQueue(); mm.render(q); check(q.boxes().size() > 0 && q.boxes().size() <= lo.maxDraw.asInt(), "light overlay marks dark floor tiles within the draw cap");
        // custom fov
        g = world(); CustomFov cf = new CustomFov(g); mm = reg(cf); cf.fov.set(90.0); cf.setEnabled(true); ticks(mm, g, 1); check(g.fovVal == 90, "custom fov applies"); cf.setEnabled(false); check(g.fovVal == 70, "custom fov restores the original");
    }
    static int[][] d4() { return new int[][]{{1, 0}, {-1, 0}, {0, 1}, {0, -1}}; }

    static void worldMods() {
        FriendManager fr = new FriendManager();
        G7 g = world(); for (int i = 0; i < 9; i++) g.entries.add(new BlockEntry(new BlockPos(i, 64, 1), "minecraft:chest")); g.entries.add(new BlockEntry(new BlockPos(100, 64, 100), "minecraft:chest"));
        StashFinder sf = new StashFinder(g); ModuleManager mm = reg(sf); sf.setEnabled(true); ticks(mm, g, 1); check(sf.found.size() == 1 && g.msgs().stream().anyMatch(m -> m.contains("Stash? 9 containers in chunk 0,0")), "stash finder reports a dense chunk once");
        int n = g.msgs().size(); ticks(mm, g, 80); check(g.msgs().size() == n, "stash finder does not repeat itself");
        g = world(); g.hotbar[1] = ItemKind.PICKAXE; g.blockIdMap.put("2,64,0", "minecraft:ender_chest"); g.walls.add(ModuleTest.FakeGame.k(2, 64, 0)); EChestFarmer ec = new EChestFarmer(g); mm = reg(ec); ec.setEnabled(true); ticks(mm, g, 1); check(g.sel == 1, "e-chest farmer picks the pickaxe"); ec.setEnabled(false); check(g.sel == 0, "e-chest farmer restores the slot");
        g = world(); g.blockIdMap.put("2,64,0", "minecraft:ender_chest"); g.walls.add(ModuleTest.FakeGame.k(2, 64, 0)); ec = new EChestFarmer(g); mm = reg(ec); ec.setEnabled(true); ticks(mm, g, 2); check(g.sel == 0, "e-chest farmer needs a pickaxe");
        // excavator
        g = world(); Excavator ex = new Excavator(g); mm = reg(ex); g.me = NewModuleTest.body(0.5, 66, 0.5, 0, 0, 0, true); check(ex.setPos(1, false).startsWith("pos1"), "excavator pos1"); g.me = NewModuleTest.body(1.5, 64, 1.5, 0, 0, 0, true); ex.setPos(2, false); check(ex.volume() == 2 * 3 * 2, "excavator volume " + ex.volume());
        g.me = NewModuleTest.body(0.5, 67, 0.5, 0, 0, 0, true); ex.setEnabled(true); ticks(mm, g, 1); check(g.count("look") >= 0, "excavator runs with an area set"); ex.setPos(0, true); check(ex.pos1() == null, "excavator clear");
        g = world(); ex = new Excavator(g); mm = reg(ex); ex.setEnabled(true); check(g.isEnabledMsg("set the area"), "excavator tells you to set an area"); ticks(mm, g, 2);
        // waypoint nav
        g = world(); WaypointNav nav = new WaypointNav(g); mm = reg(nav); nav.setTarget("far", 0, 64, 20); nav.setEnabled(true); ticks(mm, g, 1); check(g.forced && Math.abs(g.yaw) < 1 , "waypoint nav faces the target and walks");
        g.hcol = true; ticks(mm, g, 1); check(g.jumpIn, "waypoint nav hops obstacles"); g.me = NewModuleTest.body(0.5, 64, 19.5, 0, 0, 0, true); ticks(mm, g, 1); check(!nav.isEnabled() && !g.forced && g.isEnabledMsg("Arrived"), "waypoint nav stops on arrival");
        // shearer / breed / mount
        g = world(); g.hotbar[2] = ItemKind.SHEARS; g.ents.add(new EntityInfo(70, EntityInfo.Kind.PASSIVE, "Sheep", new Vec3(2.5, 64, 0.5), Vec3.ZERO, .9, 1.3, 8, 0, 0, 0, 0, -1, false)); AutoShearer as = new AutoShearer(g); mm = reg(as); as.setEnabled(true); ticks(mm, g, 1);
        check(g.interacted == 70 && g.sel == 2, "auto shearer shears the sheep"); g.interacted = -1; ticks(mm, g, 3); check(g.interacted == -1, "auto shearer waits out the cooldown"); check(g.sel == 0, "auto shearer restores the slot");
        g = world(); g.ids[3] = "minecraft:wheat"; g.ents.add(new EntityInfo(71, EntityInfo.Kind.PASSIVE, "Cow", new Vec3(2.5, 64, 0.5), Vec3.ZERO, .9, 1.4, 10, 0, 0, 0, 0, -1, false)); AutoBreed abr = new AutoBreed(g); mm = reg(abr); abr.setEnabled(true); ticks(mm, g, 1); check(g.interacted == 71 && g.sel == 3, "auto breed feeds a cow wheat");
        g = world(); g.ids[3] = "minecraft:wheat_seeds"; g.ents.add(new EntityInfo(71, EntityInfo.Kind.PASSIVE, "Cow", new Vec3(2.5, 64, 0.5), Vec3.ZERO, .9, 1.4, 10, 0, 0, 0, 0, -1, false)); abr = new AutoBreed(g); mm = reg(abr); abr.setEnabled(true); ticks(mm, g, 1); check(g.interacted == -1, "auto breed does not feed seeds to cows");
        check(AutoBreed.foods("Pig").contains("carrot") && AutoBreed.foods("Chicken").contains("seeds") && AutoBreed.foods("Zombie").isEmpty(), "breeding food table");
        g = world(); g.ents.add(new EntityInfo(72, EntityInfo.Kind.PASSIVE, "Horse", new Vec3(2.0, 64, 0.5), Vec3.ZERO, 1.4, 1.6, 15, 0, 0, 0, 0, -1, false)); AutoMount am = new AutoMount(g); mm = reg(am); am.setEnabled(true); ticks(mm, g, 1); check(g.interacted == 72, "auto mount boards the horse"); g.interacted = -1; g.riding = true; ticks(mm, g, 30); check(g.interacted == -1, "auto mount does nothing while riding");
    }

    static void misc() {
        G7 g = world(); g.inWorld = false; g.disc = true; AutoReconnect ar = new AutoReconnect(g); ModuleManager mm = reg(ar); ar.seconds.set(1.0); ar.setEnabled(true); ticks(mm, g, 19); check(g.reconnects == 0, "auto reconnect waits"); ticks(mm, g, 2); check(g.reconnects == 1, "auto reconnect reconnects after the delay");
        ticks(mm, g, 100); check(g.reconnects >= 2 && g.reconnects <= 5, "auto reconnect retries but is bounded (" + g.reconnects + ")"); ticks(mm, g, 1000); check(g.reconnects == 5, "auto reconnect gives up after max attempts"); g.inWorld = true; ticks(mm, g, 1); check(true, "auto reconnect resets once connected");
        g = world(); g.inWorld = false; g.disc = false; ar = new AutoReconnect(g); mm = reg(ar); ar.setEnabled(true); ticks(mm, g, 500); check(g.reconnects == 0, "auto reconnect idle without a disconnect screen");
        g = world(); g.inWorld = false; g.disc = true; g.reason = "Server is restarting"; AutoRelog rl = new AutoRelog(g); mm = reg(rl); rl.baseSeconds.set(1.0); rl.setEnabled(true); ticks(mm, g, 21); check(g.reconnects == 1, "auto relog reconnects on a matching reason");
        ticks(mm, g, 30); check(g.reconnects == 1, "auto relog backs off (second wait is longer)"); g.reason = "You are banned"; g.reconnects = 0; ticks(mm, g, 500); check(g.reconnects == 0, "auto relog ignores non-matching reasons");
        check(AutoRelog.matches("Lost Connection", "lost, x") && !AutoRelog.matches("Banned", "lost") && !AutoRelog.matches(null, "lost") && !AutoRelog.matches("x", ""), "auto relog reason matching");
        g = world(); NameProtect np = new NameProtect(g); mm = reg(np); np.setEnabled(true); ticks(mm, g, 1); check(NameState.apply("me says hi").equals("Player says hi"), "name protect hides your name"); np.fake.set("Bob"); ticks(mm, g, 1); check(NameState.apply("me").equals("Bob"), "name protect follows the setting");
        np.setEnabled(false); check(NameState.apply("me").equals("me"), "name protect clears on disable"); np.setEnabled(true); ticks(mm, g, 1); mm.onWorldLeave(); check(NameState.apply("me").equals("me"), "name protect clears when leaving the world"); NameState.clear();
    }

    static void hud() {
        G7 g = world(); g.ents.add(ModuleTest.FakeGame.player(1, "bob", 10.5, 64, 0.5)); g.ents.add(ModuleTest.FakeGame.player(2, "al", 3.5, 64, 0.5)); g.ents.add(ModuleTest.FakeGame.player(3, "far", 400.5, 64, 0.5));
        List<String> r = Hud.radar(g, 60, 6); check(r.size() == 2 && r.get(0).startsWith("al 3m") && r.get(1).startsWith("bob 10m"), "radar lists nearby players nearest first: " + r);
        check(Hud.radar(g, 60, 1).size() == 1, "radar line cap");
        g.hotbar[0] = ItemKind.TOTEM; g.hotbar[1] = ItemKind.END_CRYSTAL; check(Hud.inventory(g).equals(List.of("Totems 1", "Crystals 1")), "inventory summary: " + Hud.inventory(g));
        ModuleManager mm = reg(); Hud hud = new Hud(); Hud.Ctx c = new Hud.Ctx(g, mm);
        check(hud.get("radar") != null && hud.get("inventory") != null && hud.get("lag") != null && hud.get("target") != null && hud.get("combat") != null, "new hud elements exist");
        check(hud.get("lag").lines(c).isEmpty(), "lag notifier quiet when packets arrive"); g.pktMs = 2500; check(hud.get("lag").lines(c).get(0).contains("2.5s"), "lag notifier reports silence"); g.pktMs = 0;
        check(hud.get("target").lines(c).get(0).startsWith("al"), "target info shows the nearest player"); check(hud.get("combat").lines(c).get(0).contains("Totems 1"), "combat info shows counts when a foe is near");
        g.inWorld = false; check(hud.get("radar").lines(c).isEmpty() && hud.get("target").lines(c).isEmpty() && hud.get("combat").lines(c).isEmpty() && hud.get("inventory").lines(c).isEmpty() && hud.get("lag").lines(c).isEmpty(), "new hud elements are empty outside a world");
    }
}
