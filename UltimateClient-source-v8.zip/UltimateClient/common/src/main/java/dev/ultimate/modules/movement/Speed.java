package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Drives horizontal velocity while moving forward. Servers may reject this; use where allowed. */
public final class Speed extends Module {
    public final Setting.Num speed = add(Setting.Num.dbl("speed", "Horizontal speed (blocks/tick; walking is ~0.22)", 0.35, 0.1, 1.5, 0.05));
    public final Setting.Bool inWater = add(new Setting.Bool("in-water", "Work in water", false));
    private final Game game;
    public Speed(Game g) { super("speed", "Speed", "Increases forward movement speed.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.movingForward() || (game.inWater() && !inWater.get())) return;
        double yaw = Math.toRadians(game.yaw()); Vec3 v = game.self().velocity();
        game.setVelocity(new Vec3(-Math.sin(yaw) * speed.get(), v.y(), Math.cos(yaw) * speed.get()));
    }
}
