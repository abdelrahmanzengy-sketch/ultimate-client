package dev.ultimate.modules.misc;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Sends a chat message or command once, or repeatedly (at least every 2 seconds, to respect server chat limits). */
public final class ChatMacro extends Module {
    public final Setting.Str message = add(new Setting.Str("message", "Message or /command to send", "", 256));
    public final Setting.Mode mode = add(new Setting.Mode("mode", "Send once then turn off, or repeat", "Once", "Once", "Repeat"));
    public final Setting.Num interval = add(Setting.Num.intg("interval", "Ticks between repeats (min 40)", 200, 40, 24000));
    private final Game game; private long last;
    public ChatMacro(Game g) { super("chat-macro", "Chat Macro", "Sends a saved chat message.", Category.MISC); game = g; }
    @Override protected void onEnable() {
        last = game.inWorld() ? game.tick() : 0;
        if (message.get().isBlank()) { if (game.inWorld()) game.message("Chat Macro: message is empty"); setEnabled(false); return; }
        if (!game.inWorld()) { setEnabled(false); return; }
        game.sendChat(message.get());
        if (mode.get().equals("Once")) setEnabled(false);
    }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !mode.get().equals("Repeat")) return;
        long now = game.tick(); if (now - last < interval.asInt()) return;
        game.sendChat(message.get()); last = now;
    }
}
