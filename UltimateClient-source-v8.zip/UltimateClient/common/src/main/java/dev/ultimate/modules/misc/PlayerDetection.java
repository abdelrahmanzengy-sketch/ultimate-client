package dev.ultimate.modules.misc;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Tells you in chat when a player comes into or leaves detection range. */
public final class PlayerDetection extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Detection radius", 64.0, 8.0, 256.0, 4.0));
    public final Setting.Bool ignoreFriends = add(new Setting.Bool("ignore-friends", "Do not announce friends", true));
    public final Setting.Bool leaves = add(new Setting.Bool("announce-leave", "Also announce when they leave", true));
    private final Game game; private final FriendManager friends; private final java.util.Set<String> seen = new java.util.HashSet<>(), now = new java.util.HashSet<>();
    public PlayerDetection(Game g, FriendManager f) { super("player-detection", "Player Detection", "Announces players entering your range.", Category.MISC); game = g; friends = f; }
    @Override protected void onEnable() { seen.clear(); }
    @Override protected void onDisable() { seen.clear(); }
    @Override protected void onWorldLeave() { seen.clear(); }
    @Override protected void onTick() {
        if (!game.inWorld()) return;
        EntityInfo me = game.self(); now.clear();
        for (EntityInfo e : game.entities()) {
            if (e.kind() != EntityInfo.Kind.PLAYER || e.pos().distanceTo(me.pos()) > range.get()) continue;
            if (ignoreFriends.get() && friends.isFriend(e.name())) continue;
            now.add(e.name());
            if (seen.add(e.name())) game.message(e.name() + " entered range (" + Math.round(e.pos().distanceTo(me.pos())) + " blocks)");
        }
        for (java.util.Iterator<String> it = seen.iterator(); it.hasNext(); ) {
            String n = it.next();
            if (!now.contains(n)) { it.remove(); if (leaves.get()) game.message(n + " left range"); }
        }
    }
}
