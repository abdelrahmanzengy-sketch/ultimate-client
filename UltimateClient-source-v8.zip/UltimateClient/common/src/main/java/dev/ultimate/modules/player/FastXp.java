package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Like Fast Use, but only while you hold experience bottles, so other items keep their normal delay. */
public final class FastXp extends Module {
    public final Setting.Num cooldown = add(Setting.Num.intg("cooldown", "Maximum ticks between throws", 0, 0, 4));
    private final Game game;
    public FastXp(Game g) { super("fast-xp", "Fast XP", "Throws experience bottles without the delay.", Category.PLAYER); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.mainHand() != ItemKind.EXP_BOTTLE && game.offhand() != ItemKind.EXP_BOTTLE) return;
        if (game.itemUseCooldown() > cooldown.asInt()) game.setItemUseCooldown(cooldown.asInt());
    }
}
