package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Raises the step height so you walk up blocks without jumping. Restores the original value on disable. */
public final class Step extends Module {
    public final Setting.Num height = add(Setting.Num.dbl("height", "Step height in blocks", 1.0, 0.6, 2.5, 0.1));
    private final Game game; private float original = -1;
    public Step(Game g) { super("step", "Step", "Walk up blocks instantly.", Category.MOVEMENT); game = g; }
    @Override protected void onEnable() { original = -1; }
    @Override protected void onDisable() { if (original >= 0 && game.inWorld()) game.setStepHeight(original); original = -1; }
    @Override protected void onWorldLeave() { original = -1; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        float cur = game.stepHeight();
        if (original < 0) original = cur;   // remember the value we found, once, to restore on disable
        if (cur != height.asFloat()) game.setStepHeight(height.asFloat());
    }
}
