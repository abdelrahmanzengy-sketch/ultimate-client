package dev.ultimate.modules.movement;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;

/** Pulls you down quickly when you walk off a short ledge, so you do not float down it. */
public final class ReverseStep extends Module {
    public final Setting.Num maxDrop = add(Setting.Num.intg("max-drop", "Only for drops of at most this many blocks", 2, 1, 4));
    public final Setting.Num pull = add(Setting.Num.dbl("pull", "Downward speed (blocks/tick)", 0.8, 0.1, 2.0, 0.1));
    private final Game game; private boolean wasGround;
    public ReverseStep(Game g) { super("reverse-step", "Reverse Step", "Drop off ledges quickly.", Category.MOVEMENT); game = g; }
    @Override protected void onEnable() { wasGround = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo me = game.self(); boolean g = me.onGround();
        if (wasGround && !g && me.velocity().y() <= 0 && !game.inWater() && !game.gliding() && !game.jumping()) {
            int x = (int) Math.floor(me.pos().x()), z = (int) Math.floor(me.pos().z()), y = (int) Math.floor(me.pos().y());
            if (game.isLoaded(x, z)) for (int i = 1; i <= maxDrop.asInt() + 1; i++)
                if (game.isSolid(x, y - i, z)) { if (i <= maxDrop.asInt() + 1 && i > 1) game.setVelocity(new Vec3(me.velocity().x(), -pull.get(), me.velocity().z())); break; }
        }
        wasGround = g;
    }
}
