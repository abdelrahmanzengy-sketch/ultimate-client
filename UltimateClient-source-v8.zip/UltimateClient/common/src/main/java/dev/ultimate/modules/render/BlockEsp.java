package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Highlights blocks you name (ore, spawners, anything) using a budgeted scan so it stays cheap on phones. */
public class BlockEsp extends EspModule {
    public final Setting.Str blocks;
    public final Setting.Num radius = add(Setting.Num.intg("scan-radius", "Horizontal scan radius", 16, 4, 48));
    public final Setting.Num height = add(Setting.Num.intg("scan-height", "Vertical scan range up and down", 16, 4, 48));
    public final Setting.Num budget = add(Setting.Num.intg("scan-budget", "Blocks examined per tick (lower = faster)", 600, 100, 5000));
    private final BlockScan scan; private List<String> frags = new ArrayList<>(); private String lastSetting = null;
    public BlockEsp(Game g) { this(g, "block-esp", "Block ESP", "Highlights chosen blocks.", "diamond_ore,emerald_ore,ancient_debris"); }
    protected BlockEsp(Game g, String id, String name, String desc, String defaultBlocks) {
        super(id, name, desc, g); blocks = add(new Setting.Str("blocks", "Block id fragments, comma separated", defaultBlocks, 300)); scan = new BlockScan(g);
    }
    protected List<String> fragments() {
        String s = blocks.get(); if (!s.equals(lastSetting)) { lastSetting = s; frags = new ArrayList<>(); for (String p : s.toLowerCase(Locale.ROOT).split(",")) if (!p.isBlank()) frags.add(p.trim()); scan.reset(); }
        return frags;
    }
    @Override protected void onDisable() { scan.reset(); lastSetting = null; }
    @Override protected void onWorldLeave() { scan.reset(); }
    @Override protected void onTick() { if (game.inWorld() && !game.selfDead()) scan.step(fragments(), radius.asInt(), height.asInt(), budget.asInt(), maxDraw.asInt()); }
    @Override protected void draw(RenderQueue q) {
        for (BlockPos p : scan.results()) { if (!within(p.center())) continue; blockBox(q, p, col()); if (labels.get()) label(q, p.center().add(0, 0.8, 0), game.blockId(p.x(), p.y(), p.z()).replace("minecraft:", "")); }
    }
}
