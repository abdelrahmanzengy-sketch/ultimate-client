package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;
import java.util.*;

/** Places a cobweb in your own feet block. */
public final class SelfWeb extends Module {
    public final Setting.Bool autoDisable = add(new Setting.Bool("auto-disable", "Disable after placing", true));
    private final Game game;
    public SelfWeb(Game g) { super("self-web", "Self Web", "Webs your own position.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo me = game.self();
        int r = Placer.place(game, List.of(new BlockPos(Placer.fx(me), Placer.fy(me), Placer.fz(me))), ItemKind.WEB, 1, false);
        if (r == Placer.NO_ITEM) { game.message("Self Web: no cobwebs in hotbar"); setEnabled(false); }
        else if (r > 0 && autoDisable.get()) setEnabled(false);
    }
}
