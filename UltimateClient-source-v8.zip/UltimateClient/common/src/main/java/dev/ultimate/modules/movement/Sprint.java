package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.Game;

public final class Sprint extends Module {
    public final Setting.Bool omni = add(new Setting.Bool("omni", "Sprint on any movement input, not only forward", false));
    private final Game game;
    public Sprint(Game game) { super("sprint", "Sprint", "Automatically sprints while moving.", Category.MOVEMENT); this.game = game; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.sneaking() || game.usingItem()) return;
        if (omni.get() ? game.movingAny() : game.movingForward()) game.setSprinting(true);
    }
}
