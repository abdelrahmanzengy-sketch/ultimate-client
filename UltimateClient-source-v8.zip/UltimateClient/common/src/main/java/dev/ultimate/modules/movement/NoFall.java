package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.Game;

/** Reports on-ground to the server once the fall exceeds a threshold, which cancels fall damage on vanilla servers. */
public final class NoFall extends Module {
    public final Setting.Num minFall = add(Setting.Num.dbl("min-fall", "Fall distance before acting", 2.5, 1.0, 20.0, 0.5));
    private final Game game;
    public NoFall(Game game) { super("no-fall", "No Fall", "Prevents fall damage.", Category.MOVEMENT); this.game = game; }
    @Override protected void onTick() {
        if (game.inWorld() && !game.selfDead() && game.fallDistance() >= minFall.get() && !game.inWater()) game.sendOnGround(true);
    }
}
