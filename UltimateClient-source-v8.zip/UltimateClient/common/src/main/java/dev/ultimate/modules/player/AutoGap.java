package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Eats a golden apple from the hotbar when your health is low, then restores your slot. */
public final class AutoGap extends Module {
    public final Setting.Num health = add(Setting.Num.dbl("health", "Eat at or below this health (hearts x2)", 12.0, 2.0, 20.0, 1.0));
    public final Setting.Bool needAbsorptionGone = add(new Setting.Bool("only-without-absorption", "Skip while you still have absorption hearts", true));
    private final Game game; private boolean eating; private int prev, ticks;
    public AutoGap(Game g) { super("auto-gap", "Auto Gap", "Eats golden apples when hurt.", Category.PLAYER); game = g; }
    private void stop() { if (eating) { game.setUseKey(false); game.selectSlot(prev); eating = false; } }
    @Override protected void onDisable() { if (game.inWorld()) stop(); eating = false; }
    @Override protected void onWorldLeave() { eating = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) { eating = false; return; }
        if (eating) { if (++ticks > 60 || (!game.usingItem() && ticks > 5)) stop(); else game.setUseKey(true); return; }
        EntityInfo me = game.self();
        if (me.health() > health.asFloat() || game.usingItem()) return;
        if (needAbsorptionGone.get() && me.absorption() > 0) return;
        int s = game.hotbarSlotOf(ItemKind.GOLDEN_APPLE); if (s < 0) return;
        prev = game.selectedSlot(); game.selectSlot(s); game.setUseKey(true); eating = true; ticks = 0;
    }
}
