package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Attacks the player under your crosshair once the weapon is recharged. Never targets friends. */
public final class TriggerBot extends Module {
    public final Setting.Num minCooldown = add(Setting.Num.dbl("min-cooldown", "Attack once the weapon is this recharged", 0.95, 0.1, 1.0, 0.05));
    public final Setting.Bool mobs = add(new Setting.Bool("mobs", "Also attack hostile mobs", false));
    public final Setting.Bool pauseOnUse = add(new Setting.Bool("pause-on-use", "Pause while eating/blocking", true));
    private final Game game; private final FriendManager friends;

    public TriggerBot(Game g, FriendManager f) { super("trigger-bot", "Trigger Bot", "Hits the player you are aiming at when the weapon is ready.", Category.COMBAT); game = g; friends = f; }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (pauseOnUse.get() && game.usingItem()) return;
        if (game.attackCooldown() < minCooldown.asFloat()) return;
        int id = game.crosshairEntity(); if (id < 0) return;
        for (EntityInfo e : game.entities()) {
            if (e.id() != id || e.health() <= 0) continue;
            boolean ok = e.kind() == EntityInfo.Kind.PLAYER ? !friends.isFriend(e.name()) : (mobs.get() && e.kind() == EntityInfo.Kind.HOSTILE);
            if (ok) game.attack(id);
            return;
        }
    }
}
