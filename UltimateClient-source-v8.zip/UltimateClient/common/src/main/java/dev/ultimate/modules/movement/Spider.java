package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Climb walls by pushing against them. (Most servers do not allow this; use where permitted.) */
public final class Spider extends Module {
    public final Setting.Num speed = add(Setting.Num.dbl("speed", "Climb speed (blocks/tick)", 0.2, 0.05, 0.8, 0.05));
    private final Game game;
    public Spider(Game g) { super("spider", "Spider", "Climb walls like a spider.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.horizontalCollision() || !game.movingAny()) return;
        Vec3 v = game.self().velocity();
        if (game.sneaking()) { game.setVelocity(new Vec3(v.x(), 0, v.z())); return; }
        game.setVelocity(new Vec3(v.x(), speed.get(), v.z()));
    }
}
