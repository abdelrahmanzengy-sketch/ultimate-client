package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** In an open inventory, a totem you hover over jumps into the offhand (the offhand must be empty or not a totem). */
public final class HoverTotem extends Module {
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between swaps", 1, 0, 10));
    private final Game game; private long last = -1000;
    public HoverTotem(Game g) { super("hover-totem", "Hover Totem", "Hover a totem in your inventory to equip it.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.inventoryScreenOpen() || game.tick() - last < delay.asInt()) return;
        int s = game.hoveredSlot(); if (s < 0 || s > 35 || game.kindAt(s) != ItemKind.TOTEM || game.offhand() == ItemKind.TOTEM) return;
        game.swapWithOffhand(s); last = game.tick();
    }
}
