package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/**
 * Walks in a straight line toward a waypoint (/uc wp go <name>): turns toward it, holds forward and hops over one-block
 * steps. It does NOT path-find; for obstacles, water or caves use the Baritone integration.
 */
public final class WaypointNav extends Module {
    public final Setting.Num stopDistance = add(Setting.Num.dbl("stop-distance", "Stop when this close (blocks)", 2.0, 0.5, 10.0, 0.5));
    public final Setting.Bool sprint = add(new Setting.Bool("sprint", "Sprint while walking", true));
    private final Game game; private Vec3 target; private String targetName = "";
    public WaypointNav(Game g) { super("waypoint-nav", "Waypoint Navigation", "Walks straight to a waypoint.", Category.WORLD); game = g; }
    public void setTarget(String name, int x, int y, int z) { target = new Vec3(x + 0.5, y, z + 0.5); targetName = name; }
    public Vec3 target() { return target; }
    @Override protected void onEnable() { if (target == null) game.message("Waypoint Navigation: pick a target with /uc wp go <name>."); }
    @Override protected void onDisable() { stop(); }
    @Override protected void onWorldLeave() { target = null; }
    private void stop() { if (game.inWorld()) { game.setForwardInput(false); game.setJumpInput(false); } }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || target == null) return;
        Vec3 me = game.self().pos(); double dx = target.x() - me.x(), dz = target.z() - me.z();
        if (Math.sqrt(dx * dx + dz * dz) <= stopDistance.get()) { game.message("Arrived at " + targetName + "."); target = null; stop(); setEnabled(false); return; }
        game.setRotation(Angles.yawTo(me, target), game.pitch());
        game.setForwardInput(true); if (sprint.get()) game.setSprinting(true);
        game.setJumpInput(game.horizontalCollision() && game.self().onGround());
    }
}
