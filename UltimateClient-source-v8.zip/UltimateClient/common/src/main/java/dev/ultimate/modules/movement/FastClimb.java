package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Climbs ladders and vines faster; sneaking holds you in place. */
public final class FastClimb extends Module {
    public final Setting.Num speed = add(Setting.Num.dbl("speed", "Climb speed (blocks/tick)", 0.3, 0.1, 1.0, 0.05));
    private final Game game;
    public FastClimb(Game g) { super("fast-climb", "Fast Climb", "Climb ladders quickly.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.onClimbable()) return;
        Vec3 v = game.self().velocity();
        if (game.jumping() || game.movingForward()) game.setVelocity(new Vec3(v.x(), speed.get(), v.z()));
    }
}
