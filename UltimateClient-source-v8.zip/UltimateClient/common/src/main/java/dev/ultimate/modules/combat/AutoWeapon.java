package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Switches to a sword/axe in the hotbar while the crosshair is on a living target. */
public final class AutoWeapon extends Module {
    public final Setting.Mode prefer = add(new Setting.Mode("prefer", "Preferred weapon", "Sword", "Sword", "Axe"));
    public final Setting.Bool switchBack = add(new Setting.Bool("switch-back", "Restore the previous slot when the target is gone", true));
    private final Game game; private int prev = -1;

    public AutoWeapon(Game g) { super("auto-weapon", "Auto Weapon", "Equips your best melee weapon when aiming at an entity.", Category.COMBAT); game = g; }

    @Override protected void onDisable() { restore(); }
    @Override protected void onWorldLeave() { prev = -1; }
    private void restore() { if (prev >= 0 && game.inWorld()) game.selectSlot(prev); prev = -1; }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        int id = game.crosshairEntity();
        EntityInfo target = null;
        if (id >= 0) for (EntityInfo e : game.entities()) if (e.id() == id) { target = e; break; }
        boolean valid = target != null && target.kind() != EntityInfo.Kind.CRYSTAL && target.kind() != EntityInfo.Kind.OTHER;
        if (!valid) { if (switchBack.get()) restore(); return; }
        ItemKind first = prefer.get().equals("Sword") ? ItemKind.SWORD : ItemKind.AXE;
        ItemKind second = first == ItemKind.SWORD ? ItemKind.AXE : ItemKind.SWORD;
        if (game.mainHand() == first) return;
        int slot = game.hotbarSlotOf(first);
        if (slot < 0) { if (game.mainHand() == second) return; slot = game.hotbarSlotOf(second); }
        if (slot < 0 || slot == game.selectedSlot()) return;
        if (prev < 0) prev = game.selectedSlot();
        game.selectSlot(slot);
    }
}
