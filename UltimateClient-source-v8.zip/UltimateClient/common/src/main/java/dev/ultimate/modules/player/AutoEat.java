package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Eats food from the hotbar when hunger is low, then restores the previously held slot. */
public final class AutoEat extends Module {
    public final Setting.Num hunger = add(Setting.Num.intg("hunger", "Eat at or below this food level", 14, 1, 19));
    public final Setting.Bool preferGapple = add(new Setting.Bool("prefer-golden-apple", "Eat golden apples first", false));
    private final Game game; private boolean eating; private int prev, ticks;
    public AutoEat(Game g) { super("auto-eat", "Auto Eat", "Eats automatically when hungry.", Category.PLAYER); game = g; }
    private void stop() { if (eating) { game.setUseKey(false); game.selectSlot(prev); eating = false; } }
    @Override protected void onDisable() { if (game.inWorld()) stop(); eating = false; }
    @Override protected void onWorldLeave() { eating = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) { eating = false; return; }
        if (eating) {
            if (++ticks > 80 || game.hunger() >= 20 || (!game.usingItem() && ticks > 5)) stop();
            else game.setUseKey(true);
            return;
        }
        if (game.hunger() > hunger.asInt() || game.usingItem()) return;
        int s = preferGapple.get() ? game.hotbarSlotOf(ItemKind.GOLDEN_APPLE) : -1;
        if (s < 0) s = game.hotbarSlotOf(ItemKind.FOOD);
        if (s < 0) s = game.hotbarSlotOf(ItemKind.GOLDEN_APPLE);
        if (s < 0) return;
        prev = game.selectedSlot(); game.selectSlot(s); game.setUseKey(true); eating = true; ticks = 0;
    }
}
