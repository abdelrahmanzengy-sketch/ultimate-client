package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** While riding a boat: jump rises, sneak descends, otherwise it hovers; forward drives at the chosen speed. Servers often reject this. */
public final class BoatFly extends Module {
    public final Setting.Num horizontal = add(Setting.Num.dbl("horizontal", "Forward speed (blocks/tick)", 0.8, 0.1, 3.0, 0.1));
    public final Setting.Num vertical = add(Setting.Num.dbl("vertical", "Climb/descend speed (blocks/tick)", 0.3, 0.05, 1.5, 0.05));
    public final Setting.Bool hover = add(new Setting.Bool("hover", "Hold height when no vertical key is pressed", true));
    private final Game game;
    public BoatFly(Game g) { super("boat-fly", "Boat Fly", "Flies while riding a boat.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.riding() || !game.vehicleIsBoat()) return;
        Vec3 v = game.vehicleVelocity(); double vy = game.jumping() ? vertical.get() : game.sneaking() ? -vertical.get() : hover.get() ? 0 : v.y();
        double yaw = Math.toRadians(game.yaw()); double hx = v.x(), hz = v.z();
        if (game.movingForward()) { hx = -Math.sin(yaw) * horizontal.get(); hz = Math.cos(yaw) * horizontal.get(); }
        game.setVehicleVelocity(new Vec3(hx, vy, hz));
    }
}
