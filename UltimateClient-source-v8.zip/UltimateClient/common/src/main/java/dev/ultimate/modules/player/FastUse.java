package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Shortens the delay between right-click uses (placing blocks, throwing items). */
public final class FastUse extends Module {
    public final Setting.Num cooldown = add(Setting.Num.intg("cooldown", "Maximum ticks between uses (vanilla is 4)", 0, 0, 4));
    private final Game game;
    public FastUse(Game g) { super("fast-use", "Fast Use", "Removes the delay between item uses.", Category.PLAYER); game = g; }
    @Override protected void onTick() { if (game.inWorld() && !game.selfDead() && game.itemUseCooldown() > cooldown.asInt()) game.setItemUseCooldown(cooldown.asInt()); }
}
