package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.*;

/** Right-clicks nearby sheep with shears from your hotbar, at most once per sheep per cooldown. */
public final class AutoShearer extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Reach", 3.5, 1.0, 5.0, 0.1));
    public final Setting.Num cooldown = add(Setting.Num.intg("cooldown", "Ticks before shearing the same sheep again", 600, 20, 6000));
    private final Game game; private final Map<Integer, Long> done = new HashMap<>(); private int prev = -1;
    public AutoShearer(Game g) { super("auto-shearer", "Auto Shearer", "Shears sheep in reach.", Category.WORLD); game = g; }
    @Override protected void onDisable() { restore(); done.clear(); }
    @Override protected void onWorldLeave() { done.clear(); prev = -1; }
    private void restore() { if (prev >= 0 && game.inWorld()) game.selectSlot(prev); prev = -1; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        int shears = game.hotbarSlotOf(ItemKind.SHEARS); if (shears < 0) { restore(); return; }
        long now = game.tick(); done.values().removeIf(t -> now - t > cooldown.asInt());
        Vec3 eye = Angles.eye(game.self());
        for (EntityInfo e : game.entities()) {
            if (e.kind() != EntityInfo.Kind.PASSIVE || !e.name().toLowerCase(Locale.ROOT).contains("sheep") || done.containsKey(e.id())) continue;
            if (e.pos().add(0, e.height() / 2, 0).distanceTo(eye) > range.get()) continue;
            if (prev < 0) prev = game.selectedSlot(); game.selectSlot(shears); game.lookAt(e.pos().add(0, e.height() / 2, 0));
            if (game.interactEntity(e.id())) done.put(e.id(), now); return;
        }
        restore();
    }
}
