package dev.ultimate.modules.render;

import dev.ultimate.core.FriendManager;
import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.Locale;

/** Extra labels above players: name, health, distance. (The vanilla tag is not hidden.) */
public final class Nametags extends EspModule {
    public final Setting.Bool showDistance = add(new Setting.Bool("distance-text", "Show distance in the label", true));
    private final FriendManager friends;
    public Nametags(Game g, FriendManager f) { super("nametags", "Nametags", "Shows name, health and distance above players.", g); friends = f; labels.set(true); }
    @Override protected void draw(RenderQueue q) {
        for (EntityInfo e : game.entities()) {
            if (e.kind() != EntityInfo.Kind.PLAYER || !within(e.pos())) continue;
            String t = String.format(Locale.ROOT, "%s%s %.0f", friends.isFriend(e.name()) ? "[F] " : "", e.name(), e.effectiveHealth());
            if (showDistance.get()) t += String.format(Locale.ROOT, "  %.0fm", e.pos().distanceTo(game.self().pos()));
            label(q, e.pos().add(0, e.height() + 0.6, 0), t);
        }
    }
}
