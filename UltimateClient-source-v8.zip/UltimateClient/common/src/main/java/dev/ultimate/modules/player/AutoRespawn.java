package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.Game;

public final class AutoRespawn extends Module {
    public final Setting.Num delay = add(Setting.Num.dbl("delay", "Seconds to wait before respawning", 0.5, 0.0, 5.0, 0.05));
    private final Game game; private int dead;
    public AutoRespawn(Game game) { super("auto-respawn", "Auto Respawn", "Respawns automatically after death.", Category.PLAYER); this.game = game; }
    @Override protected void onEnable() { dead = 0; }
    @Override protected void onWorldLeave() { dead = 0; }
    @Override protected void onTick() {
        if (!game.inWorld() || !game.selfDead()) { dead = 0; return; }
        if (++dead >= Math.round(delay.get() * 20)) { game.respawn(); dead = 0; }
    }
}
