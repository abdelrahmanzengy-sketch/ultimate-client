package dev.ultimate.modules.render;

import dev.ultimate.core.FriendManager;
import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Holes;
import dev.ultimate.util.Placer;

/** Marks the breakable blocks around the nearest enemy who is standing in a hole (the blocks Auto City would mine). */
public final class CityEsp extends EspModule {
    public final Setting.Num targetRange = add(Setting.Num.dbl("target-range", "Max distance of the enemy", 8.0, 2.0, 16.0, 0.5));
    private static final int[][] SIDES = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private final FriendManager friends;
    public CityEsp(Game g, FriendManager f) { super("city-esp", "City ESP", "Shows breakable blocks around an enemy in a hole.", g); friends = f; color.set(0xFFFF4040); }
    @Override protected void draw(RenderQueue q) {
        EntityInfo t = Placer.nearestEnemy(game, friends, targetRange.get()); if (t == null) return;
        int x = Placer.fx(t), y = Placer.fy(t), z = Placer.fz(t); if (Holes.classify(game, x, y, z) == Holes.NONE) return;
        for (int[] o : SIDES) if (game.isBreakable(x + o[0], y, z + o[1])) blockBox(q, new BlockPos(x + o[0], y, z + o[1]), col());
    }
}
