package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Caps the pause between finishing one block and starting the next (vanilla is 5 ticks). */
public final class BreakDelay extends Module {
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Maximum ticks between blocks", 0, 0, 5));
    private final Game game;
    public BreakDelay(Game g) { super("break-delay", "Break Delay", "Shortens the delay between mined blocks.", Category.PLAYER); game = g; }
    @Override protected void onTick() { if (game.inWorld() && !game.selfDead() && game.breakCooldown() > delay.asInt()) game.setBreakCooldown(delay.asInt()); }
}
