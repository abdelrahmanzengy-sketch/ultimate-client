package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Air control: while airborne, steers your horizontal speed toward the direction you are pressing. */
public final class Strafe extends Module {
    public final Setting.Num boost = add(Setting.Num.dbl("boost", "Minimum air speed while steering (blocks/tick)", 0.26, 0.1, 1.0, 0.02));
    public final Setting.Bool keepSpeed = add(new Setting.Bool("keep-speed", "Keep your current speed if it is higher than the minimum", true));
    private final Game game;
    public Strafe(Game g) { super("strafe", "Strafe", "Steers horizontal motion in the air toward your input.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.inWater() || game.gliding() || game.onClimbable()) return;
        EntityInfo me = game.self();
        if (me.onGround()) return;
        float fwd = game.movingForward() ? 1f : 0f, side = game.sidewaysInput();
        if (fwd == 0f && side == 0f) return;
        // Minecraft yaw: forward is (-sin, +cos); right strafe is (-cos, -sin).
        double yaw = Math.toRadians(game.yaw()), s = Math.sin(yaw), c = Math.cos(yaw);
        double dx = -s * fwd - c * side, dz = c * fwd - s * side, len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1e-6) return;
        double speed = boost.get(); Vec3 v = me.velocity();
        if (keepSpeed.get()) speed = Math.max(speed, v.horizontalLength());
        game.setVelocity(new Vec3(dx / len * speed, v.y(), dz / len * speed));
    }
}
