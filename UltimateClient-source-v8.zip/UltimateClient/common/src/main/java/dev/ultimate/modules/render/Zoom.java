package dev.ultimate.modules.render;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Narrows the field of view while enabled (smoothly), then restores your own FOV. Vanilla limits FOV to 30-110. */
public final class Zoom extends Module {
    public final Setting.Num zoomFov = add(Setting.Num.intg("fov", "FOV while zoomed", 30, 30, 110));
    public final Setting.Num smooth = add(Setting.Num.intg("smooth", "Max FOV change per tick (110 = instant)", 12, 1, 110));
    private final Game game; private int original = -1, cur;
    public Zoom(Game g) { super("zoom", "Zoom", "Zoom in.", Category.RENDER); game = g; }
    @Override protected void onEnable() { original = game.fov(); cur = original; }
    @Override protected void onDisable() { if (original > 0) game.setFov(original); original = -1; }
    @Override protected void onTick() {
        int goal = zoomFov.asInt(), step = smooth.asInt();
        cur = cur < goal ? Math.min(goal, cur + step) : Math.max(goal, cur - step);
        if (game.fov() != cur) game.setFov(cur);
    }
}
