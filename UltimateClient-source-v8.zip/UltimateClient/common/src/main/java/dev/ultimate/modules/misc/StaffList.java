package dev.ultimate.modules.misc;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.*;

/**
 * Watches the server player list for names you configured (comma separated, case-insensitive) and tells you in
 * chat when one appears or disappears. It only reads the public tab list; it cannot know who is staff by itself.
 */
public final class StaffList extends Module {
    public final Setting.Str names = add(new Setting.Str("names", "Staff names, comma separated", "", 400));
    public final Setting.Num interval = add(Setting.Num.intg("interval", "Ticks between checks", 20, 5, 200));
    public final Setting.Bool leaves = add(new Setting.Bool("announce-leave", "Also announce when they leave", true));
    private final Game game; private final Set<String> online = new HashSet<>(); private int n;
    /** Currently online watched names, for the HUD / commands. */
    public final List<String> present = new ArrayList<>();
    public StaffList(Game g) { super("staff-list", "Staff List", "Announces watched staff names joining or leaving.", Category.MISC); game = g; }
    @Override protected void onEnable() { online.clear(); present.clear(); n = 0; }
    @Override protected void onDisable() { online.clear(); present.clear(); }
    @Override protected void onWorldLeave() { online.clear(); present.clear(); }
    public static Set<String> parse(String csv) {
        Set<String> out = new HashSet<>();
        for (String p : csv.split(",")) { String t = p.trim().toLowerCase(Locale.ROOT); if (!t.isEmpty()) out.add(t); }
        return out;
    }
    @Override protected void onTick() {
        if (!game.inWorld() || ++n < interval.asInt()) return;
        n = 0;
        Set<String> watch = parse(names.get()); Set<String> now = new HashSet<>();
        if (!watch.isEmpty()) for (String p : game.onlinePlayerNames()) if (p != null && watch.contains(p.toLowerCase(Locale.ROOT))) now.add(p);
        for (String p : now) if (online.add(p)) game.message("Staff online: " + p);
        for (Iterator<String> it = online.iterator(); it.hasNext(); ) { String p = it.next(); if (!now.contains(p)) { it.remove(); if (leaves.get()) game.message("Staff left: " + p); } }
        present.clear(); present.addAll(online); Collections.sort(present);
    }
}
