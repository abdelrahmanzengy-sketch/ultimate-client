package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** While your inventory screen is open, moves a totem from the main inventory into the offhand if it is empty. */
public final class AutoInvTotem extends Module {
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between swaps", 1, 0, 10));
    private final Game game; private long last = -1000;
    public AutoInvTotem(Game g) { super("auto-inventory-totem", "Auto Inventory Totem", "Fills the offhand with a totem when you open your inventory.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.inventoryScreenOpen() || game.offhand() == ItemKind.TOTEM || game.tick() - last < delay.asInt()) return;
        int s = game.mainInvSlotOf(ItemKind.TOTEM); if (s < 0) s = game.hotbarSlotOf(ItemKind.TOTEM); if (s < 0) return;
        game.swapWithOffhand(s); last = game.tick();
    }
}
