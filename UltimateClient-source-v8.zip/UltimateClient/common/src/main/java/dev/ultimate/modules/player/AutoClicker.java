package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Attacks whatever entity is under the crosshair at a fixed rate, ignoring weapon cooldown (spam clicker). */
public final class AutoClicker extends Module {
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between clicks", 4, 1, 40));
    public final Setting.Bool playersOnly = add(new Setting.Bool("players-only", "Only click players", false));
    private final Game game; private final FriendManager friends; private long last = -1000;
    public AutoClicker(Game g, FriendManager f) { super("auto-clicker", "Auto Clicker", "Clicks on the entity you are aiming at.", Category.PLAYER); game = g; friends = f; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        long now = game.tick(); if (now - last < delay.asInt()) return;
        int id = game.crosshairEntity(); if (id < 0) return;
        for (EntityInfo e : game.entities()) {
            if (e.id() != id) continue;
            if (e.kind() == EntityInfo.Kind.CRYSTAL || e.health() <= 0) return;
            if (playersOnly.get() && e.kind() != EntityInfo.Kind.PLAYER) return;
            if (e.kind() == EntityInfo.Kind.PLAYER && friends.isFriend(e.name())) return;
            game.attack(id); last = now; return;
        }
    }
}
