package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;
import java.util.*;

/** Keeps a chosen item in the offhand, switching to a totem when health is low. */
public final class AutoOffhand extends Module {
    public final Setting.Mode item = add(new Setting.Mode("item", "Offhand item", "Golden Apple", "Totem", "Crystal", "Golden Apple"));
    public final Setting.Num totemHealth = add(Setting.Num.dbl("totem-health", "Use a totem at or below this health", 10.0, 0.0, 36.0, 1.0));
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Delay between swaps (ticks)", 1, 0, 10));
    private final Game game; private long last = -1000;
    public AutoOffhand(Game g) { super("auto-offhand", "Auto Offhand", "Keeps your preferred item in the offhand.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.tick() - last < delay.asInt()) return;
        ItemKind want = game.self().effectiveHealth() <= totemHealth.get() ? ItemKind.TOTEM : switch (item.get()) { case "Totem" -> ItemKind.TOTEM; case "Crystal" -> ItemKind.END_CRYSTAL; default -> ItemKind.GOLDEN_APPLE; };
        if (game.offhand() == want) return;
        int s = game.hotbarSlotOf(want); if (s < 0) s = game.mainInvSlotOf(want); if (s < 0) return;
        game.swapWithOffhand(s); last = game.tick();
    }
}
