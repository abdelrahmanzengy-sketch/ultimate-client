package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Pushes you upward when you fall toward the void. Client-side only: servers may correct it. */
public final class AntiVoid extends Module {
    public final Setting.Num voidY = add(Setting.Num.dbl("void-y", "Act below this Y (overworld bottom is -64)", -56.0, -128.0, 320.0, 1.0));
    public final Setting.Num lift = add(Setting.Num.dbl("lift", "Upward speed (blocks/tick)", 0.8, 0.1, 2.0, 0.1));
    private final Game game;
    public AntiVoid(Game g) { super("anti-void", "Anti Void", "Saves you from falling into the void.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo me = game.self();
        if (me.pos().y() >= voidY.get() || me.velocity().y() >= 0 || me.onGround()) return;
        int x = (int) Math.floor(me.pos().x()), z = (int) Math.floor(me.pos().z()), y = (int) Math.floor(me.pos().y());
        if (!game.isLoaded(x, z)) return;
        for (int i = 1; i <= 3; i++) if (game.isSolid(x, y - i, z)) return;   // ground right below: nothing to do
        game.setVelocity(new Vec3(me.velocity().x(), lift.get(), me.velocity().z()));
    }
}
