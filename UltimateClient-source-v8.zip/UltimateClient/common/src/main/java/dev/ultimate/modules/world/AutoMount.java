package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.Locale;

/** Gets on the nearest rideable thing in reach (horse, donkey, mule, camel, strider, boat, minecart) when you are not riding. */
public final class AutoMount extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Reach", 3.0, 1.0, 5.0, 0.1));
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between tries", 20, 5, 100));
    public final Setting.Bool boats = add(new Setting.Bool("boats-minecarts", "Also board boats and minecarts", true));
    private final Game game; private long last = -1000;
    public AutoMount(Game g) { super("auto-mount", "Auto Mount", "Boards a nearby mount automatically.", Category.WORLD); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.riding() || game.tick() - last < delay.asInt()) return;
        Vec3 eye = Angles.eye(game.self()); EntityInfo best = null; double bd = Double.MAX_VALUE;
        for (EntityInfo e : game.entities()) {
            String n = e.name().toLowerCase(Locale.ROOT);
            boolean ok = n.contains("horse") || n.contains("donkey") || n.contains("mule") || n.contains("camel") || n.contains("strider")
                    || boats.get() && (n.contains("boat") || n.contains("raft") || n.contains("minecart"));
            if (!ok) continue; double d = e.pos().add(0, e.height() / 2, 0).distanceTo(eye); if (d <= range.get() && d < bd) { bd = d; best = e; }
        }
        if (best != null && game.interactEntity(best.id())) last = game.tick();
    }
}
