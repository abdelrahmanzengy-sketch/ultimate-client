package dev.ultimate.modules.render;

import dev.ultimate.game.*;

/** Block ESP preset that looks for ancient debris (netherite source). */
public final class NetheriteFinder extends BlockEsp {
    public NetheriteFinder(Game g) { super(g, "netherite-finder", "Netherite Finder", "Highlights ancient debris.", "ancient_debris"); color.set(0xFF8A5A3C); }
    @Override protected java.util.List<String> fragments() { return java.util.List.of("ancient_debris"); }
}
