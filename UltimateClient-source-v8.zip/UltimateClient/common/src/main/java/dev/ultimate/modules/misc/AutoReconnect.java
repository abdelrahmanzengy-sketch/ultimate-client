package dev.ultimate.modules.misc;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Reconnects to the last server a few seconds after the disconnect screen appears. */
public final class AutoReconnect extends Module {
    public final Setting.Num seconds = add(Setting.Num.intg("seconds", "Wait before reconnecting", 5, 1, 120));
    public final Setting.Num attempts = add(Setting.Num.intg("max-attempts", "Give up after this many tries in a row", 5, 1, 50));
    private final Game game; private int wait = -1, tries;
    public AutoReconnect(Game g) { super("auto-reconnect", "Auto Reconnect", "Rejoins the server after a disconnect.", Category.MISC); game = g; }
    @Override protected void onEnable() { wait = -1; tries = 0; }
    @Override protected void onTick() {
        if (game.inWorld()) { wait = -1; tries = 0; return; }
        if (!game.disconnectScreenShown()) { wait = -1; return; }
        if (tries >= attempts.asInt()) return;
        if (wait < 0) wait = seconds.asInt() * 20;
        if (--wait <= 0) { tries++; wait = -1; game.reconnect(); }
    }
}
