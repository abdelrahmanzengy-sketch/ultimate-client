package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Plugs nearby water/lava source blocks with a cheap block (cobblestone, stone, dirt, netherrack...). */
public final class LiquidFiller extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Reach", 4.0, 1.0, 5.0, 0.5));
    public final Setting.Num perTick = add(Setting.Num.intg("per-tick", "Blocks per tick", 2, 1, 8));
    private final Game game; private boolean warned;
    public LiquidFiller(Game g) { super("liquid-filler", "Liquid Filler", "Fills in liquids around you.", Category.WORLD); game = g; }
    @Override protected void onEnable() { warned = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        EntityInfo me = game.self(); Vec3 eye = Angles.eye(me);
        int r = (int) Math.ceil(range.get()), cx = (int) Math.floor(me.pos().x()), cy = (int) Math.floor(me.pos().y()), cz = (int) Math.floor(me.pos().z());
        java.util.List<BlockPos> targets = new java.util.ArrayList<>();
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            int x = cx + dx, y = cy + dy, z = cz + dz;
            if (game.isLoaded(x, z) && game.isLiquid(x, y, z) && new Vec3(x + .5, y + .5, z + .5).distanceTo(eye) <= range.get()) targets.add(new BlockPos(x, y, z));
        }
        if (targets.isEmpty()) return;
        int slot = game.hotbarSlotOf(ItemKind.FILLER_BLOCK);
        if (slot < 0) { if (!warned) { game.message("Liquid Filler: no cobblestone/stone/dirt in hotbar"); warned = true; } return; }
        targets.sort(java.util.Comparator.comparingDouble(p -> p.center().distanceTo(eye)));
        int prev = game.selectedSlot(), placed = 0; game.selectSlot(slot);
        for (BlockPos p : targets) { if (placed >= perTick.asInt()) break; if (game.placeBlock(p)) placed++; }
        game.selectSlot(prev);
    }
}
