package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Press jump again in mid-air for extra jumps. */
public final class AirJump extends Module {
    public final Setting.Num jumps = add(Setting.Num.intg("jumps", "Extra jumps before landing", 1, 1, 10));
    public final Setting.Num power = add(Setting.Num.dbl("power", "Upward speed of each extra jump", 0.42, 0.1, 1.0, 0.02));
    private final Game game; private int used; private boolean wasJumping;
    public AirJump(Game g) { super("air-jump", "Air Jump", "Jump again while airborne.", Category.MOVEMENT); game = g; }
    @Override protected void onEnable() { used = 0; wasJumping = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo me = game.self(); boolean j = game.jumping();
        if (me.onGround() || game.inWater() || game.onClimbable()) used = 0;
        else if (j && !wasJumping && used < jumps.asInt()) { game.setVelocity(new Vec3(me.velocity().x(), power.get(), me.velocity().z())); used++; }
        wasJumping = j;
    }
}
