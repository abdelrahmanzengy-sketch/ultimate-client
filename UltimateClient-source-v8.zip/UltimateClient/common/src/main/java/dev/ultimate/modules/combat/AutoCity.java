package dev.ultimate.modules.combat;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;

/** Mines the blocks that wall in a surrounded enemy, one at a time, so the enemy becomes exposed. */
public final class AutoCity extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Mining reach", 4.5, 1.0, 6.0, 0.1));
    public final Setting.Num targetRange = add(Setting.Num.dbl("target-range", "Max distance of targets", 6.0, 2.0, 10.0, 0.5));
    public final Setting.Bool onlyIfSurrounded = add(new Setting.Bool("only-if-surrounded", "Only act when every side of the enemy is blocked", true));
    private static final int[][] SIDES = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private final Game game; private final FriendManager friends; private BlockPos current;
    public AutoCity(Game g, FriendManager f) { super("auto-city", "Auto City", "Breaks the blocks around a surrounded enemy.", Category.COMBAT); game = g; friends = f; }
    @Override protected void onDisable() { current = null; }
    @Override protected void onWorldLeave() { current = null; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        EntityInfo me = game.self(), t = dev.ultimate.util.Placer.nearestEnemy(game, friends, targetRange.get());
        if (t == null) { current = null; return; }
        Vec3 eye = Angles.eye(me); int fx = dev.ultimate.util.Placer.fx(t), fy = dev.ultimate.util.Placer.fy(t), fz = dev.ultimate.util.Placer.fz(t);
        if (current != null && (game.isAir(current.x(), current.y(), current.z()) || current.center().distanceTo(eye) > range.get())) current = null;
        if (current == null) {
            BlockPos best = null; double bd = Double.MAX_VALUE; boolean open = false;
            for (int[] s : SIDES) {
                int x = fx + s[0], z = fz + s[1];
                if (!game.isLoaded(x, z)) continue;
                if (!game.isSolid(x, fy, z)) { open = true; continue; }
                if (!game.isBreakable(x, fy, z)) continue;
                BlockPos p = new BlockPos(x, fy, z); double d = p.center().distanceTo(eye);
                if (d <= range.get() && d < bd) { bd = d; best = p; }
            }
            if (open && onlyIfSurrounded.get()) return;
            current = best;
        }
        if (current != null && !game.breakBlock(current)) current = null;
    }
}
