package dev.ultimate.modules;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.ModuleManager;
import dev.ultimate.game.Game;
import dev.ultimate.modules.client.*;
import dev.ultimate.modules.combat.*;
import dev.ultimate.modules.movement.*;
import dev.ultimate.modules.player.*;
import dev.ultimate.modules.world.*;
import dev.ultimate.modules.render.*;
import dev.ultimate.modules.misc.*;

/**
 * Registers every module that has real, unit-tested behaviour.
 * Only classes that actually exist in this source tree are registered here;
 * anything not listed is not part of the build.
 */
public final class Modules {
    private Modules() {}

    public static void registerAll(ModuleManager mm, Game game, FriendManager friends) {
        // ---- Combat ----
        mm.register(new CrystalAura(game, friends));
        mm.register(new KillAura(game, friends));
        mm.register(new AnchorAura(game, friends));
        mm.register(new AutoTotem(game));
        mm.register(new AutoOffhand(game));
        mm.register(new AutoArmor(game));
        mm.register(new AutoWeapon(game));
        mm.register(new AimAssist(game, friends));
        mm.register(new TriggerBot(game, friends));
        mm.register(new AutoCity(game, friends));
        mm.register(new ShieldBreaker(game, friends));
        mm.register(new AutoEXP(game));
        mm.register(new Surround(game));
        mm.register(new AutoTrap(game, friends));
        mm.register(new SelfTrap(game));
        mm.register(new AutoWeb(game, friends));
        mm.register(new SelfWeb(game));
        mm.register(new HoleFiller(game, friends));
        mm.register(new JumpReset(game));
        mm.register(new CrystalMacro(game));
        mm.register(new CrystalOptimizer(game));
        mm.register(new SingleAnchorMacro(game));
        mm.register(new AntiAnchor(game));
        mm.register(new AnchorGuard(game));
        mm.register(new AntiBed(game));
        mm.register(new BedAura(game, friends));
        mm.register(new AutoAnvil(game, friends));
        mm.register(new AntiAnvil(game));
        mm.register(new Criticals(game));
        mm.register(new WTap(game));
        mm.register(new Mace(game));
        mm.register(new AutoInvTotem(game));
        mm.register(new HoverTotem(game));
        mm.register(new FriendGuard(friends));

        // ---- Movement ----
        mm.register(new Fly(game));
        mm.register(new ElytraFly(game));
        mm.register(new Speed(game));
        mm.register(new Sprint(game));
        mm.register(new NoFall(game));
        mm.register(new AutoWalk(game));
        mm.register(new HighJump(game));
        mm.register(new AirJump(game));
        mm.register(new Jesus(game));
        mm.register(new ReverseStep(game));
        mm.register(new ElytraAutopilot(game));
        mm.register(new LongJump(game));
        mm.register(new SlowFall(game));
        mm.register(new Step(game));
        mm.register(new SafeWalk(game));
        mm.register(new AutoJump(game));
        mm.register(new Parkour(game));
        mm.register(new Spider(game));
        mm.register(new FastClimb(game));
        mm.register(new Sneak(game));
        mm.register(new AntiVoid(game));
        mm.register(new Strafe(game));
        mm.register(new Velocity(game));
        mm.register(new ElytraBoost(game));
        mm.register(new BoatFly(game));
        mm.register(new EntitySpeed(game));
        mm.register(new GuiMove(game));

        // ---- Player ----
        mm.register(new AutoRespawn(game));
        mm.register(new AutoEat(game));
        mm.register(new AutoGap(game));
        mm.register(new AutoTool(game));
        mm.register(new AutoReplenish(game));
        mm.register(new AutoFish(game));
        mm.register(new AutoClicker(game, friends));
        mm.register(new ChestSwap(game));
        mm.register(new AntiAFK(game));
        mm.register(new FastUse(game));
        mm.register(new FastXp(game));
        mm.register(new BreakDelay(game));
        mm.register(new SpeedMine(game));

        // ---- Render ----
        mm.register(new Fullbright(game));
        mm.register(new Zoom(game));
        mm.register(new CustomFov(game));
        mm.register(new EntityEsp(game));
        mm.register(new PlayerEsp(game, friends));
        mm.register(new ItemEsp(game));
        mm.register(new StorageEsp(game));
        mm.register(new BlockEsp(game));
        mm.register(new NetheriteFinder(game));
        mm.register(new SpawnerEsp(game));
        mm.register(new HoleEsp(game));
        mm.register(new CityEsp(game, friends));
        mm.register(new TargetEsp(game, friends));
        mm.register(new Tracers(game, friends));
        mm.register(new Nametags(game, friends));
        mm.register(new Trajectories(game));
        mm.register(new PearlTrajectory(game));
        mm.register(new Breadcrumbs(game));
        mm.register(new LogoutSpots(game));
        mm.register(new Waypoints(game));
        mm.register(new BlockOverlay(game));
        mm.register(new LightOverlay(game));

        // ---- World ----
        mm.register(new Nuker(game));
        mm.register(new TunnelMiner(game));
        mm.register(new VeinMiner(game));
        mm.register(new LiquidFiller(game));
        mm.register(new SpawnProofer(game));
        mm.register(new StashFinder(game));
        mm.register(new EChestFarmer(game));
        mm.register(new Excavator(game));
        mm.register(new WaypointNav(game));
        mm.register(new AutoShearer(game));
        mm.register(new AutoBreed(game));
        mm.register(new AutoMount(game));
        mm.register(new Baritone(game));

        // ---- Misc ----
        mm.register(new ChatMacro(game));
        mm.register(new PlayerDetection(game, friends));
        mm.register(new WeatherNotifier(game));
        mm.register(new BlockNotifier(game));
        mm.register(new StaffList(game));
        mm.register(new AutoReconnect(game));
        mm.register(new AutoRelog(game));
        mm.register(new NameProtect(game));

        // ---- Client (privacy / OpSec-inspired) ----
        mm.register(new ClientBrand());
    }
}
