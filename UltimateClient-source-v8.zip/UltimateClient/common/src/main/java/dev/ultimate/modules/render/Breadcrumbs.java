package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.ArrayDeque;

/** Leaves a line behind you so you can find your way back. */
public final class Breadcrumbs extends EspModule {
    public final Setting.Num length = add(Setting.Num.intg("length", "Points kept", 300, 20, 2000));
    public final Setting.Num spacing = add(Setting.Num.dbl("spacing", "Distance between points (blocks)", 1.0, 0.25, 8.0, 0.25));
    private final ArrayDeque<Vec3> trail = new ArrayDeque<>();
    public Breadcrumbs(Game g) { super("breadcrumbs", "Breadcrumbs", "Draws the path you walked.", g); color.set(0xFF50FF50); }
    @Override protected void onEnable() { trail.clear(); }
    @Override protected void onDisable() { trail.clear(); }
    @Override protected void onWorldLeave() { trail.clear(); }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        Vec3 p = game.self().pos();
        if (trail.isEmpty() || trail.peekLast().distanceTo(p) >= spacing.get()) { trail.addLast(p); while (trail.size() > length.asInt()) trail.pollFirst(); }
    }
    @Override protected void draw(RenderQueue q) {
        Vec3 prev = null; int skip = Math.max(1, trail.size() / Math.max(1, maxDraw.asInt()) + 1), i = 0;
        for (Vec3 p : trail) { if (i++ % skip != 0) continue; if (prev != null) line(q, prev, p, col()); prev = p; }
    }
}
