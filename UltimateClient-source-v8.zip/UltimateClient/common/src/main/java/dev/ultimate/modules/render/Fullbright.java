package dev.ultimate.modules.render;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Client-side night-vision look. Other players cannot see it; it sends no packets. */
public final class Fullbright extends Module {
    public final Setting.Num darkBelow = add(Setting.Num.intg("dark-below", "Only brighten where the light level is below this (15 = always)", 15, 1, 15));
    private final Game game;
    public Fullbright(Game g) { super("fullbright", "Fullbright", "See clearly in the dark.", Category.RENDER); game = g; }
    @Override protected void onEnable() { if (game.inWorld()) game.setNightVision(true); }
    @Override protected void onDisable() { if (game.inWorld()) game.setNightVision(false); }
    @Override protected void onTick() {
        if (!game.inWorld()) return;
        EntityInfo me = game.self();
        int x = (int) Math.floor(me.pos().x()), y = (int) Math.floor(me.pos().y()), z = (int) Math.floor(me.pos().z());
        game.setNightVision(darkBelow.asInt() >= 15 || game.lightLevel(x, y, z) < darkBelow.asInt());
    }
}
