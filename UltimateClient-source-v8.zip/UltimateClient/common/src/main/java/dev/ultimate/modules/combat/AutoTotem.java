package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Keeps a totem of undying in the offhand, taking it from the hotbar or (optionally) the main inventory. */
public final class AutoTotem extends Module {
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Delay between swaps (ticks)", 0, 0, 10));
    public final Setting.Bool useInventory = add(new Setting.Bool("use-inventory", "Also take totems from the main inventory", true));
    public final Setting.Num healthThreshold = add(Setting.Num.dbl("health-threshold", "Only act at or below this health (36 = always)", 36.0, 1.0, 36.0, 1.0));

    private final Game game; private long last = -1000;

    public AutoTotem(Game game) {
        super("auto-totem", "Auto Totem", "Keeps a totem in the offhand.", Category.COMBAT);
        this.game = game;
    }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (game.offhand() == ItemKind.TOTEM) return;
        if (game.self().effectiveHealth() > healthThreshold.get()) return;
        long now = game.tick();
        if (now - last < delay.asInt()) return;
        int slot = game.hotbarSlotOf(ItemKind.TOTEM);
        if (slot < 0 && useInventory.get()) slot = game.mainInvSlotOf(ItemKind.TOTEM);
        if (slot < 0) return;
        game.swapWithOffhand(slot);
        last = now;
    }
}
