package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;

import java.util.ArrayList;
import java.util.List;

/** When a charged respawn anchor is near you, puts blocks between it and you at foot and head height. */
public final class AntiAnchor extends Module {
    public final Setting.Num radius = add(Setting.Num.intg("radius", "Look for charged anchors within this many blocks", 5, 2, 8));
    public final Setting.Num perTick = add(Setting.Num.intg("per-tick", "Blocks placed per tick", 2, 1, 4));
    public final Setting.Bool rotate = add(new Setting.Bool("rotate", "Look at the block being placed", false));
    private final Game game;
    public AntiAnchor(Game g) { super("anti-anchor", "Anti Anchor", "Blocks the line to nearby charged anchors.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        EntityInfo me = game.self(); int cx = Placer.fx(me), cy = Placer.fy(me), cz = Placer.fz(me), r = radius.asInt();
        BlockPos anchor = null; double bd = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            if (!game.isLoaded(cx + dx, cz + dz)) continue;
            BlockPos p = new BlockPos(cx + dx, cy + dy, cz + dz);
            if (game.anchorCharges(p) < 1) continue;
            double d = dx * dx + dy * dy + dz * dz; if (d < bd) { bd = d; anchor = p; }
        }
        if (anchor == null) return;
        int sx = Integer.signum(anchor.x() - cx), sz = Integer.signum(anchor.z() - cz);
        List<BlockPos> t = new ArrayList<>();
        for (int h = 0; h <= 1; h++) { if (sx != 0) t.add(new BlockPos(cx + sx, cy + h, cz)); if (sz != 0) t.add(new BlockPos(cx, cy + h, cz + sz)); }
        if (anchor.y() > cy + 1) t.add(new BlockPos(cx, cy + 2, cz));
        Placer.placeAny(game, t, perTick.asInt(), rotate.get());
    }
}
