package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;

import java.util.List;

/** Caps the block above your head when an anvil is overhead (or always, if you choose). */
public final class AntiAnvil extends Module {
    public final Setting.Bool always = add(new Setting.Bool("always", "Keep the cap up even without an anvil above", false));
    public final Setting.Num scan = add(Setting.Num.intg("scan-height", "How far above your head to look for anvils", 6, 2, 10));
    private final Game game;
    public AntiAnvil(Game g) { super("anti-anvil", "Anti Anvil", "Caps your head against falling anvils.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        EntityInfo me = game.self(); int x = Placer.fx(me), y = Placer.fy(me), z = Placer.fz(me);
        if (!always.get()) {
            boolean anvil = false;
            for (int h = 2; h <= scan.asInt() + 1 && !anvil; h++) anvil = game.isLoaded(x, z) && game.blockId(x, y + h, z).endsWith("anvil");
            if (!anvil) return;
        }
        if (game.isAir(x, y + 2, z)) Placer.placeAny(game, List.of(new BlockPos(x, y + 2, z)), 1, false);
    }
}
