package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Places obsidian on the four sides of the player's feet block (adding a floor block first if unsupported). */
public final class Surround extends Module {
    public final Setting.Bool rotate = add(new Setting.Bool("rotate", "Look at placement", false));
    public final Setting.Bool onlyOnGround = add(new Setting.Bool("only-on-ground", "Only when on ground", true));
    public final Setting.Num blocksPerTick = add(Setting.Num.intg("blocks-per-tick", "Blocks placed per tick", 2, 1, 8));
    public final Setting.Bool autoDisable = add(new Setting.Bool("auto-disable", "Disable once surrounded", false));

    private static final int[][] SIDES = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private final Game game;

    public Surround(Game game) {
        super("surround", "Surround", "Places obsidian around your feet.", Category.COMBAT);
        this.game = game;
    }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo me = game.self();
        if (onlyOnGround.get() && !me.onGround()) return;
        int fx = (int) Math.floor(me.pos().x()), fy = (int) Math.floor(me.pos().y()), fz = (int) Math.floor(me.pos().z());
        boolean complete = true; int placed = 0, limit = blocksPerTick.asInt();
        int prev = game.selectedSlot(); int slot = -1;
        for (int[] s : SIDES) {
            int x = fx + s[0], z = fz + s[1];
            if (!game.isLoaded(x, z) || game.isSolid(x, fy, z)) continue;
            complete = false;
            if (placed >= limit) break;
            if (slot < 0) { slot = game.hotbarSlotOf(ItemKind.OBSIDIAN); if (slot < 0) { game.message("Surround: no obsidian in hotbar"); setEnabled(false); return; } game.selectSlot(slot); }
            if (!game.isSolid(x, fy - 1, z) && game.isAir(x, fy - 1, z)) { if (game.placeBlock(new BlockPos(x, fy - 1, z))) placed++; if (placed >= limit) break; }
            if (rotate.get()) game.lookAt(new BlockPos(x, fy, z).center());
            if (game.placeBlock(new BlockPos(x, fy, z))) placed++;
        }
        if (slot >= 0) game.selectSlot(prev);
        if (complete && autoDisable.get()) setEnabled(false);
    }
}
