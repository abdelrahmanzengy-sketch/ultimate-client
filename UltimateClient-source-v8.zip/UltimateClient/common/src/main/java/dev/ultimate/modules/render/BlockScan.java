package dev.ultimate.modules.render;

import dev.ultimate.game.*;

import java.util.ArrayList;
import java.util.List;

/** Incremental cube scan for blocks whose id contains one of the fragments; spreads the work over many ticks. */
public final class BlockScan {
    private final Game game; private List<BlockPos> found = new ArrayList<>(), building = new ArrayList<>();
    private int idx = -1, cx, cy, cz, side, tall;
    public BlockScan(Game g) { game = g; }
    public List<BlockPos> results() { return found; }
    public void reset() { found = new ArrayList<>(); building = new ArrayList<>(); idx = -1; }
    /** Examines up to budget cells around the player. A full cycle restarts automatically. */
    public void step(List<String> fragments, int radius, int height, int budget, int maxResults) {
        if (fragments.isEmpty()) { found = new ArrayList<>(); return; }
        if (idx < 0) { EntityInfo me = game.self(); cx = (int) Math.floor(me.pos().x()); cy = (int) Math.floor(me.pos().y()); cz = (int) Math.floor(me.pos().z()); side = radius * 2 + 1; tall = height * 2 + 1; idx = 0; building = new ArrayList<>(); }
        int total = side * side * tall;
        for (int n = 0; n < budget && idx < total; n++, idx++) {
            int x = cx - radius + idx % side, z = cz - radius + (idx / side) % side, y = cy - height + idx / (side * side);
            if (!game.isLoaded(x, z)) continue;
            String id = game.blockId(x, y, z); if (id.isEmpty()) continue;
            for (String f : fragments) if (id.contains(f)) { if (building.size() < maxResults) building.add(new BlockPos(x, y, z)); break; }
        }
        if (idx >= total) { found = building; idx = -1; }
    }
}
