package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Breaks every breakable block in a radius, nearest first, one target at a time (survival-safe). */
public final class Nuker extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Radius", 4.0, 1.0, 6.0, 0.5));
    public final Setting.Mode mode = add(new Setting.Mode("mode", "All blocks, or only blocks at/above your feet", "All", "All", "Flatten"));
    public final Setting.Bool skipLiquids = add(new Setting.Bool("skip-liquids", "Ignore fluids", true));
    public final Setting.Num perTick = add(Setting.Num.intg("per-tick", "Break attempts per tick (helps in creative)", 1, 1, 8));
    private final Game game; private BlockPos current;
    public Nuker(Game g) { super("nuker", "Nuker", "Mines everything around you.", Category.WORLD); game = g; }
    @Override protected void onDisable() { current = null; }
    @Override protected void onWorldLeave() { current = null; }
    private boolean valid(int x, int y, int z, Vec3 eye, int feetY) {
        if (!game.isLoaded(x, z) || game.isAir(x, y, z) || !game.isBreakable(x, y, z)) return false;
        if (skipLiquids.get() && game.isLiquid(x, y, z)) return false;
        if (mode.get().equals("Flatten") && y < feetY) return false;
        return new Vec3(x + .5, y + .5, z + .5).distanceTo(eye) <= range.get();
    }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        EntityInfo me = game.self(); Vec3 eye = Angles.eye(me);
        int cx = (int) Math.floor(me.pos().x()), cy = (int) Math.floor(me.pos().y()), cz = (int) Math.floor(me.pos().z());
        for (int n = 0; n < perTick.asInt(); n++) {
            if (current != null && !valid(current.x(), current.y(), current.z(), eye, cy)) current = null;
            if (current == null) {
                int r = (int) Math.ceil(range.get()); double bd = Double.MAX_VALUE;
                for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
                    int x = cx + dx, y = cy + dy, z = cz + dz;
                    if (!valid(x, y, z, eye, cy)) continue;
                    double d = new Vec3(x + .5, y + .5, z + .5).distanceTo(eye);
                    if (d < bd) { bd = d; current = new BlockPos(x, y, z); }
                }
            }
            if (current == null) return;
            if (!game.breakBlock(current)) current = null;
        }
    }
}
