package dev.ultimate.util;

import java.lang.reflect.Method;

/**
 * Talks to the Baritone API by reflection, so UltimateClient builds and runs with or without Baritone installed and
 * never copies Baritone code. Commands are the normal Baritone commands without the chat prefix, e.g. "goto 100 64 100",
 * "mine diamond_ore", "build house.schematic", "tunnel", "cancel", "set allowBreak true".
 */
public final class BaritoneBridge {
    private BaritoneBridge() {}

    /** Replaceable backend (tests use a fake). Returns true if the command was accepted. */
    public interface Backend { boolean available(); boolean execute(String command) throws Exception; }

    private static final Backend REFLECTIVE = new Backend() {
        @Override public boolean available() { try { Class.forName("baritone.api.BaritoneAPI"); return true; } catch (Throwable t) { return false; } }
        @Override public boolean execute(String command) throws Exception {
            Class<?> api = Class.forName("baritone.api.BaritoneAPI");
            Object provider = api.getMethod("getProvider").invoke(null);
            Object baritone = Class.forName("baritone.api.IBaritoneProvider").getMethod("getPrimaryBaritone").invoke(provider);
            Object cm = Class.forName("baritone.api.IBaritone").getMethod("getCommandManager").invoke(baritone);
            Method ex = Class.forName("baritone.api.command.manager.ICommandManager").getMethod("execute", String.class);
            Object r = ex.invoke(cm, command);
            return !(r instanceof Boolean b) || b;
        }
    };
    private static volatile Backend backend = REFLECTIVE;
    public static void setBackend(Backend b) { backend = b == null ? REFLECTIVE : b; }

    public static boolean available() { return backend.available(); }

    /** @return null on success, otherwise a human-readable error. */
    public static String execute(String command) {
        if (command == null || command.isBlank()) return "Empty Baritone command.";
        if (command.length() > 500 || command.indexOf('\n') >= 0) return "Baritone command rejected (too long or multi-line).";
        if (!backend.available()) return "Baritone is not installed. Put the baritone-meteor (or baritone-api) jar in your mods folder.";
        try { return backend.execute(command.trim()) ? null : "Baritone did not accept: " + command; }
        catch (Throwable t) { Throwable c = t.getCause() != null ? t.getCause() : t; return "Baritone error: " + c; }
    }
}
