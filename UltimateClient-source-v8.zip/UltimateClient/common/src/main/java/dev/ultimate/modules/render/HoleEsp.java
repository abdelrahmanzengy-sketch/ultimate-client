package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Holes;

import java.util.ArrayList;
import java.util.List;

/** Marks 1x1 holes near you: green when all sides are obsidian/bedrock, orange when some sides can be broken. */
public final class HoleEsp extends EspModule {
    public final Setting.Color safeColor = add(new Setting.Color("safe-color", "Colour of fully safe holes", 0xFF30FF60));
    public final Setting.Num radius = add(Setting.Num.intg("radius", "Search radius", 6, 2, 12));
    public final Setting.Num interval = add(Setting.Num.intg("interval", "Ticks between searches", 10, 1, 60));
    public final Setting.Bool showMixed = add(new Setting.Bool("show-breakable", "Also show holes with breakable sides", true));
    private final List<int[]> holes = new ArrayList<>(); private int n;
    public HoleEsp(Game g) { super("hole-esp", "Hole ESP", "Shows safe and half-safe holes.", g); color.set(0xFFFFA030); thickness.set(1.0); }
    @Override protected void onDisable() { holes.clear(); }
    @Override protected void onWorldLeave() { holes.clear(); }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || n++ % interval.asInt() != 0) return;
        holes.clear(); EntityInfo me = game.self(); int cx = (int) Math.floor(me.pos().x()), cy = (int) Math.floor(me.pos().y()), cz = (int) Math.floor(me.pos().z()), r = radius.asInt();
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) for (int dy = -3; dy <= 2; dy++) {
            int c = Holes.classify(game, cx + dx, cy + dy, cz + dz);
            if (c == Holes.NONE || c == Holes.MIXED && !showMixed.get()) continue;
            if (holes.size() < maxDraw.asInt()) holes.add(new int[]{cx + dx, cy + dy, cz + dz, c});
        }
    }
    @Override protected void draw(RenderQueue q) {
        for (int[] h : holes) { int c = h[3] == Holes.SAFE ? withOpacity(safeColor.get()) : col(); box(q, new Vec3(h[0], h[1] - 1, h[2]), new Vec3(h[0] + 1, h[1] - 0.9, h[2] + 1), c); }
    }
}
