package dev.ultimate.hud;

import dev.ultimate.core.Module;
import dev.ultimate.core.ModuleManager;
import dev.ultimate.game.*;
import dev.ultimate.modules.combat.CrystalAura;

import java.util.*;

/**
 * HUD model: draggable/scalable text elements with persisted layout. Positions are fractions (0..1) of the screen so
 * they survive resolution changes. This produces the text lines; drawing them needs a per-version renderer (not written).
 */
public final class Hud {
    public static final class Element {
        public final String id, name; public double x, y, scale = 1.0; public boolean enabled = true;
        private final java.util.function.Function<Ctx, List<String>> lines;
        Element(String id, String name, double x, double y, java.util.function.Function<Ctx, List<String>> l) { this.id = id; this.name = name; this.x = x; this.y = y; lines = l; }
        public List<String> lines(Ctx c) { return enabled ? lines.apply(c) : List.of(); }
        public void moveTo(double nx, double ny) { x = clamp(nx, 0, 1); y = clamp(ny, 0, 1); }
        public void setScale(double s) { scale = clamp(s, 0.5, 3.0); }
    }
    public record Ctx(Game game, ModuleManager modules) {}

    private final Map<String, Element> elements = new LinkedHashMap<>();
    static double clamp(double v, double lo, double hi) { return Double.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v)); }
    public Collection<Element> elements() { return elements.values(); }
    public Element get(String id) { return elements.get(id); }

    public Hud() {
        add("watermark", "Watermark", 0.01, 0.01, c -> List.of("UltimateClient"));
        add("modules", "Active Modules", 0.99, 0.01, c -> {
            List<String> l = new ArrayList<>(); for (Module m : c.modules().all()) if (m.isEnabled()) l.add(m.name);
            l.sort(Comparator.comparingInt(String::length).reversed().thenComparing(Comparator.naturalOrder())); return l; });
        add("coords", "Coordinates", 0.01, 0.95, c -> { if (!c.game().inWorld()) return List.of(); Vec3 p = c.game().self().pos();
            return List.of(String.format(Locale.ROOT, "XYZ %.1f %.1f %.1f", p.x(), p.y(), p.z())); });
        add("speed", "Speed", 0.01, 0.91, c -> { if (!c.game().inWorld()) return List.of(); Vec3 v = c.game().self().velocity();
            return List.of(String.format(Locale.ROOT, "%.1f b/s", v.horizontalLength() * 20)); });
        add("direction", "Direction", 0.01, 0.87, c -> c.game().inWorld() ? List.of(direction(c.game().yaw())) : List.of());
        add("totems", "Totem Count", 0.5, 0.9, c -> c.game().inWorld() ? List.of("Totems: " + c.game().countItem(ItemKind.TOTEM)) : List.of());
        add("fps", "FPS", 0.01, 0.05, c -> c.game().inWorld() ? List.of(c.game().fps() + " FPS") : List.of());
        add("ping", "Ping", 0.01, 0.09, c -> { if (!c.game().inWorld()) return List.of(); int p = c.game().ping(); return List.of(p < 0 ? "Ping: n/a" : "Ping: " + p + " ms"); });
        add("durability", "Armor Durability", 0.5, 0.86, c -> { if (!c.game().inWorld()) return List.of(); float d = c.game().armorDurability(); return d >= 1f ? List.of() : List.of(String.format(Locale.ROOT, "Armor: %.0f%%", d * 100)); });
        add("keybinds", "Keybinds", 0.99, 0.5, c -> { List<String> l = new ArrayList<>(); for (Module m : c.modules().all()) if (m.keybind() >= 0 && m.isEnabled()) l.add(m.name + " [" + dev.ultimate.core.Keys.name(m.keybind()) + "]"); return l; });
        add("compass", "Compass", 0.5, 0.01, c -> { if (!c.game().inWorld()) return List.of(); return List.of(compass(c.game().yaw())); });
        add("hole", "Hole Info", 0.5, 0.8, c -> { if (!c.game().inWorld()) return List.of(); String h = holeInfo(c.game()); return h.isEmpty() ? List.of() : List.of(h); });
        add("potions", "Potion Timers", 0.01, 0.3, c -> c.game().inWorld() ? c.game().effectTimers() : List.of());
        add("server", "Server Info", 0.99, 0.95, c -> { if (!c.game().inWorld()) return List.of(); String a = c.game().serverAddress(); return List.of(a.isEmpty() ? "Singleplayer / unknown" : a); });
        add("radar", "Player Radar", 0.99, 0.3, c -> { if (!c.game().inWorld()) return List.of(); return radar(c.game(), 60.0, 6); });
        add("inventory", "Inventory Summary", 0.01, 0.6, c -> { if (!c.game().inWorld()) return List.of(); return inventory(c.game()); });
        add("lag", "Lag Notifier", 0.5, 0.15, c -> { if (!c.game().inWorld()) return List.of(); long ms = c.game().msSincePacket(); return ms >= 1000 ? List.of(String.format(Locale.ROOT, "Server not responding: %.1fs", ms / 1000.0)) : List.of(); });
        add("target", "Target Info", 0.5, 0.25, c -> { if (!c.game().inWorld()) return List.of(); EntityInfo t = nearestPlayer(c.game(), 30.0); if (t == null) return List.of();
            return List.of(String.format(Locale.ROOT, "%s  %.0f hp  %.1fm", t.name(), t.effectiveHealth(), t.pos().distanceTo(c.game().self().pos()))); });
        add("combat", "Combat Info", 0.5, 0.3, c -> { if (!c.game().inWorld()) return List.of(); Game g = c.game(); EntityInfo t = nearestPlayer(g, 12.0); if (t == null) return List.of();
            return List.of(String.format(Locale.ROOT, "Totems %d  Crystals %d  Gaps %d  Foe %.0f hp", g.countItem(ItemKind.TOTEM), g.countItem(ItemKind.END_CRYSTAL), g.countItem(ItemKind.GOLDEN_APPLE), t.effectiveHealth())); });
        add("crystal", "Crystal Info", 0.5, 0.2, c -> { Module m = c.modules().get("crystal-aura");
            if (!(m instanceof CrystalAura ca) || !ca.isEnabled() || ca.hudTarget.isEmpty()) return List.of();
            return List.of(String.format(Locale.ROOT, "%s  dmg %.1f  self %.1f", ca.hudTarget, ca.hudTargetDamage, ca.hudSelfDamage)); });
    }
    private void add(String id, String name, double x, double y, java.util.function.Function<Ctx, List<String>> f) { elements.put(id, new Element(id, name, x, y, f)); }

    public static String direction(float yaw) {
        double y = ((yaw % 360) + 360) % 360; // 0 = south (+Z), 90 = west (-X) in Minecraft
        String[] n = {"South (+Z)", "South-West", "West (-X)", "North-West", "North (-Z)", "North-East", "East (+X)", "South-East"};
        return n[(int) Math.floor((y + 22.5) / 45) % 8];
    }

    /** Eight-point compass strip with the facing marked, e.g. "S  [SW]  W". */
    public static String compass(float yaw) {
        String[] n = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};
        double y = ((yaw % 360) + 360) % 360; int i = (int) Math.floor((y + 22.5) / 45) % 8;
        return n[(i + 7) % 8] + "  [" + n[i] + "]  " + n[(i + 1) % 8];
    }

    /** "Hole: safe (obsidian/bedrock on all 4 sides)", "Hole: 2/4 sides covered", or "" when not standing in a 1x1 pit. */
    public static String holeInfo(Game g) {
        EntityInfo me = g.self(); int x = (int) Math.floor(me.pos().x()), y = (int) Math.floor(me.pos().y()), z = (int) Math.floor(me.pos().z());
        if (!g.isLoaded(x, z) || g.isSolid(x, y, z) || g.isSolid(x, y + 1, z) || !g.isSolid(x, y - 1, z)) return "";
        int[][] d = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}; int solid = 0, hard = 0;
        for (int[] o : d) {
            if (!g.isLoaded(x + o[0], z + o[1])) return "";
            if (g.isSolid(x + o[0], y, z + o[1])) { solid++; if (g.isCrystalBase(x + o[0], y, z + o[1])) hard++; }
        }
        if (solid == 0) return "";
        if (hard == 4) return "Hole: safe (obsidian/bedrock all sides)";
        if (solid == 4) return "Hole: enclosed (breakable sides)";
        return "Hole: " + solid + "/4 sides covered";
    }

    static EntityInfo nearestPlayer(Game g, double range) {
        EntityInfo me = g.self(), best = null;
        for (EntityInfo e : g.entities()) if (e.kind() == EntityInfo.Kind.PLAYER && e.health() > 0) { double d = e.pos().distanceTo(me.pos()); if (d <= range && (best == null || d < best.pos().distanceTo(me.pos()))) best = e; }
        return best;
    }

    /** Nearby players as "name 12m NE", nearest first, at most max lines. */
    public static List<String> radar(Game g, double range, int max) {
        EntityInfo me = g.self(); List<EntityInfo> ps = new ArrayList<>();
        for (EntityInfo e : g.entities()) if (e.kind() == EntityInfo.Kind.PLAYER && e.pos().distanceTo(me.pos()) <= range) ps.add(e);
        ps.sort(Comparator.comparingDouble(e -> e.pos().distanceTo(me.pos())));
        List<String> out = new ArrayList<>();
        for (EntityInfo e : ps) {
            if (out.size() >= max) break;
            float yaw = Angles.yawTo(me.pos(), e.pos()); String d = direction(yaw); int cut = d.indexOf(' '); if (cut > 0) d = d.substring(0, cut);
            out.add(String.format(Locale.ROOT, "%s %.0fm %s", e.name(), e.pos().distanceTo(me.pos()), d));
        }
        return out;
    }

    /** Counts of the items that matter in a fight. Empty lines are skipped. */
    public static List<String> inventory(Game g) {
        List<String> out = new ArrayList<>(); int t = g.countItem(ItemKind.TOTEM), c = g.countItem(ItemKind.END_CRYSTAL), a = g.countItem(ItemKind.GOLDEN_APPLE), x = g.countItem(ItemKind.EXP_BOTTLE), o = g.countItem(ItemKind.OBSIDIAN);
        if (t > 0) out.add("Totems " + t); if (c > 0) out.add("Crystals " + c); if (a > 0) out.add("Gapples " + a); if (x > 0) out.add("XP bottles " + x); if (o > 0) out.add("Obsidian " + o);
        return out;
    }

    /** Persist into ModuleManager.layout (saved by ConfigManager). */
    public void save(Map<String, Object> layout) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (Element e : elements.values()) { Map<String, Object> o = new LinkedHashMap<>(); o.put("x", e.x); o.put("y", e.y); o.put("scale", e.scale); o.put("enabled", e.enabled); m.put(e.id, o); }
        layout.put("hud", m);
    }
    public void load(Map<String, Object> layout) {
        if (!(layout.get("hud") instanceof Map<?, ?> m)) return;
        for (Map.Entry<?, ?> en : m.entrySet()) {
            Element e = elements.get(String.valueOf(en.getKey()));
            if (e == null || !(en.getValue() instanceof Map<?, ?> o)) continue;
            if (o.get("x") instanceof Number x && o.get("y") instanceof Number y) e.moveTo(x.doubleValue(), y.doubleValue());
            if (o.get("scale") instanceof Number s) e.setScale(s.doubleValue());
            if (o.get("enabled") instanceof Boolean b) e.enabled = b;
        }
    }
}
