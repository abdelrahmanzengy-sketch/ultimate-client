package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** While gliding with the forward key held, adds speed along your view direction up to a cap (no fireworks needed). */
public final class ElytraBoost extends Module {
    public final Setting.Num boost = add(Setting.Num.dbl("boost", "Speed added per tick (blocks/tick)", 0.03, 0.005, 0.2, 0.005));
    public final Setting.Num maxSpeed = add(Setting.Num.dbl("max-speed", "Stop boosting above this speed (blocks/tick)", 1.6, 0.5, 4.0, 0.1));
    private final Game game;
    public ElytraBoost(Game g) { super("elytra-boost", "Elytra Boost", "Accelerates elytra flight while moving forward.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.gliding() || !game.movingForward()) return;
        Vec3 v = game.self().velocity(); double sp = Math.sqrt(v.x() * v.x() + v.y() * v.y() + v.z() * v.z());
        if (sp >= maxSpeed.get()) return;
        Vec3 d = Angles.look(game.yaw(), game.pitch());
        game.setVelocity(v.add(d.scale(boost.get())));
    }
}
