package dev.ultimate.modules.misc;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.NameState;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Replaces your username with a fake one in text drawn on your own screen (chat, tab list, nametags). Others still see your real name. */
public final class NameProtect extends Module {
    public final Setting.Str fake = add(new Setting.Str("name", "Name to show instead of yours", "Player", 16));
    private final Game game;
    public NameProtect(Game g) { super("name-protect", "Name Protect", "Hides your real username on your screen.", Category.MISC); game = g; }
    @Override protected void onDisable() { NameState.clear(); }
    @Override protected void onWorldLeave() { NameState.clear(); }
    @Override protected void onTick() {
        if (!game.inWorld()) { NameState.clear(); return; }
        String real = game.self().name(), f = fake.get().isBlank() ? "Player" : fake.get();
        if (!NameState.active() || !f.equals(lastFake) || !real.equals(lastReal)) { NameState.set(real, f); lastFake = f; lastReal = real; }
    }
    private String lastFake = "", lastReal = "";
}
