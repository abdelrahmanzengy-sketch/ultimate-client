package dev.ultimate.modules.world;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;

/** After you break an ore (or any block whose id matches the filter), mines the connected blocks of the same kind. */
public final class VeinMiner extends Module {
    public final Setting.Str filter = add(new Setting.Str("filter", "Comma-separated id fragments (e.g. _ore,ancient_debris); empty = any block", "_ore,ancient_debris", 128));
    public final Setting.Num maxBlocks = add(Setting.Num.intg("max-blocks", "Largest vein to mine", 32, 1, 128));
    public final Setting.Num range = add(Setting.Num.dbl("range", "Mining reach", 5.0, 2.0, 6.0, 0.5));
    private final Game game; private BlockPos anchor; private String anchorId = ""; private final java.util.ArrayDeque<BlockPos> queue = new java.util.ArrayDeque<>(); private BlockPos current;
    public VeinMiner(Game g) { super("vein-miner", "Vein Miner", "Mines whole ore veins.", Category.WORLD); game = g; }
    private void reset() { anchor = null; anchorId = ""; queue.clear(); current = null; }
    @Override protected void onEnable() { reset(); }
    @Override protected void onDisable() { reset(); }
    @Override protected void onWorldLeave() { reset(); }
    private boolean matches(String id) {
        if (id.isEmpty()) return false;
        String f = filter.get().trim(); if (f.isEmpty()) return true;
        for (String part : f.split(",")) { String p = part.trim(); if (!p.isEmpty() && id.contains(p)) return true; }
        return false;
    }
    private void collect(BlockPos from) {
        java.util.ArrayDeque<BlockPos> open = new java.util.ArrayDeque<>(); java.util.Set<BlockPos> seen = new java.util.HashSet<>();
        open.add(from); seen.add(from);
        while (!open.isEmpty() && queue.size() < maxBlocks.asInt()) {
            BlockPos c = open.poll();
            for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dy == 0 && dz == 0) continue;
                BlockPos n = c.offset(dx, dy, dz);
                if (!seen.add(n) || !game.isLoaded(n.x(), n.z())) continue;
                if (anchorId.equals(game.blockId(n.x(), n.y(), n.z())) && game.isBreakable(n.x(), n.y(), n.z())) { queue.add(n); open.add(n); if (queue.size() >= maxBlocks.asInt()) return; }
            }
        }
    }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        Vec3 eye = Angles.eye(game.self());
        if (current == null && queue.isEmpty()) {
            BlockPos t = game.targetBlock();
            if (game.breakingBlock() && t != null) { String id = game.blockId(t.x(), t.y(), t.z()); if (matches(id)) { anchor = t; anchorId = id; } }
            else if (anchor != null && game.isAir(anchor.x(), anchor.y(), anchor.z())) { collect(anchor); anchor = null; }   // the player just broke it
            else if (anchor != null && !game.breakingBlock()) anchor = null;                                                    // gave up mining
        }
        if (current != null && (game.isAir(current.x(), current.y(), current.z()) || current.center().distanceTo(eye) > range.get())) current = null;
        while (current == null && !queue.isEmpty()) {
            BlockPos n = queue.poll();
            if (!game.isAir(n.x(), n.y(), n.z()) && n.center().distanceTo(eye) <= range.get()) current = n;
        }
        if (current != null && !game.breakBlock(current)) current = null;
    }
}
