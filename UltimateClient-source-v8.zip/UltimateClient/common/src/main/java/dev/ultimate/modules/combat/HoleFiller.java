package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;
import java.util.*;

/** Fills 1x1 holes (solid floor and four solid walls) near you while an enemy is close, using obsidian. */
public final class HoleFiller extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Fill range", 4.5, 1.0, 6.0, 0.1));
    public final Setting.Num enemyRange = add(Setting.Num.dbl("enemy-range", "Only fill holes this close to an enemy", 6.0, 1.0, 12.0, 0.5));
    public final Setting.Num blocksPerTick = add(Setting.Num.intg("blocks-per-tick", "Blocks per tick", 1, 1, 6));
    private final Game game; private final FriendManager friends;
    public HoleFiller(Game g, FriendManager f) { super("hole-filler", "Hole Filler", "Fills nearby holes enemies could use.", Category.COMBAT); game = g; friends = f; }
    private boolean hole(int x, int y, int z) {
        return game.isLoaded(x, z) && game.isAir(x, y, z) && game.isAir(x, y + 1, z) && game.isSolid(x, y - 1, z)
            && game.isSolid(x + 1, y, z) && game.isSolid(x - 1, y, z) && game.isSolid(x, y, z + 1) && game.isSolid(x, y, z - 1);
    }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo me = game.self(); EntityInfo foe = Placer.nearestEnemy(game, friends, 64); if (foe == null) return;
        int r = (int) Math.ceil(range.get()), mx = Placer.fx(me), my = Placer.fy(me), mz = Placer.fz(me);
        List<BlockPos> l = new ArrayList<>();
        for (int x = mx - r; x <= mx + r; x++) for (int z = mz - r; z <= mz + r; z++) for (int y = my - 2; y <= my + 1; y++) {
            if (x == mx && z == mz) continue; // never the hole we stand in
            BlockPos b = new BlockPos(x, y, z);
            if (b.center().distanceTo(me.pos()) > range.get() || b.center().distanceTo(foe.pos()) > enemyRange.get()) continue;
            if (hole(x, y, z)) l.add(b);
        }
        l.sort(Comparator.comparingDouble(b -> b.center().distanceTo(foe.pos())));
        if (Placer.place(game, l, ItemKind.OBSIDIAN, blocksPerTick.asInt(), false) == Placer.NO_ITEM) { game.message("Hole Filler: no obsidian in hotbar"); setEnabled(false); }
    }
}
