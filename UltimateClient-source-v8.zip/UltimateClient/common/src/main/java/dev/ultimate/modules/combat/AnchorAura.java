package dev.ultimate.modules.combat;

import dev.ultimate.combat.Explosion;
import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/**
 * Places a respawn anchor next to the nearest enemy, charges it with glowstone and detonates it with another item,
 * only when the {@link Explosion} model says it hurts the target enough and you little enough.
 * Anchors only explode outside the Nether (vanilla rule); use in the Nether does nothing useful.
 */
public final class AnchorAura extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Reach for placing/charging/detonating", 4.5, 1.0, 6.0, 0.1));
    public final Setting.Num targetRange = add(Setting.Num.dbl("target-range", "Max distance of targets", 8.0, 3.0, 12.0, 0.5));
    public final Setting.Num minDamage = add(Setting.Num.dbl("min-damage", "Minimum damage to the target", 6.0, 0.0, 36.0, 0.5));
    public final Setting.Num maxSelfDamage = add(Setting.Num.dbl("max-self-damage", "Maximum damage to you", 6.0, 0.0, 36.0, 0.5));
    public final Setting.Num selfWeight = add(Setting.Num.dbl("self-weight", "Score penalty per self-damage point", 1.0, 0.0, 4.0, 0.1));
    public final Setting.Num charges = add(Setting.Num.intg("charges", "Glowstone charges before detonating", 1, 1, 4));
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between actions", 1, 0, 20));
    public final Setting.Bool place = add(new Setting.Bool("place", "Place new anchors", true));
    public final Setting.Bool rotate = add(new Setting.Bool("rotate", "Look at the anchor", false));
    public volatile String hudTarget = ""; public volatile float hudTargetDamage, hudSelfDamage;

    private static final int[][] OFFS = {{0, 2, 0}, {1, 1, 0}, {-1, 1, 0}, {0, 1, 1}, {0, 1, -1}, {1, 0, 0}, {-1, 0, 0}, {0, 0, 1}, {0, 0, -1}};
    private final Game game; private final FriendManager friends; private long last = -1000; private boolean warned;

    public AnchorAura(Game g, FriendManager f) { super("anchor-aura", "Anchor Aura", "Places, charges and detonates respawn anchors on nearby enemies.", Category.COMBAT); game = g; friends = f; }

    @Override protected void onDisable() { hudTarget = ""; hudTargetDamage = hudSelfDamage = 0; warned = false; }

    private float[] eval(BlockPos a, EntityInfo me, EntityInfo t) {
        Explosion.Blocks b = (x, y, z) -> !(x == a.x() && y == a.y() && z == a.z()) && game.isSolid(x, y, z);
        float dt = Explosion.damage(Explosion.Kind.ANCHOR, a.center(), t, t.pos(), game.difficulty(), b);
        float ds = Explosion.damage(Explosion.Kind.ANCHOR, a.center(), me, me.pos(), game.difficulty(), b);
        return new float[]{dt, ds};
    }
    private boolean ok(float[] d, EntityInfo me) { return d[0] >= minDamage.asFloat() && d[1] <= maxSelfDamage.asFloat() && d[1] < me.effectiveHealth() - 0.5f; }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        long now = game.tick(); if (now - last < delay.asInt()) return;
        EntityInfo me = game.self(), t = dev.ultimate.util.Placer.nearestEnemy(game, friends, targetRange.get());
        if (t == null) { hudTarget = ""; return; }
        Vec3 eye = Angles.eye(me); int tx = dev.ultimate.util.Placer.fx(t), ty = dev.ultimate.util.Placer.fy(t), tz = dev.ultimate.util.Placer.fz(t);
        BlockPos anchor = null; double bd = Double.MAX_VALUE;
        for (int dx = -3; dx <= 3; dx++) for (int dy = -1; dy <= 3; dy++) for (int dz = -3; dz <= 3; dz++) {
            if (!game.isLoaded(tx + dx, tz + dz)) continue;
            BlockPos p = new BlockPos(tx + dx, ty + dy, tz + dz);
            if (game.anchorCharges(p) < 0 || p.center().distanceTo(eye) > range.get()) continue;
            double d = p.center().distanceTo(t.pos()); if (d < bd) { bd = d; anchor = p; }
        }
        if (anchor != null) { work(anchor, me, t, now); return; }
        if (place.get()) placeNew(me, t, eye, tx, ty, tz, now);
    }

    private void work(BlockPos a, EntityInfo me, EntityInfo t, long now) {
        float[] d = eval(a, me, t); hudTarget = t.name(); hudTargetDamage = d[0]; hudSelfDamage = d[1];
        if (!ok(d, me)) return;
        int c = game.anchorCharges(a), prev = game.selectedSlot();
        if (c < charges.asInt()) {
            int gs = game.hotbarSlotOf(ItemKind.GLOWSTONE);
            if (gs < 0) { if (!warned) { game.message("Anchor Aura: no glowstone in hotbar"); warned = true; } return; }
            game.selectSlot(gs); if (rotate.get()) game.lookAt(a.center()); game.interactBlock(a); game.selectSlot(prev);
        } else {
            int slot = game.mainHand() != ItemKind.GLOWSTONE ? prev : -1;
            for (int i = 0; slot < 0 && i < 9; i++) if (game.kindAt(i) != ItemKind.GLOWSTONE) slot = i;
            if (slot < 0) return;
            game.selectSlot(slot); if (rotate.get()) game.lookAt(a.center()); game.interactBlock(a); game.selectSlot(prev);
        }
        last = now;
    }

    private void placeNew(EntityInfo me, EntityInfo t, Vec3 eye, int tx, int ty, int tz, long now) {
        BlockPos best = null; float bestScore = -Float.MAX_VALUE;
        for (int[] o : OFFS) {
            int x = tx + o[0], y = ty + o[1], z = tz + o[2];
            if (!game.isLoaded(x, z) || !game.isAir(x, y, z)) continue;
            BlockPos p = new BlockPos(x, y, z);
            if (p.center().distanceTo(eye) > range.get()) continue;
            if (!(game.isSolid(x, y - 1, z) || game.isSolid(x + 1, y, z) || game.isSolid(x - 1, y, z) || game.isSolid(x, y, z + 1) || game.isSolid(x, y, z - 1) || game.isSolid(x, y + 1, z))) continue;
            float[] d = eval(p, me, t); if (!ok(d, me)) continue;
            float sc = d[0] - selfWeight.asFloat() * d[1];
            if (sc > bestScore) { bestScore = sc; best = p; }
        }
        if (best == null) return;
        int slot = game.hotbarSlotOf(ItemKind.RESPAWN_ANCHOR); if (slot < 0) return;
        int prev = game.selectedSlot(); game.selectSlot(slot);
        if (rotate.get()) game.lookAt(best.center());
        game.placeBlock(best); game.selectSlot(prev); last = now;
    }
}
