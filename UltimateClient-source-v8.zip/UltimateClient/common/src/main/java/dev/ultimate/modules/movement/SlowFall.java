package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Caps your falling speed. Client-side only; servers with movement checks may correct it. */
public final class SlowFall extends Module {
    public final Setting.Num maxFall = add(Setting.Num.dbl("max-fall", "Fastest allowed fall speed (blocks/tick)", 0.1, 0.02, 0.5, 0.02));
    private final Game game;
    public SlowFall(Game g) { super("slow-fall", "Slow Fall", "Fall gently.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.inWater() || game.gliding()) return;
        EntityInfo me = game.self();
        if (!me.onGround() && me.velocity().y() < -maxFall.get()) game.setVelocity(new Vec3(me.velocity().x(), -maxFall.get(), me.velocity().z()));
    }
}
