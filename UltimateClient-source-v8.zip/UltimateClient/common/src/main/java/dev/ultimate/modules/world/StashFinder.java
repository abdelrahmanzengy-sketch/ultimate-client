package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.*;

/** Counts storage blocks per chunk and tells you in chat when a chunk holds at least the threshold (possible stash). */
public final class StashFinder extends Module {
    public final Setting.Num threshold = add(Setting.Num.intg("threshold", "Announce chunks with at least this many containers", 8, 2, 100));
    public final Setting.Num interval = add(Setting.Num.intg("interval", "Ticks between scans", 40, 10, 400));
    public final Setting.Str types = add(new Setting.Str("types", "Block id fragments counted, comma separated", "chest,barrel,shulker_box,hopper", 200));
    /** Chunks announced so far: "cx,cz" -> container count. */
    public final Map<String, Integer> found = new LinkedHashMap<>();
    private final Game game; private int n;
    public StashFinder(Game g) { super("stash-finder", "Stash Finder", "Reports chunks with many chests and barrels.", Category.WORLD); game = g; }
    @Override protected void onEnable() { found.clear(); n = 0; }
    @Override protected void onDisable() { found.clear(); }
    @Override protected void onWorldLeave() { found.clear(); }
    @Override protected void onTick() {
        if (!game.inWorld() || n++ % interval.asInt() != 0) return;
        String[] want = types.get().toLowerCase(Locale.ROOT).split(","); Map<String, Integer> count = new HashMap<>();
        for (BlockEntry b : game.blockEntities()) {
            String id = b.id().toLowerCase(Locale.ROOT); boolean ok = false; for (String w : want) if (!w.isBlank() && id.contains(w.trim())) { ok = true; break; }
            if (ok) count.merge((b.pos().x() >> 4) + "," + (b.pos().z() >> 4), 1, Integer::sum);
        }
        for (Map.Entry<String, Integer> e : count.entrySet()) {
            if (e.getValue() < threshold.asInt()) continue;
            Integer old = found.get(e.getKey()); if (old != null && old >= e.getValue()) continue;
            found.put(e.getKey(), e.getValue()); String[] c = e.getKey().split(",");
            game.message("Stash? " + e.getValue() + " containers in chunk " + e.getKey() + " (around X " + (Integer.parseInt(c[0]) * 16 + 8) + ", Z " + (Integer.parseInt(c[1]) * 16 + 8) + ")");
        }
    }
}
