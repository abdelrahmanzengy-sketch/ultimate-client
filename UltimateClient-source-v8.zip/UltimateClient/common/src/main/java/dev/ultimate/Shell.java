package dev.ultimate;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.hud.Hud;
import dev.ultimate.modules.render.Waypoints;
import dev.ultimate.modules.world.Excavator;
import dev.ultimate.modules.world.WaypointNav;
import dev.ultimate.util.BaritoneBridge;

import java.io.IOException;
import java.util.*;

/**
 * Text command interpreter behind {@code /uc}. It controls everything a GUI would (toggle, settings, keybinds, favorites,
 * profiles, friends, HUD layout) so the client is fully usable before a Click GUI exists. Pure Java, unit-tested.
 */
public final class Shell {
    private final ModuleManager mm; private final ConfigManager cfg; private final FriendManager friends; private final Hud hud;

    public Shell(ModuleManager mm, ConfigManager cfg, FriendManager friends, Hud hud) { this.mm = mm; this.cfg = cfg; this.friends = friends; this.hud = hud; }

    public static final String HELP = String.join("\n",
        "/uc list [category]            list modules        /uc search <text>",
        "/uc toggle|on|off <module>     switch a module     /uc panic   (disable all)",
        "/uc info <module>              settings + keybind  /uc get|set|reset <module> [setting] [value]",
        "/uc bind <module> <key|none>   /uc binds           /uc fav <module>  /uc favs  /uc recent",
        "/uc save|load|delete <profile> /uc profiles        /uc resetall",
        "/uc friend add|remove|list [name]",
        "/uc hud list | hud toggle <id> | hud move <id> <x 0-1> <y 0-1> | hud reset",
        "/uc wp add|del|list|go <name>  (waypoints; go = walk straight there)",
        "/uc excavator pos1|pos2|clear  (then enable the Excavator module)",
        "/uc baritone <command>         e.g. goto 100 64 100, mine diamond_ore, build x.schematic, cancel");

    public List<String> exec(String line) {
        List<String> out = new ArrayList<>();
        try { run(split(line), out); }
        catch (RuntimeException e) { out.add("Error: " + e.getMessage()); }
        return out;
    }

    private static List<String> split(String s) { List<String> l = new ArrayList<>(); for (String p : s.trim().split("\\s+")) if (!p.isEmpty()) l.add(p); return l; }
    private Module mod(String id, List<String> out) { Module m = mm.get(id.toLowerCase(Locale.ROOT)); if (m == null) { List<Module> hits = mm.search(id); out.add("Unknown module '" + id + "'." + (hits.isEmpty() ? "" : " Did you mean: " + hits.get(0).id + "?")); } return m; }
    private static String state(Module m) { return (m.isEnabled() ? "[ON ] " : "[off] ") + m.id; }

    private void run(List<String> a, List<String> out) {
        if (a.isEmpty() || a.get(0).equalsIgnoreCase("help")) { out.addAll(List.of(HELP.split("\n"))); return; }
        String cmd = a.get(0).toLowerCase(Locale.ROOT);
        switch (cmd) {
            case "list" -> {
                Category only = null;
                if (a.size() > 1) { for (Category c : Category.values()) if (c.label.equalsIgnoreCase(a.get(1)) || c.name().equalsIgnoreCase(a.get(1))) only = c; if (only == null) { out.add("Unknown category. Use: " + Arrays.stream(Category.values()).map(c -> c.label).toList()); return; } }
                for (Category c : Category.values()) {
                    if (only != null && c != only) continue;
                    List<Module> l = mm.inCategory(c); if (l.isEmpty()) continue;
                    StringBuilder b = new StringBuilder(c.label + " (" + l.size() + "): ");
                    for (Module m : l) b.append(m.isEnabled() ? "*" : "").append(m.id).append(' ');
                    out.add(b.toString().trim());
                }
                out.add("* = enabled. /uc info <module> for details.");
            }
            case "search" -> { if (a.size() < 2) { out.add("Usage: /uc search <text>"); return; } for (Module m : mm.search(String.join(" ", a.subList(1, a.size())))) out.add(state(m) + " - " + m.description); if (out.isEmpty()) out.add("No matches."); }
            case "toggle", "on", "off" -> {
                if (a.size() < 2) { out.add("Usage: /uc " + cmd + " <module>"); return; }
                Module m = mod(a.get(1), out); if (m == null) return;
                boolean want = cmd.equals("toggle") ? !m.isEnabled() : cmd.equals("on");
                m.setEnabled(want);
                out.add(m.name + (m.isEnabled() ? " enabled" : " disabled") + (m.lastError() != null ? " (error: " + m.lastError() + ")" : ""));
            }
            case "panic" -> { mm.disableAll(); out.add("All modules disabled."); }
            case "info" -> {
                if (a.size() < 2) { out.add("Usage: /uc info <module>"); return; }
                Module m = mod(a.get(1), out); if (m == null) return;
                out.add(state(m) + "  [" + m.category.label + "]  key: " + Keys.name(m.keybind()) + (mm.isFavorite(m.id) ? "  (favorite)" : ""));
                out.add(m.description);
                if (m.lastError() != null) out.add("Last error: " + m.lastError());
                for (Setting<?> s : m.settings()) out.add("  " + s.id + " = " + show(s) + "   - " + s.description + hint(s));
            }
            case "get" -> {
                if (a.size() < 3) { out.add("Usage: /uc get <module> <setting>"); return; }
                Module m = mod(a.get(1), out); if (m == null) return;
                Setting<?> s = m.setting(a.get(2)); out.add(s == null ? "No setting '" + a.get(2) + "'" : s.id + " = " + show(s));
            }
            case "set" -> {
                if (a.size() < 4) { out.add("Usage: /uc set <module> <setting> <value>"); return; }
                Module m = mod(a.get(1), out); if (m == null) return;
                Setting<?> s = m.setting(a.get(2)); if (s == null) { out.add("No setting '" + a.get(2) + "'. See /uc info " + m.id); return; }
                String raw = String.join(" ", a.subList(3, a.size()));
                String err = apply(s, raw); out.add(err != null ? err : s.id + " = " + show(s));
            }
            case "reset" -> {
                if (a.size() < 2) { out.add("Usage: /uc reset <module> [setting]"); return; }
                Module m = mod(a.get(1), out); if (m == null) return;
                if (a.size() > 2) { Setting<?> s = m.setting(a.get(2)); if (s == null) { out.add("No setting '" + a.get(2) + "'"); return; } s.reset(); out.add(s.id + " = " + show(s)); }
                else { m.resetSettings(); out.add(m.name + " settings reset."); }
            }
            case "resetall" -> { cfg.resetAll(); out.add("All settings reset and keybinds cleared (modules stay as they are)."); }
            case "bind" -> {
                if (a.size() < 3) { out.add("Usage: /uc bind <module> <key|none>   e.g. /uc bind fly G"); return; }
                Module m = mod(a.get(1), out); if (m == null) return;
                int k = Keys.code(a.get(2)); if (k == -2) { out.add("Unknown key '" + a.get(2) + "'. Try a letter, digit, F1-F12, LSHIFT, UP, NUM0..."); return; }
                m.setKeybind(k); out.add(m.name + " key: " + Keys.name(m.keybind()));
            }
            case "binds" -> { for (Module m : mm.all()) if (m.keybind() >= 0) out.add(Keys.name(m.keybind()) + "  ->  " + m.id); if (out.isEmpty()) out.add("No keybinds set. /uc bind <module> <key>"); }
            case "fav" -> { if (a.size() < 2) { out.add("Usage: /uc fav <module>"); return; } Module m = mod(a.get(1), out); if (m == null) return; mm.setFavorite(m.id, !mm.isFavorite(m.id)); out.add(m.name + (mm.isFavorite(m.id) ? " added to favorites" : " removed from favorites")); }
            case "favs" -> { out.add(mm.favorites().isEmpty() ? "No favorites." : "Favorites: " + String.join(", ", mm.favorites())); }
            case "recent" -> { out.add(mm.recent().isEmpty() ? "Nothing used yet." : "Recently enabled: " + String.join(", ", mm.recent())); }
            case "profiles" -> { List<String> p = cfg.profiles(); out.add(p.isEmpty() ? "No saved profiles." : "Profiles: " + String.join(", ", p) + "   (active: " + cfg.activeProfile() + ")"); }
            case "save" -> { String n = a.size() > 1 ? a.get(1) : cfg.activeProfile(); String e = save(n); out.add(e != null ? e : "Saved profile '" + n + "'."); }
            case "load" -> { String n = a.size() > 1 ? a.get(1) : cfg.activeProfile(); String e = load(n); out.add(e != null ? e : "Loaded profile '" + n + "'."); }
            case "delete" -> {
                if (a.size() < 2) { out.add("Usage: /uc delete <profile>"); return; }
                try { out.add(cfg.delete(a.get(1)) ? "Deleted '" + a.get(1) + "'." : "No such profile."); } catch (IOException e) { out.add("Delete failed: " + e.getMessage()); }
            }
            case "friend" -> friend(a, out);
            case "hud" -> hud(a, out);
            case "wp" -> wp(a, out);
            case "excavator" -> excavator(a, out);
            case "baritone" -> { if (a.size() < 2) { out.add("Usage: /uc baritone <command>"); return; } String e = BaritoneBridge.execute(String.join(" ", a.subList(1, a.size()))); out.add(e == null ? "Sent to Baritone." : e); }
            default -> out.add("Unknown command '" + cmd + "'. /uc help");
        }
    }

    private void wp(List<String> a, List<String> out) {
        if (!(mm.get("waypoints") instanceof Waypoints w)) { out.add("Waypoints module is not available."); return; }
        String sub = a.size() > 1 ? a.get(1).toLowerCase(Locale.ROOT) : "list";
        switch (sub) {
            case "add" -> { if (a.size() < 3) { out.add("Usage: /uc wp add <name>"); return; } String e = w.addHere(a.get(2)); out.add(e == null ? "Waypoint " + a.get(2) + " saved here." : e); }
            case "del", "remove" -> { if (a.size() < 3) { out.add("Usage: /uc wp del <name>"); return; } out.add(w.remove(a.get(2)) ? "Removed " + a.get(2) + "." : "No waypoint called " + a.get(2) + "."); }
            case "list" -> { if (w.list().isEmpty()) out.add("No waypoints. /uc wp add <name>"); for (Waypoints.Waypoint p : w.list()) out.add(p.name() + "  " + p.x() + " " + p.y() + " " + p.z()); }
            case "go" -> {
                if (a.size() < 3) { out.add("Usage: /uc wp go <name>"); return; }
                Waypoints.Waypoint p = w.find(a.get(2)); if (p == null) { out.add("No waypoint called " + a.get(2) + "."); return; }
                if (!(mm.get("waypoint-nav") instanceof WaypointNav nav)) { out.add("Waypoint Navigation is not available."); return; }
                nav.setTarget(p.name(), p.x(), p.y(), p.z()); nav.setEnabled(true); out.add("Walking to " + p.name() + " (straight line, no path-finding).");
            }
            default -> out.add("Usage: /uc wp add|del|list|go <name>");
        }
    }

    private void excavator(List<String> a, List<String> out) {
        if (!(mm.get("excavator") instanceof Excavator x)) { out.add("Excavator is not available."); return; }
        String sub = a.size() > 1 ? a.get(1).toLowerCase(Locale.ROOT) : "";
        switch (sub) {
            case "pos1" -> out.add(x.setPos(1, false));
            case "pos2" -> out.add(x.setPos(2, false));
            case "clear" -> out.add(x.setPos(0, true));
            default -> out.add("Usage: /uc excavator pos1|pos2|clear");
        }
    }

    private void friend(List<String> a, List<String> out) {
        String sub = a.size() > 1 ? a.get(1).toLowerCase(Locale.ROOT) : "list";
        switch (sub) {
            case "add" -> { if (a.size() < 3) { out.add("Usage: /uc friend add <name>"); return; } out.add(friends.add(a.get(2)) ? a.get(2) + " is now a friend." : "Already a friend."); }
            case "remove" -> { if (a.size() < 3) { out.add("Usage: /uc friend remove <name>"); return; } out.add(friends.remove(a.get(2)) ? a.get(2) + " removed." : "Not in the friend list."); }
            case "list" -> out.add(friends.all().isEmpty() ? "No friends." : "Friends: " + String.join(", ", friends.all()));
            default -> out.add("Usage: /uc friend add|remove|list [name]");
        }
    }

    private void hud(List<String> a, List<String> out) {
        if (hud == null) { out.add("HUD is not available."); return; }
        String sub = a.size() > 1 ? a.get(1).toLowerCase(Locale.ROOT) : "list";
        switch (sub) {
            case "list" -> { for (Hud.Element e : hud.elements()) out.add((e.enabled ? "[ON ] " : "[off] ") + e.id + String.format(Locale.ROOT, "  at %.2f,%.2f", e.x, e.y)); }
            case "toggle" -> { Hud.Element e = a.size() > 2 ? hud.get(a.get(2)) : null; if (e == null) { out.add("Usage: /uc hud toggle <id>  (see /uc hud list)"); return; } e.enabled = !e.enabled; out.add(e.id + (e.enabled ? " shown" : " hidden")); }
            case "move" -> {
                Hud.Element e = a.size() > 4 ? hud.get(a.get(2)) : null; if (e == null) { out.add("Usage: /uc hud move <id> <x 0-1> <y 0-1>"); return; }
                try { e.moveTo(Double.parseDouble(a.get(3)), Double.parseDouble(a.get(4))); out.add(String.format(Locale.ROOT, "%s moved to %.2f,%.2f", e.id, e.x, e.y)); } catch (NumberFormatException ex) { out.add("x and y must be numbers between 0 and 1"); }
            }
            case "reset" -> { Hud fresh = new Hud(); for (Hud.Element e : hud.elements()) { Hud.Element f = fresh.get(e.id); e.moveTo(f.x, f.y); e.setScale(f.scale); e.enabled = f.enabled; } out.add("HUD layout reset."); }
            default -> out.add("Usage: /uc hud list|toggle|move|reset");
        }
    }

    // ---- persistence that includes friends and the HUD layout ----
    public String save(String profile) {
        try { if (hud != null) hud.save(mm.layout); mm.layout.put("friends", friends.toJson()); cfg.save(profile); return null; }
        catch (IOException | IllegalArgumentException e) { return "Save failed: " + e.getMessage(); }
    }
    public String load(String profile) {
        String err = cfg.load(profile); if (err != null) return err;
        if (hud != null) hud.load(mm.layout);
        friends.fromJson(mm.layout.get("friends")); return null;
    }

    // ---- setting parsing ----
    @SuppressWarnings("unchecked")
    private static String apply(Setting<?> s, String raw) {
        if (s instanceof Setting.Bool b) {
            String v = raw.toLowerCase(Locale.ROOT);
            Boolean val = switch (v) { case "on", "true", "yes", "1" -> true; case "off", "false", "no", "0" -> false; case "toggle" -> !b.get(); default -> null; };
            return val == null ? "Expected on/off" : (b.set(val) ? null : "Rejected");
        }
        if (s instanceof Setting.Num n) {
            double v; try { v = Double.parseDouble(raw); } catch (NumberFormatException e) { return "Expected a number between " + fmt(n.min) + " and " + fmt(n.max); }
            if (Double.isNaN(v) || Double.isInfinite(v)) return "Expected a finite number";
            n.set(v); return v < n.min || v > n.max ? "(clamped to " + fmt(n.get()) + ") " : null;
        }
        if (s instanceof Setting.Mode m) {
            for (String o : m.modes) if (o.equalsIgnoreCase(raw)) { m.set(o); return null; }
            return "Choose one of: " + String.join(", ", m.modes);
        }
        if (s instanceof Setting.Color c) {
            String h = raw.startsWith("#") ? raw.substring(1) : raw;
            if (!h.matches("[0-9a-fA-F]{6}|[0-9a-fA-F]{8}")) return "Expected #RRGGBB or #AARRGGBB";
            long v = Long.parseLong(h, 16); if (h.length() == 6) v |= 0xFF000000L; c.set((int) v); return null;
        }
        if (s instanceof Setting.Key k) { int code = Keys.code(raw); if (code == -2) return "Unknown key"; k.set(code); return null; }
        if (s instanceof Setting.Str t) { t.set(raw); return null; }
        return "Unsupported setting type";
    }
    private static String fmt(double d) { return d == Math.rint(d) && Math.abs(d) < 1e9 ? String.valueOf((long) d) : String.format(Locale.ROOT, "%.2f", d); }
    private static String show(Setting<?> s) {
        if (s instanceof Setting.Color c) return String.format(Locale.ROOT, "#%08X", c.get());
        if (s instanceof Setting.Num n) return fmt(n.get());
        if (s instanceof Setting.Key k) return Keys.name(k.get());
        return String.valueOf(s.get());
    }
    private static String hint(Setting<?> s) {
        if (s instanceof Setting.Num n) return "  [" + fmt(n.min) + ".." + fmt(n.max) + "]";
        if (s instanceof Setting.Mode m) return "  [" + String.join("|", m.modes) + "]";
        return "";
    }
}
