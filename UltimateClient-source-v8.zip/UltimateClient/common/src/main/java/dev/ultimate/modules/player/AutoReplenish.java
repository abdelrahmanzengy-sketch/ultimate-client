package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Refills a dwindling hotbar stack from an identical stack in the main inventory. Matches exact item ids. */
public final class AutoReplenish extends Module {
    public final Setting.Num threshold = add(Setting.Num.intg("threshold", "Refill when a hotbar stack has this many or fewer", 8, 1, 32));
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between refills", 4, 1, 40));
    private final Game game; private long last = -1000;
    public AutoReplenish(Game g) { super("auto-replenish", "Auto Replenish", "Keeps your hotbar stacks topped up.", Category.PLAYER); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        long now = game.tick(); if (now - last < delay.asInt()) return;
        for (int i = 0; i < 9; i++) {
            String id = game.itemId(i);
            if (id.isEmpty() || game.stackCount(i) > threshold.asInt()) continue;
            for (int s = 9; s < 36; s++)
                if (id.equals(game.itemId(s)) && game.stackCount(s) > 0) { game.mergeIntoHotbar(s, i); last = now; return; }
        }
    }
}
