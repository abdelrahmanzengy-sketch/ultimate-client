package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.ArrayList;
import java.util.List;

/** Predicts where the item in your hand (bow, pearl, trident, snowball, egg, XP bottle) will land. Uses vanilla speed/gravity/drag constants. */
public final class Trajectories extends EspModule {
    public final Setting.Num steps = add(Setting.Num.intg("steps", "Maximum simulated ticks", 80, 10, 200));
    public Trajectories(Game g) { super("trajectories", "Trajectories", "Shows where thrown items and arrows will land.", g); color.set(0xFF40C0FF); }

    /** {speed, gravity, drag} for the held item id, or null if it is not a projectile. */
    public static double[] physics(String itemId) {
        if (itemId == null) return null;
        if (itemId.endsWith("ender_pearl") || itemId.endsWith("snowball") || itemId.endsWith("egg")) return new double[]{1.5, 0.03, 0.99};
        if (itemId.endsWith("trident")) return new double[]{2.5, 0.05, 0.99};
        if (itemId.endsWith("bow") || itemId.endsWith("crossbow")) return new double[]{3.0, 0.05, 0.99};
        if (itemId.endsWith("experience_bottle")) return new double[]{0.7, 0.07, 0.99};
        if (itemId.endsWith("splash_potion") || itemId.endsWith("lingering_potion")) return new double[]{0.5, 0.05, 0.99};
        return null;
    }
    /** Steps a projectile until it enters a solid block (last point is inside it) or runs out of steps. */
    public static List<Vec3> simulate(Game g, Vec3 start, Vec3 velocity, double gravity, double drag, int maxSteps) {
        List<Vec3> pts = new ArrayList<>(); Vec3 p = start, v = velocity; pts.add(p);
        for (int i = 0; i < maxSteps; i++) {
            p = p.add(v); v = new Vec3(v.x() * drag, v.y() * drag - gravity, v.z() * drag); pts.add(p);
            int x = (int) Math.floor(p.x()), y = (int) Math.floor(p.y()), z = (int) Math.floor(p.z());
            if (!g.isLoaded(x, z) || g.isSolid(x, y, z) || y < -128) break;
        }
        return pts;
    }
    @Override protected void draw(RenderQueue q) {
        double[] ph = physics(game.itemId(game.selectedSlot())); if (ph == null) return;
        Vec3 start = Angles.eye(game.self()).add(0, -0.1, 0), dir = Angles.look(game.yaw(), game.pitch());
        List<Vec3> pts = simulate(game, start, dir.scale(ph[0]), ph[1], ph[2], steps.asInt());
        for (int i = 1; i < pts.size(); i++) line(q, pts.get(i - 1), pts.get(i), col());
        Vec3 end = pts.get(pts.size() - 1);
        box(q, end.add(-0.25, -0.25, -0.25), end.add(0.25, 0.25, 0.25), col());
    }
}
