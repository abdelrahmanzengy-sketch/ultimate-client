package dev.ultimate.modules.combat;

import dev.ultimate.combat.Explosion;
import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/**
 * Steps through one respawn anchor you aim at: place it (optional), charge it with glowstone, detonate it with another
 * hotbar slot. Anchors only explode outside the Nether. Refuses to detonate when the damage model says it hurts you too much.
 */
public final class SingleAnchorMacro extends Module {
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between steps", 2, 0, 20));
    public final Setting.Num charges = add(Setting.Num.intg("charges", "Glowstone charges before detonating", 1, 1, 4));
    public final Setting.Bool placeAnchor = add(new Setting.Bool("place", "Place an anchor on the aimed block first", false));
    public final Setting.Num maxSelf = add(Setting.Num.dbl("max-self-damage", "Do not detonate if you would take more than this", 8.0, 0.0, 36.0, 0.5));
    public final Setting.Num detonateSlot = add(Setting.Num.intg("detonate-slot", "Hotbar slot (1-9) used to detonate; must not hold glowstone", 1, 1, 9));
    private final Game game; private long last = -1000; private int prevSlot = -1;
    public SingleAnchorMacro(Game g) { super("single-anchor-macro", "Single Anchor Macro", "Place, charge and detonate the anchor you aim at.", Category.COMBAT); game = g; }
    @Override protected void onDisable() { restore(); }
    @Override protected void onWorldLeave() { prevSlot = -1; }
    private void restore() { if (prevSlot >= 0 && game.inWorld()) game.selectSlot(prevSlot); prevSlot = -1; }
    private void use(int slot) { if (prevSlot < 0) prevSlot = game.selectedSlot(); game.selectSlot(slot); }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        long now = game.tick(); if (now - last < delay.asInt()) return;
        BlockPos t = game.targetBlock(); if (t == null) { restore(); return; }
        int c = game.anchorCharges(t);
        if (c < 0) { // not an anchor: optionally place one on top of the aimed block
            int a = game.hotbarSlotOf(ItemKind.RESPAWN_ANCHOR);
            if (placeAnchor.get() && a >= 0 && game.isSolid(t.x(), t.y(), t.z()) && game.isAir(t.x(), t.y() + 1, t.z())) { use(a); if (game.placeBlock(t.up())) last = now; }
            return;
        }
        if (c < charges.asInt()) {
            int g = game.hotbarSlotOf(ItemKind.GLOWSTONE); if (g < 0) return;
            use(g); if (game.interactBlock(t)) last = now; return;
        }
        EntityInfo me = game.self();
        float self = Explosion.damage(Explosion.Kind.ANCHOR, t.center(), me, me.pos(), game.difficulty(), (x, y, z) -> !(x == t.x() && y == t.y() && z == t.z()) && game.isSolid(x, y, z));
        if (self > maxSelf.get() || self >= me.effectiveHealth() - 0.5f) return;
        int slot = detonateSlot.asInt() - 1; if (game.kindAt(slot) == ItemKind.GLOWSTONE || game.hotbarSlotOf(ItemKind.GLOWSTONE) == slot) return;
        use(slot); if (game.interactBlock(t)) { last = now; restore(); }
    }
}
