package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;
import java.util.*;

/** Places cobwebs at the nearest enemy's feet and head. */
public final class AutoWeb extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Target and placement range", 4.5, 1.0, 6.0, 0.1));
    public final Setting.Bool head = add(new Setting.Bool("head", "Also web head height", true));
    private final Game game; private final FriendManager friends;
    public AutoWeb(Game g, FriendManager f) { super("auto-web", "Auto Web", "Webs the nearest enemy.", Category.COMBAT); game = g; friends = f; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo t = Placer.nearestEnemy(game, friends, range.get()); if (t == null) return;
        int x = Placer.fx(t), y = Placer.fy(t), z = Placer.fz(t);
        List<BlockPos> l = new ArrayList<>(List.of(new BlockPos(x, y, z))); if (head.get()) l.add(new BlockPos(x, y + 1, z));
        if (Placer.place(game, l, ItemKind.WEB, 2, false) == Placer.NO_ITEM) { game.message("Auto Web: no cobwebs in hotbar"); setEnabled(false); }
    }
}
