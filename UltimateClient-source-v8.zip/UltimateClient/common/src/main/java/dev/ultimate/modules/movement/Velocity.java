package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Scales the knockback you take, client side, on the tick after you are hit. The server still decides your real position. */
public final class Velocity extends Module {
    public final Setting.Num horizontal = add(Setting.Num.dbl("horizontal", "Horizontal knockback kept (percent)", 0.0, 0.0, 100.0, 5.0));
    public final Setting.Num vertical = add(Setting.Num.dbl("vertical", "Vertical knockback kept (percent)", 100.0, 0.0, 100.0, 5.0));
    private final Game game; private int prev;
    public Velocity(Game g) { super("velocity", "Velocity", "Reduces knockback you take (client side).", Category.MOVEMENT); game = g; }
    @Override protected void onEnable() { prev = 0; }
    @Override protected void onWorldLeave() { prev = 0; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        int h = game.hurtTime(); boolean fresh = h > 0 && prev == 0; prev = h;
        if (!fresh) return;
        Vec3 v = game.self().velocity();
        game.setVelocity(new Vec3(v.x() * horizontal.get() / 100.0, v.y() * vertical.get() / 100.0, v.z() * horizontal.get() / 100.0));
    }
}
