package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Adds extra break progress each tick while you mine a block. Servers that check break speed may reject the result. */
public final class SpeedMine extends Module {
    public final Setting.Num boost = add(Setting.Num.dbl("boost", "Extra progress per tick (0.1 = a tenth of a block)", 0.05, 0.01, 0.5, 0.01));
    private final Game game;
    public SpeedMine(Game g) { super("speed-mine", "Speed Mine", "Mines blocks faster.", Category.PLAYER); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.breakingBlock()) return;
        float p = game.breakProgress(); if (p > 0f && p < 1f) game.setBreakProgress(Math.min(0.999f, p + boost.asFloat()));
    }
}
