package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;
import java.util.*;

/** Boxes the nearest enemy in with obsidian (sides at feet and head height, plus the top). */
public final class AutoTrap extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Target and placement range", 4.5, 1.0, 6.0, 0.1));
    public final Setting.Num blocksPerTick = add(Setting.Num.intg("blocks-per-tick", "Blocks per tick", 2, 1, 8));
    public final Setting.Bool top = add(new Setting.Bool("top", "Cover the top", true));
    public final Setting.Bool rotate = add(new Setting.Bool("rotate", "Look at placement", false));
    private final Game game; private final FriendManager friends;
    public AutoTrap(Game g, FriendManager f) { super("auto-trap", "Auto Trap", "Traps the nearest enemy in obsidian.", Category.COMBAT); game = g; friends = f; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo t = Placer.nearestEnemy(game, friends, range.get()); if (t == null) return;
        int x = Placer.fx(t), y = Placer.fy(t), z = Placer.fz(t);
        List<BlockPos> l = new ArrayList<>();
        int[][] s = {{1,0},{-1,0},{0,1},{0,-1}};
        for (int h = 0; h <= 1; h++) for (int[] d : s) l.add(new BlockPos(x + d[0], y + h, z + d[1]));
        if (top.get()) l.add(new BlockPos(x, y + 2, z));
        int r = Placer.place(game, l, ItemKind.OBSIDIAN, blocksPerTick.asInt(), rotate.get());
        if (r == Placer.NO_ITEM) { game.message("Auto Trap: no obsidian in hotbar"); setEnabled(false); }
    }
}
