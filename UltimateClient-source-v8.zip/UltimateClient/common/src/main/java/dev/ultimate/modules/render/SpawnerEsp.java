package dev.ultimate.modules.render;

import dev.ultimate.game.*;

/** Block ESP preset for monster spawners. */
public final class SpawnerEsp extends BlockEsp {
    public SpawnerEsp(Game g) { super(g, "spawner-esp", "Spawner ESP", "Highlights monster spawners.", "spawner"); color.set(0xFF7030FF); }
    @Override protected java.util.List<String> fragments() { return java.util.List.of("spawner"); }
}
