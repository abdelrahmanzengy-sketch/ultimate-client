package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Auto-sneaks at ledges so you cannot walk off an edge. Releases the forced sneak as soon as it is safe. */
public final class SafeWalk extends Module {
    public final Setting.Num maxDrop = add(Setting.Num.intg("max-drop", "Drops of at most this many blocks are allowed", 2, 1, 5));
    public final Setting.Num lookAhead = add(Setting.Num.dbl("look-ahead", "Ticks of motion to look ahead", 3.0, 1.0, 8.0, 0.5));
    private final Game game; private boolean forced;
    public SafeWalk(Game g) { super("safe-walk", "Safe Walk", "Prevents falling off ledges.", Category.MOVEMENT); game = g; }
    private void release() { if (forced) { game.setSneakInput(false); forced = false; } }
    @Override protected void onDisable() { if (game.inWorld()) release(); forced = false; }
    @Override protected void onWorldLeave() { forced = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo me = game.self();
        if (!me.onGround() || !game.movingAny()) { release(); return; }
        Vec3 probe = me.pos().add(me.velocity().x() * lookAhead.get(), 0, me.velocity().z() * lookAhead.get());
        int px = (int) Math.floor(probe.x()), pz = (int) Math.floor(probe.z()), fy = (int) Math.floor(me.pos().y());
        boolean edge = game.isLoaded(px, pz);
        if (edge) for (int i = 1; i <= maxDrop.asInt(); i++) if (game.isSolid(px, fy - i, pz)) { edge = false; break; }
        if (edge) { game.setSneakInput(true); forced = true; } else release();
    }
}
