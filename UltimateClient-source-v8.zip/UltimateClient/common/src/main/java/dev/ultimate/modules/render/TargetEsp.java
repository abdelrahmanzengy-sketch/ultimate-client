package dev.ultimate.modules.render;

import dev.ultimate.core.FriendManager;
import dev.ultimate.core.RenderQueue;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;

/** Highlights the nearest non-friend player with a filled box and a name/health/distance label. */
public final class TargetEsp extends EspModule {
    private final FriendManager friends;
    public TargetEsp(Game g, FriendManager f) { super("target-esp", "Target ESP", "Highlights the nearest enemy player.", g); friends = f; style.set("Both"); }
    @Override protected void draw(RenderQueue q) {
        EntityInfo t = Placer.nearestEnemy(game, friends, distance.get()); if (t == null) return;
        entityBox(q, t, col());
        label(q, t.pos().add(0, t.height() + 0.4, 0), String.format(java.util.Locale.ROOT, "%s  %.0f hp  %.1fm", t.name(), t.effectiveHealth(), t.pos().distanceTo(game.self().pos())));
    }
}
