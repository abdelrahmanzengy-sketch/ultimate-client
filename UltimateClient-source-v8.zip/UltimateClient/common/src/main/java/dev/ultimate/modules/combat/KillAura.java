package dev.ultimate.modules.combat;

import dev.ultimate.combat.Explosion;
import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.core.FriendManager;
import dev.ultimate.game.*;

import java.util.*;

/** Attacks nearby entities in range with cooldown awareness, line-of-sight range limit, friend protection and priorities. */
public final class KillAura extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Attack range", 3.5, 1.0, 6.0, 0.1));
    public final Setting.Num wallRange = add(Setting.Num.dbl("wall-range", "Range when no line of sight", 0.0, 0.0, 6.0, 0.1));
    public final Setting.Bool players = add(new Setting.Bool("players", "Target players", true));
    public final Setting.Bool animals = add(new Setting.Bool("animals", "Target passive mobs", false));
    public final Setting.Bool monsters = add(new Setting.Bool("monsters", "Target hostile mobs", true));
    public final Setting.Bool targetFriends = add(new Setting.Bool("target-friends", "Target friends (normally off)", false));
    public final Setting.Mode priority = add(new Setting.Mode("priority", "Target priority", "Distance", "Distance", "Health", "Angle"));
    public final Setting.Num maxTargets = add(Setting.Num.intg("max-targets", "Entities hit per swing", 1, 1, 5));
    public final Setting.Bool rotate = add(new Setting.Bool("rotate", "Look at the target", true));
    public final Setting.Num minCooldown = add(Setting.Num.dbl("min-cooldown", "Attack cooldown progress required (0-1)", 0.95, 0.0, 1.0, 0.05));

    private final Game game; private final FriendManager friends;

    public KillAura(Game game, FriendManager friends) {
        super("kill-aura", "Kill Aura", "Automatically attacks nearby entities.", Category.COMBAT);
        this.game = game; this.friends = friends;
    }

    private static Vec3 eye(EntityInfo e) { return e.pos().add(0, e.height() * 0.9, 0); }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        if (game.attackCooldown() < minCooldown.get()) return;
        EntityInfo me = game.self();
        Vec3 myEye = eye(me);
        List<EntityInfo> c = new ArrayList<>();
        for (EntityInfo e : game.entities()) {
            boolean ok = switch (e.kind()) {
                case PLAYER -> players.get() && (targetFriends.get() || !friends.isFriend(e.name()));
                case PASSIVE -> animals.get();
                case HOSTILE -> monsters.get();
                default -> false;
            };
            if (!ok || e.health() <= 0) continue;
            double d = myEye.distanceTo(eye(e));
            if (d > range.get()) continue;
            if (d > wallRange.get() && !Explosion.clear(game::isSolid, myEye.x(), myEye.y(), myEye.z(), eye(e).x(), eye(e).y(), eye(e).z())) continue;
            c.add(e);
        }
        if (c.isEmpty()) return;
        c.sort(switch (priority.get()) {
            case "Health" -> Comparator.comparingDouble(EntityInfo::effectiveHealth);
            case "Angle" -> Comparator.comparingDouble(e -> angleTo(me, e));
            default -> Comparator.comparingDouble(e -> e.pos().distanceTo(me.pos()));
        });
        int n = Math.min(maxTargets.asInt(), c.size());
        if (rotate.get()) game.lookAt(eye(c.get(0)));
        for (int i = 0; i < n; i++) game.attack(c.get(i).id());
    }

    private double angleTo(EntityInfo me, EntityInfo e) {
        double yaw = Math.toDegrees(Math.atan2(-(e.pos().x() - me.pos().x()), e.pos().z() - me.pos().z()));
        double d = Math.abs(((yaw - game.yaw()) % 360 + 540) % 360 - 180);
        return d;
    }
}
