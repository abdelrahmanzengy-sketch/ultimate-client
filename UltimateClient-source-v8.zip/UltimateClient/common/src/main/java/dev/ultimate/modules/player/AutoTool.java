package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Selects the fastest hotbar tool for the block you are mining and restores your slot afterwards. */
public final class AutoTool extends Module {
    public final Setting.Bool switchBack = add(new Setting.Bool("switch-back", "Restore the previous slot when you stop mining", true));
    private final Game game; private int prev = -1;
    public AutoTool(Game g) { super("auto-tool", "Auto Tool", "Picks the best tool while mining.", Category.PLAYER); game = g; }
    private void restore() { if (prev >= 0 && game.inWorld()) game.selectSlot(prev); prev = -1; }
    @Override protected void onDisable() { restore(); }
    @Override protected void onWorldLeave() { prev = -1; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (!game.breakingBlock()) { if (switchBack.get()) restore(); return; }
        BlockPos t = game.targetBlock(); if (t == null) return;
        int slot = game.bestToolSlotFor(t);
        if (slot >= 0 && slot != game.selectedSlot()) { if (prev < 0) prev = game.selectedSlot(); game.selectSlot(slot); }
    }
}
