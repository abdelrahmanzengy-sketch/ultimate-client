package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;
import java.util.*;

/** Covers your head (and optionally your sides at head height) with obsidian. */
public final class SelfTrap extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("mode", "Top = above head, Full = also head-height sides", "Top", "Top", "Full"));
    public final Setting.Num blocksPerTick = add(Setting.Num.intg("blocks-per-tick", "Blocks per tick", 2, 1, 8));
    private final Game game;
    public SelfTrap(Game g) { super("self-trap", "Self Trap", "Places obsidian above/around your head.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo me = game.self(); int x = Placer.fx(me), y = Placer.fy(me), z = Placer.fz(me);
        List<BlockPos> l = new ArrayList<>();
        if (mode.get().equals("Full")) for (int[] d : new int[][]{{1,0},{-1,0},{0,1},{0,-1}}) l.add(new BlockPos(x + d[0], y + 1, z + d[1]));
        l.add(new BlockPos(x, y + 2, z));
        if (Placer.place(game, l, ItemKind.OBSIDIAN, blocksPerTick.asInt(), false) == Placer.NO_ITEM) { game.message("Self Trap: no obsidian in hotbar"); setEnabled(false); }
    }
}
