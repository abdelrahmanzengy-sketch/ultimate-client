package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.*;

/** Remembers where a nearby player was when their name vanished from the server player list. Needs the player list to be available. */
public final class LogoutSpots extends EspModule {
    public final Setting.Num keep = add(Setting.Num.intg("keep", "Spots remembered", 10, 1, 40));
    public final Setting.Num seen = add(Setting.Num.dbl("seen-range", "Only record players who were this close", 64.0, 8.0, 160.0, 8.0));
    private record Spot(String name, Vec3 pos, long tick, double height) {}
    private final Map<String, Vec3> lastPos = new HashMap<>(); private final Set<String> online = new HashSet<>(); private final ArrayDeque<Spot> spots = new ArrayDeque<>();
    public LogoutSpots(Game g) { super("logout-spots", "Logout Spots", "Marks where players logged out.", g); color.set(0xFFFF8030); }
    @Override protected void onDisable() { lastPos.clear(); online.clear(); spots.clear(); }
    @Override protected void onWorldLeave() { lastPos.clear(); online.clear(); spots.clear(); }
    @Override protected void onTick() {
        if (!game.inWorld()) return;
        List<String> tab = game.onlinePlayerNames(); if (tab.isEmpty()) return; // no player list: cannot tell a logout from leaving range
        online.clear(); for (String n : tab) if (n != null) online.add(n);
        Vec3 me = game.self().pos(); Set<String> visible = new HashSet<>();
        for (EntityInfo e : game.entities()) if (e.kind() == EntityInfo.Kind.PLAYER) { visible.add(e.name()); if (e.pos().distanceTo(me) <= seen.get()) lastPos.put(e.name(), e.pos()); }
        for (Iterator<Map.Entry<String, Vec3>> it = lastPos.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<String, Vec3> en = it.next();
            if (visible.contains(en.getKey())) continue;
            if (!online.contains(en.getKey())) { spots.addLast(new Spot(en.getKey(), en.getValue(), game.tick(), 1.8)); while (spots.size() > keep.asInt()) spots.pollFirst(); }
            it.remove();
        }
    }
    @Override protected void draw(RenderQueue q) {
        for (Spot s : spots) {
            if (!within(s.pos())) continue;
            box(q, s.pos().add(-0.3, 0, -0.3), s.pos().add(0.3, s.height(), 0.3), col());
            label(q, s.pos().add(0, s.height() + 0.3, 0), s.name() + " " + (game.tick() - s.tick()) / 1200 + "m ago");
        }
    }
    public int count() { return spots.size(); }
}
