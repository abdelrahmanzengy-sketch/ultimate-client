package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/**
 * Presses jump for one tick right after you are hit while standing on the ground, so the knockback is taken
 * as a jump. Only presses the normal jump input; nothing is sent that a player could not do by hand.
 */
public final class JumpReset extends Module {
    public final Setting.Num chance = add(Setting.Num.intg("chance", "Chance to react to a hit (percent)", 100, 1, 100));
    public final Setting.Bool needSprint = add(new Setting.Bool("only-moving", "Only react while holding a movement key", false));
    private final Game game; private boolean pressed; private int lastHurt; private final java.util.Random rng = new java.util.Random();
    public JumpReset(Game g) { super("jump-reset", "Jump Reset", "Jumps the moment you are hit on the ground.", Category.COMBAT); game = g; }
    @Override protected void onEnable() { lastHurt = 0; pressed = false; }
    @Override protected void onDisable() { if (pressed && game.inWorld()) game.setJumpInput(false); pressed = false; }
    @Override protected void onWorldLeave() { pressed = false; lastHurt = 0; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (pressed) { game.setJumpInput(false); pressed = false; }
        int hurt = game.hurtTime();
        boolean fresh = hurt > 0 && lastHurt == 0; // rising edge: one reaction per hit
        lastHurt = hurt;
        if (!fresh || game.sneaking() || !game.self().onGround() || game.screenOpen()) return;
        if (needSprint.get() && !game.movingAny()) return;
        if (rng.nextInt(100) >= chance.asInt()) return;
        game.setJumpInput(true); pressed = true;
    }
}
