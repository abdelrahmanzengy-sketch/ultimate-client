package dev.ultimate.modules.render;

import dev.ultimate.core.FriendManager;
import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Boxes around other players; friends use their own colour. */
public final class PlayerEsp extends EspModule {
    public final Setting.Color friendColor = add(new Setting.Color("friend-color", "Colour for friends", 0xFF30FF60));
    public final Setting.Bool health = add(new Setting.Bool("health", "Show health in the label", true));
    private final FriendManager friends;
    public PlayerEsp(Game g, FriendManager f) { super("player-esp", "Player ESP", "Highlights other players.", g); friends = f; }
    @Override protected void draw(RenderQueue q) {
        for (EntityInfo e : game.entities()) {
            if (e.kind() != EntityInfo.Kind.PLAYER || !within(e.pos())) continue;
            boolean fr = friends.isFriend(e.name()); entityBox(q, e, fr ? withOpacity(friendColor.get()) : col());
            label(q, e.pos().add(0, e.height() + 0.3, 0), health.get() ? String.format(java.util.Locale.ROOT, "%s %.0f", e.name(), e.effectiveHealth()) : e.name());
        }
    }
}
