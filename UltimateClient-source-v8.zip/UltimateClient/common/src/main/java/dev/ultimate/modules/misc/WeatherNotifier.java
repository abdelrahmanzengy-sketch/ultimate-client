package dev.ultimate.modules.misc;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Tells you when rain starts or stops. */
public final class WeatherNotifier extends Module {
    public final Setting.Bool rainStart = add(new Setting.Bool("announce-rain", "Announce when rain starts", true));
    public final Setting.Bool rainStop = add(new Setting.Bool("announce-clear", "Announce when rain stops", true));
    private final Game game; private Boolean last;
    public WeatherNotifier(Game g) { super("weather-notifier", "Weather Notifier", "Announces weather changes.", Category.MISC); game = g; }
    @Override protected void onEnable() { last = null; }
    @Override protected void onWorldLeave() { last = null; }
    @Override protected void onTick() {
        if (!game.inWorld()) return;
        boolean r = game.raining();
        if (last != null && last != r && (r ? rainStart.get() : rainStop.get())) game.message(r ? "It started raining" : "The rain stopped");
        last = r;
    }
}
