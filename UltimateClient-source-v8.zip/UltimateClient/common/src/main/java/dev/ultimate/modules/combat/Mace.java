package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Switches to a mace from the hotbar when you are falling toward something you aim at, and back when you land. */
public final class Mace extends Module {
    public final Setting.Num minFall = add(Setting.Num.dbl("min-fall", "Fall distance (blocks) before switching", 1.5, 0.5, 20.0, 0.5));
    public final Setting.Bool needTarget = add(new Setting.Bool("need-target", "Only when aiming at an entity", true));
    private final Game game; private int prev = -1;
    public Mace(Game g) { super("mace", "Mace", "Equips a mace while you fall onto a target.", Category.COMBAT); game = g; }
    @Override protected void onDisable() { back(); }
    @Override protected void onWorldLeave() { prev = -1; }
    private void back() { if (prev >= 0 && game.inWorld()) game.selectSlot(prev); prev = -1; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (game.self().onGround()) { back(); return; }
        if (prev >= 0 || game.fallDistance() < minFall.get() || (needTarget.get() && game.crosshairEntity() < 0)) return;
        int s = game.hotbarSlotOf(ItemKind.MACE); if (s < 0 || s == game.selectedSlot()) return;
        prev = game.selectedSlot(); game.selectSlot(s);
    }
}
