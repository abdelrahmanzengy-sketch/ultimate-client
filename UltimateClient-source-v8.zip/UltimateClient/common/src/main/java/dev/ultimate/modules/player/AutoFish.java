package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Reels in on a bite and recasts. Hold a fishing rod; cast the first time yourself or enable auto-cast. */
public final class AutoFish extends Module {
    public final Setting.Bool autoCast = add(new Setting.Bool("auto-cast", "Cast automatically when no bobber is out", true));
    public final Setting.Num recastDelay = add(Setting.Num.intg("recast-delay", "Ticks to wait after reeling before casting", 20, 5, 100));
    private final Game game; private long readyAt;
    public AutoFish(Game g) { super("auto-fish", "Auto Fish", "Fishes for you.", Category.PLAYER); game = g; }
    @Override protected void onEnable() { readyAt = 0; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.mainHand() != ItemKind.FISHING_ROD) return;
        long now = game.tick();
        if (game.fishBobberOut()) { if (game.fishBobberDipping()) { game.useItem(); readyAt = now + recastDelay.asInt(); } }
        else if (autoCast.get() && now >= readyAt) { game.useItem(); readyAt = now + recastDelay.asInt(); }
    }
}
