package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.*;

/** Feeds nearby farm animals with the matching food from your hotbar (cows, sheep, pigs, chickens), once per animal per cooldown. */
public final class AutoBreed extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Reach", 3.5, 1.0, 5.0, 0.1));
    public final Setting.Num cooldown = add(Setting.Num.intg("cooldown", "Ticks before feeding the same animal again (breeding cooldown is 6000)", 6000, 100, 24000));
    private final Game game; private final Map<Integer, Long> fed = new HashMap<>(); private int prev = -1;
    public AutoBreed(Game g) { super("auto-breed", "Auto Breed", "Feeds animals so they breed.", Category.WORLD); game = g; }
    @Override protected void onDisable() { restore(); fed.clear(); }
    @Override protected void onWorldLeave() { fed.clear(); prev = -1; }
    private void restore() { if (prev >= 0 && game.inWorld()) game.selectSlot(prev); prev = -1; }
    /** Item id fragments each animal accepts. */
    public static List<String> foods(String animal) {
        String a = animal.toLowerCase(Locale.ROOT);
        if (a.contains("cow") || a.contains("sheep")) return List.of("wheat");
        if (a.contains("pig")) return List.of("carrot", "potato", "beetroot");
        if (a.contains("chicken")) return List.of("seeds");
        return List.of();
    }
    private int foodSlot(List<String> frags) { for (int i = 0; i < 9; i++) { String id = game.itemId(i); if (id.isEmpty()) continue; for (String f : frags) if (id.contains(f) && !id.contains("poisonous") && !(f.equals("wheat") && id.contains("seeds"))) return i; } return -1; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        long now = game.tick(); fed.values().removeIf(t -> now - t > cooldown.asInt()); Vec3 eye = Angles.eye(game.self());
        for (EntityInfo e : game.entities()) {
            if (e.kind() != EntityInfo.Kind.PASSIVE || fed.containsKey(e.id()) || e.pos().add(0, e.height() / 2, 0).distanceTo(eye) > range.get()) continue;
            List<String> f = foods(e.name()); if (f.isEmpty()) continue; int slot = foodSlot(f); if (slot < 0) continue;
            if (prev < 0) prev = game.selectedSlot(); game.selectSlot(slot); game.lookAt(e.pos().add(0, e.height() / 2, 0));
            if (game.interactEntity(e.id())) fed.put(e.id(), now); return;
        }
        restore();
    }
}
