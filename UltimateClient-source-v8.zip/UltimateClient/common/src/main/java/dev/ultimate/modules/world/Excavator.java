package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/**
 * Clears a box between two corners, top layer first. Set the corners while standing at them with /uc excavator pos1 and pos2.
 * It only breaks blocks within reach; walk closer when it tells you something is out of range.
 */
public final class Excavator extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Reach", 4.5, 2.0, 6.0, 0.1));
    public final Setting.Num perTick = add(Setting.Num.intg("per-tick", "Break attempts per tick", 1, 1, 6));
    public final Setting.Num maxVolume = add(Setting.Num.intg("max-volume", "Refuse boxes larger than this many blocks", 20000, 100, 200000));
    private final Game game; private BlockPos p1, p2; private boolean warned;
    public Excavator(Game g) { super("excavator", "Excavator", "Digs out a box you define (pos1/pos2).", Category.WORLD); game = g; }
    public BlockPos pos1() { return p1; } public BlockPos pos2() { return p2; }
    public String setPos(int which, boolean clear) {
        if (clear) { p1 = p2 = null; return "Excavation area cleared."; }
        if (!game.inWorld()) return "Join a world first.";
        Vec3 p = game.self().pos(); BlockPos b = new BlockPos((int) Math.floor(p.x()), (int) Math.floor(p.y()), (int) Math.floor(p.z()));
        if (which == 1) p1 = b; else p2 = b; warned = false; return "pos" + which + " set to " + b.x() + " " + b.y() + " " + b.z();
    }
    public long volume() { return p1 == null || p2 == null ? 0 : (long) (Math.abs(p1.x() - p2.x()) + 1) * (Math.abs(p1.y() - p2.y()) + 1) * (Math.abs(p1.z() - p2.z()) + 1); }
    @Override protected void onEnable() { warned = false; if (p1 == null || p2 == null) { game.message("Excavator: set the area first (/uc excavator pos1, pos2)."); } else if (volume() > maxVolume.asInt()) game.message("Excavator: area too large (" + volume() + " blocks)."); }
    @Override protected void onWorldLeave() { p1 = p2 = null; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem() || p1 == null || p2 == null || volume() > maxVolume.asInt()) return;
        Vec3 eye = Angles.eye(game.self());
        int x0 = Math.min(p1.x(), p2.x()), x1 = Math.max(p1.x(), p2.x()), y0 = Math.min(p1.y(), p2.y()), y1 = Math.max(p1.y(), p2.y()), z0 = Math.min(p1.z(), p2.z()), z1 = Math.max(p1.z(), p2.z());
        int done = 0; boolean remaining = false, outOfReach = false;
        for (int y = y1; y >= y0 && done < perTick.asInt(); y--) for (int x = x0; x <= x1 && done < perTick.asInt(); x++) for (int z = z0; z <= z1 && done < perTick.asInt(); z++) {
            if (!game.isLoaded(x, z) || game.isAir(x, y, z) || !game.isBreakable(x, y, z) || game.isLiquid(x, y, z)) continue;
            remaining = true;
            if (new Vec3(x + .5, y + .5, z + .5).distanceTo(eye) > range.get()) { outOfReach = true; continue; }
            game.lookAt(new Vec3(x + .5, y + .5, z + .5)); if (game.breakBlock(new BlockPos(x, y, z))) done++;
        }
        if (done == 0 && remaining && outOfReach && !warned) { warned = true; game.message("Excavator: blocks left out of reach, move closer."); }
        if (!remaining && !warned) { warned = true; game.message("Excavator: area is clear."); }
    }
}
