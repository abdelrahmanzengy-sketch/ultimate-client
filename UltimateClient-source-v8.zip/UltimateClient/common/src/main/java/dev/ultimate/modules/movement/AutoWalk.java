package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

public final class AutoWalk extends Module {
    public final Setting.Bool stopOnSneak = add(new Setting.Bool("stop-on-sneak", "Stop walking while sneaking", true));
    private final Game game;
    public AutoWalk(Game g) { super("auto-walk", "Auto Walk", "Walks forward without holding the key.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() { if (game.inWorld() && !game.selfDead()) game.setForwardInput(!(stopOnSneak.get() && game.sneaking())); }
    @Override protected void onDisable() { if (game.inWorld()) game.setForwardInput(false); }
}
