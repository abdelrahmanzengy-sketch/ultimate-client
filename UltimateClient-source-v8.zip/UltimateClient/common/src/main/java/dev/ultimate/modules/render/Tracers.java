package dev.ultimate.modules.render;

import dev.ultimate.core.FriendManager;
import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Lines from your crosshair to other players (and optionally mobs). */
public final class Tracers extends EspModule {
    public final Setting.Color friendColor = add(new Setting.Color("friend-color", "Colour for friends", 0xFF30FF60));
    public final Setting.Bool mobs = add(new Setting.Bool("mobs", "Also draw lines to hostile mobs", false));
    private final FriendManager friends;
    public Tracers(Game g, FriendManager f) { super("tracers", "Tracers", "Draws lines to players.", g); friends = f; color.set(0xFFFFFFFF); }
    @Override protected void draw(RenderQueue q) {
        Vec3 from = Angles.eye(game.self()).add(Angles.look(game.yaw(), game.pitch()).scale(0.6));
        for (EntityInfo e : game.entities()) {
            boolean p = e.kind() == EntityInfo.Kind.PLAYER, m = mobs.get() && e.kind() == EntityInfo.Kind.HOSTILE;
            if (!(p || m) || !within(e.pos())) continue;
            line(q, from, e.pos().add(0, e.height() / 2, 0), p && friends.isFriend(e.name()) ? withOpacity(friendColor.get()) : col());
        }
    }
}
