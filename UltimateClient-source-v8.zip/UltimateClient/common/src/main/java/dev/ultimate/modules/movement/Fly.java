package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Creative-style flight by driving the player's velocity. Servers normally disallow this; use where permitted. */
public final class Fly extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("mode", "Hover holds height, Glide sinks slowly", "Hover", "Hover", "Glide"));
    public final Setting.Num speed = add(Setting.Num.dbl("speed", "Horizontal speed (blocks/tick)", 0.5, 0.05, 3.0, 0.05));
    public final Setting.Num verticalSpeed = add(Setting.Num.dbl("vertical-speed", "Vertical speed (blocks/tick)", 0.4, 0.05, 3.0, 0.05));
    private final Game game;
    public Fly(Game game) { super("fly", "Fly", "Allows free flight.", Category.MOVEMENT); this.game = game; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        double vy = game.jumping() ? verticalSpeed.get() : game.sneaking() ? -verticalSpeed.get() : (mode.get().equals("Glide") ? -0.03 : 0.0);
        double vx = 0, vz = 0;
        if (game.movingForward()) {
            double yaw = Math.toRadians(game.yaw());
            vx = -Math.sin(yaw) * speed.get(); vz = Math.cos(yaw) * speed.get();
        }
        game.setVelocity(new Vec3(vx, vy, vz));
    }
    @Override protected void onDisable() { if (game.inWorld()) game.setVelocity(Vec3.ZERO); }
}
