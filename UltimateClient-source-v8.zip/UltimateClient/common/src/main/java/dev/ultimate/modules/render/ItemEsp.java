package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.game.*;

/** Boxes around dropped items. */
public final class ItemEsp extends EspModule {
    public ItemEsp(Game g) { super("item-esp", "Item ESP", "Highlights dropped items.", g); color.set(0xFFFFD030); }
    @Override protected void draw(RenderQueue q) {
        for (EntityInfo e : game.entities()) if (e.kind() == EntityInfo.Kind.ITEM && within(e.pos())) { entityBox(q, e, col()); label(q, e.pos().add(0, 0.6, 0), e.name()); }
    }
}
