package dev.ultimate.modules.client;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;

/**
 * Chooses the client-brand string sent to servers during login ("vanilla", "fabric" or a custom value).
 * This only changes one string. It does NOT make the client undetectable: servers can still spot a modified client
 * by its behaviour, packets, and other signals. A mixin (see the version projects) reads {@link BrandState}.
 */
public final class ClientBrand extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("mode", "Brand string to send", "Vanilla", "Vanilla", "Fabric", "Custom"));
    public final Setting.Str custom = add(new Setting.Str("custom", "Brand used in Custom mode (printable ASCII, max 32)", "vanilla", 32));

    public ClientBrand() {
        super("client-brand", "Client Brand", "Changes the brand string sent to servers. Not a stealth feature.", Category.CLIENT);
        mode.onChange(v -> refresh()); custom.onChange(v -> refresh());
    }
    public String resolved() {
        return switch (mode.get()) { case "Fabric" -> "fabric"; case "Custom" -> BrandState.sanitize(custom.get()); default -> "vanilla"; };
    }
    private void refresh() { if (isEnabled()) BrandState.set(resolved()); }
    @Override protected void onEnable() { BrandState.set(resolved()); }
    @Override protected void onDisable() { BrandState.set(null); }
}
