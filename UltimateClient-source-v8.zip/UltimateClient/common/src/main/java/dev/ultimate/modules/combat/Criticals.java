package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/**
 * Crit assist: when your attack is charged and you aim at an entity on the ground, it presses jump once so you come down
 * on the target and your next hit is a normal falling critical. It only uses the jump key; no packets are changed.
 */
public final class Criticals extends Module {
    public final Setting.Num minCharge = add(Setting.Num.dbl("min-charge", "Attack charge needed before hopping (0-1)", 0.9, 0.5, 1.0, 0.05));
    public final Setting.Bool entitiesOnly = add(new Setting.Bool("living-only", "Only hop when aiming at a player or mob", true));
    private final Game game; private boolean pressed;
    public Criticals(Game g) { super("criticals", "Criticals", "Hops so your hit lands as a falling critical.", Category.COMBAT); game = g; }
    @Override protected void onEnable() { pressed = false; }
    @Override protected void onDisable() { if (pressed && game.inWorld()) game.setJumpInput(false); pressed = false; }
    @Override protected void onWorldLeave() { pressed = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (pressed) { game.setJumpInput(false); pressed = false; return; }
        if (game.crosshairEntity() < 0 && entitiesOnly.get()) return;
        if (!game.self().onGround() || game.sneaking() || game.inWater() || game.onClimbable() || game.screenOpen() || game.attackCooldown() < minCharge.asFloat()) return;
        game.setJumpInput(true); pressed = true;
    }
}
