package dev.ultimate.modules.render;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Sets the field of view to your value while enabled and puts the old value back when disabled. */
public final class CustomFov extends Module {
    public final Setting.Num fov = add(Setting.Num.intg("fov", "Field of view (vanilla limits 30-110)", 100, 30, 110));
    private final Game game; private int original = -1;
    public CustomFov(Game g) { super("custom-fov", "Custom FOV", "Sets your field of view.", Category.RENDER); game = g; }
    @Override protected void onEnable() { original = game.inWorld() ? game.fov() : -1; }
    @Override protected void onDisable() { if (original >= 0 && game.inWorld()) game.setFov(original); original = -1; }
    @Override protected void onWorldLeave() { original = -1; }
    @Override protected void onTick() {
        if (!game.inWorld()) return;
        if (original < 0) original = game.fov();
        if (game.fov() != fov.asInt()) game.setFov(fov.asInt());
    }
}
