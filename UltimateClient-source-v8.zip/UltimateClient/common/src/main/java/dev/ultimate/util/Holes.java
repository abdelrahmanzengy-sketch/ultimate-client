package dev.ultimate.util;

import dev.ultimate.game.Game;

/** Classifies 1x1 holes (standing space with solid floor and four solid sides). */
public final class Holes {
    private Holes() {}
    public static final int NONE = 0, MIXED = 1, SAFE = 2;
    private static final int[][] SIDES = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

    /** @param y the block the player's feet occupy. SAFE = all four sides obsidian/bedrock. Unloaded chunks give NONE. */
    public static int classify(Game g, int x, int y, int z) {
        if (!g.isLoaded(x, z) || g.isSolid(x, y, z) || g.isSolid(x, y + 1, z) || !g.isSolid(x, y - 1, z)) return NONE;
        int hard = 0;
        for (int[] o : SIDES) {
            int sx = x + o[0], sz = z + o[1];
            if (!g.isLoaded(sx, sz) || !g.isSolid(sx, y, sz)) return NONE;
            if (g.isCrystalBase(sx, y, sz)) hard++;
        }
        return hard == 4 ? SAFE : MIXED;
    }
}
