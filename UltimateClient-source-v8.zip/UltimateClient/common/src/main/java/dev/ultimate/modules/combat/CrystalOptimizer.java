package dev.ultimate.modules.combat;

import dev.ultimate.combat.Explosion;
import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Hits an end crystal the moment it is under your crosshair (no attack-cooldown wait) when it is safe for you. */
public final class CrystalOptimizer extends Module {
    public final Setting.Num maxSelf = add(Setting.Num.dbl("max-self-damage", "Do not hit crystals that would deal more than this to you", 10.0, 0.0, 36.0, 0.5));
    public final Setting.Num minGap = add(Setting.Num.intg("min-gap", "Minimum ticks between hits", 0, 0, 5));
    public final Setting.Bool needCrystalInHand = add(new Setting.Bool("only-with-crystals", "Only active while holding crystals", false));
    private final Game game; private long last = -1000;
    public CrystalOptimizer(Game g) { super("crystal-optimizer", "Crystal Optimizer", "Instantly hits the crystal you aim at.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (needCrystalInHand.get() && game.mainHand() != ItemKind.END_CRYSTAL && game.offhand() != ItemKind.END_CRYSTAL) return;
        int cid = game.crosshairEntity(); if (cid < 0 || game.tick() - last < minGap.asInt()) return;
        EntityInfo me = game.self();
        for (EntityInfo e : game.entities()) if (e.id() == cid && e.kind() == EntityInfo.Kind.CRYSTAL) {
            float d = Explosion.damage(Explosion.Kind.CRYSTAL, e.pos(), me, me.pos(), game.difficulty(), (x, y, z) -> game.isSolid(x, y, z));
            if (d <= maxSelf.get() && d < me.effectiveHealth() - 0.5f && game.attack(cid)) last = game.tick();
            return;
        }
    }
}
