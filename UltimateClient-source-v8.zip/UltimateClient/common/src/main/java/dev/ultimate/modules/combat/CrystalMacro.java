package dev.ultimate.modules.combat;

import dev.ultimate.combat.Explosion;
import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/**
 * Crosshair-driven crystal macro: hits the crystal you are aiming at and places a crystal on the obsidian/bedrock
 * you are aiming at. You do the aiming; nothing is rotated. Skips actions that would hurt you more than allowed.
 */
public final class CrystalMacro extends Module {
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between actions", 1, 0, 10));
    public final Setting.Bool place = add(new Setting.Bool("place", "Place crystals on the aimed base", true));
    public final Setting.Bool breakCrystals = add(new Setting.Bool("break", "Hit the aimed crystal", true));
    public final Setting.Bool swap = add(new Setting.Bool("swap", "Switch to crystals in the hotbar when needed", true));
    public final Setting.Num maxSelf = add(Setting.Num.dbl("max-self-damage", "Skip actions that would deal more than this to you", 8.0, 0.0, 36.0, 0.5));
    private final Game game; private long last = -1000;
    public CrystalMacro(Game g) { super("crystal-macro", "Crystal Macro", "Places and breaks crystals where you aim.", Category.COMBAT); game = g; }

    private float selfDamage(EntityInfo me, Vec3 at) { return Explosion.damage(Explosion.Kind.CRYSTAL, at, me, me.pos(), game.difficulty(), (x, y, z) -> game.isSolid(x, y, z)); }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        long now = game.tick(); if (now - last < delay.asInt()) return;
        EntityInfo me = game.self();
        int cid = game.crosshairEntity();
        if (breakCrystals.get() && cid >= 0) {
            for (EntityInfo e : game.entities()) if (e.id() == cid && e.kind() == EntityInfo.Kind.CRYSTAL) {
                if (selfDamage(me, e.pos()) <= maxSelf.get() && selfDamage(me, e.pos()) < me.effectiveHealth() - 0.5f) { game.attack(cid); last = now; }
                return;
            }
        }
        BlockPos t = game.targetBlock();
        if (!place.get() || t == null || !game.isCrystalBase(t.x(), t.y(), t.z()) || !game.canPlaceCrystal(t)) return;
        Vec3 center = new Vec3(t.x() + 0.5, t.y() + 1.0, t.z() + 0.5);
        float self = selfDamage(me, center); if (self > maxSelf.get() || self >= me.effectiveHealth() - 0.5f) return;
        if (game.mainHand() != ItemKind.END_CRYSTAL && game.offhand() != ItemKind.END_CRYSTAL) {
            int slot = game.hotbarSlotOf(ItemKind.END_CRYSTAL); if (!swap.get() || slot < 0) return; game.selectSlot(slot);
        }
        if (game.placeCrystal(t)) last = now;
    }
}
