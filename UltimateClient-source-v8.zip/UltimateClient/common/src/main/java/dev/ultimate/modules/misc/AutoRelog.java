package dev.ultimate.modules.misc;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.Locale;

/** Reconnects when the disconnect message contains one of your words (restarts, timeouts...), waiting longer after each failed try. If the message cannot be read it reconnects anyway. */
public final class AutoRelog extends Module {
    public final Setting.Str reasons = add(new Setting.Str("reasons", "Reconnect when the message contains any of these (comma separated)", "restart,timed out,connection,lost,closed", 200));
    public final Setting.Num baseSeconds = add(Setting.Num.intg("base-seconds", "First wait; doubles after each failed try", 5, 1, 60));
    public final Setting.Num attempts = add(Setting.Num.intg("max-attempts", "Give up after this many tries", 6, 1, 20));
    private final Game game; private int wait = -1, tries;
    public AutoRelog(Game g) { super("auto-relog", "Auto Relog", "Rejoins after matching disconnects with growing waits.", Category.MISC); game = g; }
    @Override protected void onEnable() { wait = -1; tries = 0; }
    public static boolean matches(String reason, String csv) {
        String r = reason == null ? "" : reason.toLowerCase(Locale.ROOT);
        for (String p : csv.split(",")) { String t = p.trim().toLowerCase(Locale.ROOT); if (!t.isEmpty() && r.contains(t)) return true; }
        return false;
    }
    @Override protected void onTick() {
        if (game.inWorld()) { wait = -1; tries = 0; return; }
        if (!game.disconnectScreenShown() || tries >= attempts.asInt() || !(game.disconnectReason().isBlank() || matches(game.disconnectReason(), reasons.get()))) { wait = -1; return; }
        if (wait < 0) wait = baseSeconds.asInt() * 20 * (1 << Math.min(tries, 6));
        if (--wait <= 0) { tries++; wait = -1; game.reconnect(); }
    }
}
