package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Keeps forward/jump/sneak working while an inventory or container screen is open (not chat, signs or text boxes). */
public final class GuiMove extends Module {
    public final Setting.Bool jump = add(new Setting.Bool("jump", "Also allow jumping", true));
    public final Setting.Bool sneak = add(new Setting.Bool("sneak", "Also allow sneaking", true));
    private final Game game; private boolean held;
    public GuiMove(Game g) { super("gui-move", "GUI Move", "Move while your inventory is open.", Category.MOVEMENT); game = g; }
    @Override protected void onDisable() { release(); }
    @Override protected void onWorldLeave() { held = false; }
    private void release() { if (held && game.inWorld()) { game.setForwardInput(false); game.setJumpInput(false); game.setSneakInput(false); } held = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (!game.inventoryScreenOpen()) { release(); return; }
        game.setForwardInput(game.keyDown(Keys87.W)); game.setJumpInput(jump.get() && game.keyDown(Keys87.SPACE)); game.setSneakInput(sneak.get() && game.keyDown(Keys87.LSHIFT)); held = true;
    }
    /** GLFW codes. */
    private static final class Keys87 { static final int W = 87, SPACE = 32, LSHIFT = 340; }
}
