package dev.ultimate.modules.render;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/**
 * Shared base for visual modules. Every ESP has colour, opacity, distance limit, line thickness, style, labels and a
 * per-frame shape cap (the performance control). Subclasses describe shapes in {@link #draw}; nothing here touches Minecraft.
 */
public abstract class EspModule extends Module {
    public final Setting.Color color = add(new Setting.Color("color", "Main colour", 0xFFFF3030));
    public final Setting.Num opacity = add(Setting.Num.dbl("opacity", "Opacity (0.05 - 1)", 0.6, 0.05, 1.0, 0.05));
    public final Setting.Num distance = add(Setting.Num.dbl("distance", "Maximum distance in blocks", 64.0, 4.0, 256.0, 4.0));
    public final Setting.Num thickness = add(Setting.Num.dbl("thickness", "Line thickness", 1.5, 0.5, 6.0, 0.5));
    public final Setting.Mode style = add(new Setting.Mode("style", "Render style", "Outline", "Outline", "Fill", "Both"));
    public final Setting.Bool labels = add(new Setting.Bool("labels", "Show text labels", true));
    public final Setting.Num maxDraw = add(Setting.Num.intg("max-draw", "Maximum shapes per frame (lower = faster)", 150, 10, 1000));
    protected final Game game;
    private int drawn;

    protected EspModule(String id, String name, String desc, Game g) { super(id, name, desc, Category.RENDER); game = g; }

    protected final int withOpacity(int rgb) { return ((int) Math.round(opacity.get() * 255) << 24) | (rgb & 0xFFFFFF); }
    protected final int col() { return withOpacity(color.get()); }
    protected final RenderQueue.Style styleOf() { return switch (style.get()) { case "Fill" -> RenderQueue.Style.FILL; case "Both" -> RenderQueue.Style.BOTH; default -> RenderQueue.Style.OUTLINE; }; }
    protected final boolean room() { return drawn < maxDraw.asInt(); }
    protected final boolean within(Vec3 p) { return p.distanceTo(game.self().pos()) <= distance.get(); }

    protected final void box(RenderQueue q, Vec3 min, Vec3 max, int argb) { if (room() && q.box(min, max, argb, styleOf(), thickness.asFloat())) drawn++; }
    protected final void line(RenderQueue q, Vec3 a, Vec3 b, int argb) { if (room() && q.line(a, b, argb, thickness.asFloat())) drawn++; }
    protected final void label(RenderQueue q, Vec3 at, String text) { if (labels.get() && room() && q.label(at, text, col() | 0xFF000000)) drawn++; }
    protected final void blockBox(RenderQueue q, BlockPos p, int argb) { box(q, new Vec3(p.x(), p.y(), p.z()), new Vec3(p.x() + 1, p.y() + 1, p.z() + 1), argb); }
    protected final void entityBox(RenderQueue q, EntityInfo e, int argb) { box(q, e.boxMin(), e.boxMax(), argb); }

    @Override protected final void onRender(RenderQueue q) {
        if (!game.inWorld() || game.selfDead()) return;
        drawn = 0; draw(q);
    }
    protected abstract void draw(RenderQueue q);
}
