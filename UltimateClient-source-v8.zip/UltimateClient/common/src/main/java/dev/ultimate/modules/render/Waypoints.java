package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.*;

/**
 * Named positions shown in the world. Stored in a setting ("name|x|y|z;..."), so they are saved with your profile.
 * Manage them with /uc wp add|del|list|go.
 */
public final class Waypoints extends EspModule {
    public record Waypoint(String name, int x, int y, int z) {}
    public final Setting.Str data = add(new Setting.Str("data", "Stored waypoints (edit with /uc wp)", "", 3000));
    public Waypoints(Game g) { super("waypoints", "Waypoints", "Shows saved positions in the world.", g); color.set(0xFF40FFD0); distance.set(512.0); }

    public List<Waypoint> list() {
        List<Waypoint> out = new ArrayList<>();
        for (String e : data.get().split(";")) {
            String[] p = e.split("\\|"); if (p.length != 4) continue;
            try { out.add(new Waypoint(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]))); } catch (NumberFormatException ignored) {}
        }
        return out;
    }
    private boolean store(List<Waypoint> l) {
        StringBuilder sb = new StringBuilder(); for (Waypoint w : l) sb.append(w.name()).append('|').append(w.x()).append('|').append(w.y()).append('|').append(w.z()).append(';');
        return data.set(sb.toString());
    }
    public static String cleanName(String n) { return n == null ? "" : n.replaceAll("[|;\\s]", "").trim(); }
    /** @return null on success, else an error message. */
    public String addHere(String name) {
        String n = cleanName(name); if (n.isEmpty()) return "Give the waypoint a name without spaces."; if (n.length() > 24) return "Name too long (24 max).";
        if (!game.inWorld()) return "Join a world first.";
        List<Waypoint> l = list(); for (Waypoint w : l) if (w.name().equalsIgnoreCase(n)) return "A waypoint called " + n + " already exists.";
        Vec3 p = game.self().pos(); l.add(new Waypoint(n, (int) Math.floor(p.x()), (int) Math.floor(p.y()), (int) Math.floor(p.z())));
        return store(l) ? null : "Waypoint storage is full; delete some.";
    }
    public boolean remove(String name) { List<Waypoint> l = list(); boolean r = l.removeIf(w -> w.name().equalsIgnoreCase(name)); if (r) store(l); return r; }
    public Waypoint find(String name) { for (Waypoint w : list()) if (w.name().equalsIgnoreCase(name)) return w; return null; }

    @Override protected void draw(RenderQueue q) {
        for (Waypoint w : list()) {
            Vec3 c = new Vec3(w.x() + 0.5, w.y() + 0.5, w.z() + 0.5); if (!within(c)) continue;
            box(q, new Vec3(w.x(), w.y(), w.z()), new Vec3(w.x() + 1, w.y() + 1, w.z() + 1), col());
            label(q, c.add(0, 1, 0), w.name() + " " + Math.round(c.distanceTo(game.self().pos())) + "m");
        }
    }
}
