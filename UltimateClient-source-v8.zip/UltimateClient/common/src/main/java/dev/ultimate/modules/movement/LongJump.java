package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Boosts your horizontal speed once at take-off when jumping forward. */
public final class LongJump extends Module {
    public final Setting.Num boost = add(Setting.Num.dbl("boost", "Horizontal speed multiplier at take-off", 1.6, 1.0, 3.0, 0.05));
    private final Game game; private boolean wasGround = true;
    public LongJump(Game g) { super("long-jump", "Long Jump", "Jump farther.", Category.MOVEMENT); game = g; }
    @Override protected void onEnable() { wasGround = true; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        EntityInfo me = game.self();
        if (wasGround && !me.onGround() && me.velocity().y() > 0 && game.movingForward() && !game.inWater()) {
            Vec3 v = me.velocity(); game.setVelocity(new Vec3(v.x() * boost.get(), v.y(), v.z() * boost.get()));
        }
        wasGround = me.onGround();
    }
}
