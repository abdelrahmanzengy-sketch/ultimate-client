package dev.ultimate.util;

import dev.ultimate.game.*;
import java.util.List;

/** Shared block-placement loop used by Surround-style modules. */
public final class Placer {
    private Placer() {}
    public static final int NO_ITEM = -1;

    /** Places the item on each air target (up to limit). @return blocks placed, or NO_ITEM if the hotbar lacks the item. */
    public static int place(Game g, List<BlockPos> targets, ItemKind item, int limit, boolean rotate) {
        int slot = -1, placed = 0, prev = g.selectedSlot();
        for (BlockPos t : targets) {
            if (placed >= limit) break;
            if (!g.isLoaded(t.x(), t.z()) || !g.isAir(t.x(), t.y(), t.z())) continue;
            if (slot < 0) { slot = g.hotbarSlotOf(item); if (slot < 0) return NO_ITEM; g.selectSlot(slot); }
            if (rotate) g.lookAt(t.center());
            if (g.placeBlock(t)) placed++;
        }
        if (slot >= 0) g.selectSlot(prev);
        return placed;
    }

    /** Like {@link #place} but tries obsidian first and then any cheap filler block (cobblestone, stone, dirt, netherrack...). */
    public static int placeAny(Game g, List<BlockPos> targets, int limit, boolean rotate) {
        int n = place(g, targets, ItemKind.OBSIDIAN, limit, rotate);
        return n == NO_ITEM ? place(g, targets, ItemKind.FILLER_BLOCK, limit, rotate) : n;
    }

    public static EntityInfo nearestEnemy(Game g, dev.ultimate.core.FriendManager friends, double range) {
        EntityInfo me = g.self(), best = null;
        for (EntityInfo e : g.entities())
            if (e.kind() == EntityInfo.Kind.PLAYER && e.health() > 0 && !friends.isFriend(e.name())) {
                double d = e.pos().distanceTo(me.pos());
                if (d <= range && (best == null || d < best.pos().distanceTo(me.pos()))) best = e;
            }
        return best;
    }
    public static int fx(EntityInfo e) { return (int) Math.floor(e.pos().x()); }
    public static int fy(EntityInfo e) { return (int) Math.floor(e.pos().y()); }
    public static int fz(EntityInfo e) { return (int) Math.floor(e.pos().z()); }
}
