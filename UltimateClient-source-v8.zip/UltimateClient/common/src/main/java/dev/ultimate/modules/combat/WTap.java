package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** After you land a hit, stops sprinting for a moment and resumes, so the next hit deals full knockback. */
public final class WTap extends Module {
    public final Setting.Num release = add(Setting.Num.intg("release-ticks", "Ticks to stay un-sprinted", 2, 1, 6));
    private final Game game; private float prev = 1f; private int hold;
    public WTap(Game g) { super("w-tap", "W-Tap", "Resets sprint after each hit.", Category.COMBAT); game = g; }
    @Override protected void onEnable() { prev = 1f; hold = 0; }
    @Override protected void onDisable() { hold = 0; }
    @Override protected void onWorldLeave() { hold = 0; prev = 1f; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        float c = game.attackCooldown(); boolean swung = prev > 0.8f && c < 0.3f; prev = c;
        if (swung && game.movingForward()) hold = release.asInt();
        if (hold > 0) { hold--; game.setSprinting(false); if (hold == 0 && game.movingForward() && !game.sneaking()) game.setSprinting(true); }
    }
}
