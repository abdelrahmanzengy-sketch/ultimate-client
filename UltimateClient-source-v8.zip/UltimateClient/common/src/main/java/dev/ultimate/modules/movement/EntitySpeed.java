package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Drives whatever you ride (horse, pig, strider, minecart...) at a fixed horizontal speed while you hold forward. */
public final class EntitySpeed extends Module {
    public final Setting.Num speed = add(Setting.Num.dbl("speed", "Horizontal speed (blocks/tick)", 0.5, 0.1, 3.0, 0.1));
    private final Game game;
    public EntitySpeed(Game g) { super("entity-speed", "Entity Speed", "Speeds up the mount you are riding.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.riding() || !game.movingForward()) return;
        double yaw = Math.toRadians(game.yaw()); Vec3 v = game.vehicleVelocity();
        game.setVehicleVelocity(new Vec3(-Math.sin(yaw) * speed.get(), v.y(), Math.cos(yaw) * speed.get()));
    }
}
