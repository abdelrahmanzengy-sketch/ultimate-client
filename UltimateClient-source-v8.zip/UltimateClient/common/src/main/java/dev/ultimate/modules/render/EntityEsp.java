package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Boxes around mobs (hostile and/or passive) through walls. Players have their own Player ESP. */
public final class EntityEsp extends EspModule {
    public final Setting.Bool hostile = add(new Setting.Bool("hostile", "Show hostile mobs", true));
    public final Setting.Bool passive = add(new Setting.Bool("passive", "Show passive mobs", false));
    public EntityEsp(Game g) { super("entity-esp", "Entity ESP", "Highlights mobs.", g); }
    @Override protected void draw(RenderQueue q) {
        for (EntityInfo e : game.entities()) {
            boolean ok = e.kind() == EntityInfo.Kind.HOSTILE && hostile.get() || e.kind() == EntityInfo.Kind.PASSIVE && passive.get();
            if (!ok || !within(e.pos())) continue;
            entityBox(q, e, col()); label(q, e.pos().add(0, e.height() + 0.3, 0), e.name());
        }
    }
}
