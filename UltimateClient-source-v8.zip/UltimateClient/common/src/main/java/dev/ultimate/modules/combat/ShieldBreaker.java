package dev.ultimate.modules.combat;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;

/** Swaps to an axe and hits a player who is blocking with a shield, then restores your slot. */
public final class ShieldBreaker extends Module {
    public final Setting.Num minCooldown = add(Setting.Num.dbl("min-cooldown", "Attack once the weapon is this recharged", 0.9, 0.1, 1.0, 0.05));
    private final Game game; private final FriendManager friends;
    public ShieldBreaker(Game g, FriendManager f) { super("shield-breaker", "Shield Breaker", "Disables enemy shields with an axe.", Category.COMBAT); game = g; friends = f; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        int id = game.crosshairEntity(); if (id < 0 || !game.isBlocking(id)) return;
        for (EntityInfo e : game.entities()) {
            if (e.id() != id) continue;
            if (e.kind() != EntityInfo.Kind.PLAYER || friends.isFriend(e.name())) return;
            int slot = game.mainHand() == ItemKind.AXE ? game.selectedSlot() : game.hotbarSlotOf(ItemKind.AXE);
            if (slot < 0 || game.attackCooldown() < minCooldown.asFloat()) return;
            int prev = game.selectedSlot(); game.selectSlot(slot); game.attack(id); game.selectSlot(prev); return;
        }
    }
}
