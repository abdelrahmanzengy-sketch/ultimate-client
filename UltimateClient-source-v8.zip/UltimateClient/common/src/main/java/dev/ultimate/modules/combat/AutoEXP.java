package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Throws experience bottles at your feet to repair worn armor (Mending) when no enemy is close. */
public final class AutoEXP extends Module {
    public final Setting.Num threshold = add(Setting.Num.dbl("threshold", "Throw while the most damaged armor piece is below this durability fraction", 0.9, 0.1, 1.0, 0.05));
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between throws", 2, 0, 20));
    public final Setting.Num enemyRange = add(Setting.Num.dbl("enemy-range", "Pause when a player is closer than this", 8.0, 0.0, 20.0, 0.5));
    private final Game game; private long last = -1000;

    public AutoEXP(Game g) { super("auto-exp", "Auto EXP", "Repairs armor with experience bottles when it is safe.", Category.COMBAT); game = g; }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        if (game.armorDurability() >= threshold.asFloat()) return;
        long now = game.tick(); if (now - last < delay.asInt()) return;
        int slot = game.hotbarSlotOf(ItemKind.EXP_BOTTLE); if (slot < 0) return;
        EntityInfo me = game.self();
        for (EntityInfo e : game.entities())
            if (e.kind() == EntityInfo.Kind.PLAYER && e.health() > 0 && e.pos().distanceTo(me.pos()) < enemyRange.get()) return;
        int prev = game.selectedSlot(); float yaw = game.yaw(), pitch = game.pitch();
        game.selectSlot(slot); game.setRotation(yaw, 90f); game.useItem();
        game.setRotation(yaw, pitch); game.selectSlot(prev);
        last = now;
    }
}
