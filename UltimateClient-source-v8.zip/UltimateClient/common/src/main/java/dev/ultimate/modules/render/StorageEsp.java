package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.Locale;

/** Boxes around storage blocks (chests, barrels, shulker boxes, hoppers, furnaces...). */
public final class StorageEsp extends EspModule {
    public final Setting.Str types = add(new Setting.Str("types", "Block id fragments to show, comma separated", "chest,barrel,shulker_box,hopper,furnace,dispenser,dropper", 300));
    public StorageEsp(Game g) { super("storage-esp", "Storage ESP", "Highlights chests and other storage.", g); color.set(0xFFFFA030); }
    @Override protected void draw(RenderQueue q) {
        String[] want = types.get().toLowerCase(Locale.ROOT).split(",");
        for (BlockEntry b : game.blockEntities()) {
            if (!within(b.pos().center())) continue;
            String id = b.id().toLowerCase(Locale.ROOT); boolean ok = false;
            for (String w : want) if (!w.isBlank() && id.contains(w.trim())) { ok = true; break; }
            if (!ok) continue;
            blockBox(q, b.pos(), col()); label(q, b.pos().center().add(0, 0.8, 0), id.substring(id.indexOf(':') + 1));
        }
    }
}
