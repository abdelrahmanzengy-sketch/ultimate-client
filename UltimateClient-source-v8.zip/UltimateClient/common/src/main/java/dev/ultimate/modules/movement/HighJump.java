package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

public final class HighJump extends Module {
    public final Setting.Num power = add(Setting.Num.dbl("power", "Jump velocity (vanilla is 0.42)", 0.8, 0.42, 3.0, 0.05));
    private final Game game;
    public HighJump(Game g) { super("high-jump", "High Jump", "Jumps higher.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.jumping() || !game.self().onGround()) return;
        Vec3 v = game.self().velocity(); game.setVelocity(new Vec3(v.x(), power.get(), v.z()));
    }
}
