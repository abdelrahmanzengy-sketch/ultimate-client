package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Equips better armor found in the inventory, one swap per delay, never while you are using an item. */
public final class AutoArmor extends Module {
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between swaps", 3, 0, 20));
    public final Setting.Bool head = add(new Setting.Bool("head", "Manage helmets", true));
    public final Setting.Bool chest = add(new Setting.Bool("chest", "Manage chestplates (never replaces an elytra)", true));
    public final Setting.Bool legs = add(new Setting.Bool("legs", "Manage leggings", true));
    public final Setting.Bool feet = add(new Setting.Bool("feet", "Manage boots", true));
    private final Game game; private long last = -1000;

    public AutoArmor(Game g) { super("auto-armor", "Auto Armor", "Wears the best armor in your inventory.", Category.COMBAT); game = g; }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        long now = game.tick(); if (now - last < delay.asInt()) return;
        for (int idx = 3; idx >= 0; idx--) {
            boolean on = switch (idx) { case 3 -> head.get(); case 2 -> chest.get() && game.chest() != ItemKind.ELYTRA; case 1 -> legs.get(); default -> feet.get(); };
            if (!on) continue;
            int slot = game.betterArmorSlot(idx);
            if (slot >= 0) { game.equipArmor(slot, idx); last = now; return; }
        }
    }
}
