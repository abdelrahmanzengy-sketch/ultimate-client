package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** One-shot: swaps your chest slot between elytra and a chestplate, then turns itself off. */
public final class ChestSwap extends Module {
    public final Setting.Bool notify = add(new Setting.Bool("notify", "Tell me in chat what was swapped", true));
    private final Game game;
    public ChestSwap(Game g) { super("chest-swap", "Chest Swap", "Swap between elytra and chestplate.", Category.PLAYER); game = g; }
    @Override protected void onEnable() {
        if (!game.inWorld() || game.selfDead()) { setEnabled(false); return; }
        ItemKind want = game.chest() == ItemKind.ELYTRA ? ItemKind.CHESTPLATE : ItemKind.ELYTRA;
        int slot = game.hotbarSlotOf(want); if (slot < 0) slot = game.mainInvSlotOf(want);
        if (slot < 0) game.message("Chest Swap: no " + (want == ItemKind.ELYTRA ? "elytra" : "chestplate") + " in inventory");
        else { game.swapWithChest(slot); if (notify.get()) game.message("Chest Swap: now wearing " + (want == ItemKind.ELYTRA ? "elytra" : "chestplate")); }
        setEnabled(false);
    }
}
