package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendGuardState;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;

/** Cancels your own attacks on players in your friend list (the attack mixin reads {@link FriendGuardState}). */
public final class FriendGuard extends Module {
    public final Setting.Bool sneakOverride = add(new Setting.Bool("sneak-override", "Hold sneak to hit a friend anyway", true));
    private final FriendManager friends;
    public FriendGuard(FriendManager f) { super("friend-guard", "Friend Guard", "Stops you from hitting friends.", Category.COMBAT); friends = f; }
    @Override protected void onEnable() { FriendGuardState.set(friends, true, sneakOverride.get()); }
    @Override protected void onTick() { FriendGuardState.set(friends, true, sneakOverride.get()); }
    @Override protected void onDisable() { FriendGuardState.set(null, false, false); }
}
