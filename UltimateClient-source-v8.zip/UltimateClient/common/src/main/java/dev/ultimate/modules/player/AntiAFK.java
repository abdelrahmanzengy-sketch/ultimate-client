package dev.ultimate.modules.player;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Turns the camera slightly every few seconds so idle-kick timers reset. */
public final class AntiAFK extends Module {
    public final Setting.Num interval = add(Setting.Num.intg("interval", "Ticks between look changes", 400, 20, 2400));
    private final Game game; private int n; private boolean flip;
    public AntiAFK(Game g) { super("anti-afk", "Anti AFK", "Periodically nudges the camera.", Category.PLAYER); game = g; }
    @Override protected void onEnable() { n = 0; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || ++n < interval.asInt()) return;
        n = 0; flip = !flip; double yaw = Math.toRadians(game.yaw() + (flip ? 15 : -15)); Vec3 p = game.self().pos();
        game.lookAt(new Vec3(p.x() - Math.sin(yaw) * 5, p.y() + 1.62, p.z() + Math.cos(yaw) * 5));
    }
}
