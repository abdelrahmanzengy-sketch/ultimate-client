package dev.ultimate.modules.misc;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;

/** Scans the area around you in small slices (cheap on phones) and tells you once about blocks whose id matches. */
public final class BlockNotifier extends Module {
    public final Setting.Str blocks = add(new Setting.Str("blocks", "Comma-separated id fragments, e.g. diamond_ore,ancient_debris,spawner", "diamond_ore,ancient_debris", 128));
    public final Setting.Num range = add(Setting.Num.intg("range", "Scan radius", 16, 4, 32));
    public final Setting.Num perTick = add(Setting.Num.intg("per-tick", "Positions checked per tick (lower = lighter)", 300, 50, 2000));
    private final Game game; private int cursor, side, bx, by, bz; private boolean active;
    private final java.util.LinkedHashSet<Long> told = new java.util.LinkedHashSet<>();
    private String[] needles = new String[0];
    public BlockNotifier(Game g) { super("block-notifier", "Block Notifier", "Announces valuable blocks nearby.", Category.MISC); game = g; blocks.onChange(v -> parse(v)); parse(blocks.get()); }
    private void parse(String v) {
        java.util.List<String> l = new java.util.ArrayList<>();
        for (String p : v.split(",")) { String t = p.trim(); if (!t.isEmpty()) l.add(t); }
        needles = l.toArray(new String[0]);
    }
    private void reset() { active = false; cursor = 0; told.clear(); }
    @Override protected void onEnable() { reset(); }
    @Override protected void onDisable() { reset(); }
    @Override protected void onWorldLeave() { reset(); }
    private static long key(int x, int y, int z) { return ((long) x & 0x3FFFFFF) << 38 | ((long) z & 0x3FFFFFF) << 12 | ((long) y & 0xFFF); }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || needles.length == 0) return;
        if (!active) {
            EntityInfo me = game.self(); bx = (int) Math.floor(me.pos().x()); by = (int) Math.floor(me.pos().y()); bz = (int) Math.floor(me.pos().z());
            side = range.asInt() * 2 + 1; cursor = 0; active = true;
        }
        int total = side * side * side, r = side / 2;
        for (int n = 0; n < perTick.asInt() && cursor < total; n++, cursor++) {
            int x = bx - r + cursor % side, y = by - r + (cursor / side) % side, z = bz - r + cursor / (side * side);
            if (!game.isLoaded(x, z)) continue;
            String id = game.blockId(x, y, z); if (id.isEmpty()) continue;
            for (String nd : needles) if (id.contains(nd)) {
                if (told.add(key(x, y, z))) { game.message("Found " + id.substring(id.indexOf(':') + 1) + " at " + x + " " + y + " " + z); if (told.size() > 256) { var it = told.iterator(); it.next(); it.remove(); } }
                break;
            }
        }
        if (cursor >= total) active = false;     // next tick starts a fresh sweep around the new position
    }
}
