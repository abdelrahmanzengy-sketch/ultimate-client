package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.BaritoneBridge;

/**
 * Control panel for the Baritone pathfinder (a separate mod you install). Enabling this applies the settings below to Baritone;
 * run Baritone itself with /uc baritone <command> (goto, mine, build, tunnel, farm, explore, follow, cancel ...).
 * If Baritone is not installed, enabling this reports it and turns itself off.
 */
public final class Baritone extends Module {
    public final Setting.Bool allowBreak = add(new Setting.Bool("allow-break", "Let Baritone break blocks", true));
    public final Setting.Bool allowPlace = add(new Setting.Bool("allow-place", "Let Baritone place blocks", true));
    public final Setting.Bool allowSprint = add(new Setting.Bool("allow-sprint", "Let Baritone sprint", true));
    public final Setting.Bool allowParkour = add(new Setting.Bool("allow-parkour", "Allow jumping gaps", false));
    public final Setting.Bool freeLook = add(new Setting.Bool("free-look", "Look around freely while Baritone walks", false));
    public final Setting.Bool chatControl = add(new Setting.Bool("chat-control", "Let Baritone react to # chat commands", false));
    private final Game game;
    public Baritone(Game g) {
        super("baritone", "Baritone", "Settings and control for the Baritone pathfinder.", Category.WORLD); game = g;
        for (Setting<?> s : settings()) s.onChange(v -> { if (isEnabled()) { String e = apply(); if (e != null) game.message("Baritone: " + e); } });
    }
    private String apply() {
        String[][] kv = {{"allowBreak", String.valueOf(allowBreak.get())}, {"allowPlace", String.valueOf(allowPlace.get())}, {"allowSprint", String.valueOf(allowSprint.get())},
                {"allowParkour", String.valueOf(allowParkour.get())}, {"freeLook", String.valueOf(freeLook.get())}, {"chatControl", String.valueOf(chatControl.get())}};
        for (String[] e : kv) { String err = BaritoneBridge.execute("set " + e[0] + " " + e[1]); if (err != null) return err; }
        return null;
    }
    private boolean pending, warned;
    @Override protected void onEnable() { pending = true; warned = false; }
    @Override protected void onWorldLeave() { pending = true; }
    @Override protected void onDisable() { pending = false; if (BaritoneBridge.available()) BaritoneBridge.execute("cancel"); }
    /** Pushes the settings as soon as Baritone is available; says once if it is not installed. */
    @Override protected void onTick() {
        if (!pending || !game.inWorld()) return;
        if (!BaritoneBridge.available()) { if (!warned) { warned = true; game.message("Baritone: not installed. Put the baritone-meteor (or baritone-api) jar in your mods folder."); } return; }
        String err = apply(); pending = false; if (err != null) game.message("Baritone: " + err);
    }
    /** Re-sends the settings (call after changing them while enabled). */
    public String reapply() { return isEnabled() ? apply() : "Enable the Baritone module first."; }
}
