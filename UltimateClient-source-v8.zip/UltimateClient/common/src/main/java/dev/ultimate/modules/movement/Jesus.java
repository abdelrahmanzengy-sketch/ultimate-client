package dev.ultimate.modules.movement;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;

/** Keeps you afloat at the surface of water or lava while moving. Sneak to sink. Client-side motion only. */
public final class Jesus extends Module {
    public final Setting.Num lift = add(Setting.Num.dbl("lift", "Upward speed at the surface (blocks/tick)", 0.1, 0.02, 0.4, 0.01));
    public final Setting.Bool lava = add(new Setting.Bool("lava", "Also float on lava (it still burns you)", false));
    private final Game game;
    public Jesus(Game g) { super("jesus", "Jesus", "Walk on liquids.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.sneaking()) return;
        EntityInfo me = game.self();
        int x = (int) Math.floor(me.pos().x()), y = (int) Math.floor(me.pos().y()), z = (int) Math.floor(me.pos().z());
        if (!game.isLoaded(x, z) || !game.isLiquid(x, y, z) || game.isLiquid(x, y + 1, z)) return;   // not at the surface
        if (!lava.get() && !game.inWater()) return;                                                  // lava is the only liquid that is not water
        game.setVelocity(new Vec3(me.velocity().x(), Math.max(me.velocity().y(), lift.get()), me.velocity().z()));
    }
}
