package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.ArrayList;
import java.util.List;

/** Marks floor tiles where mobs can spawn (solid floor, two free blocks above, block light at or below the level you set). */
public final class LightOverlay extends EspModule {
    public final Setting.Num level = add(Setting.Num.intg("max-light", "Mark tiles with block light at or below this", 0, 0, 7));
    public final Setting.Num radius = add(Setting.Num.intg("radius", "Search radius", 6, 2, 12));
    public final Setting.Num interval = add(Setting.Num.intg("interval", "Ticks between scans", 10, 2, 60));
    private final List<int[]> tiles = new ArrayList<>(); private int n;
    public LightOverlay(Game g) { super("light-overlay", "Light Overlay", "Shows where mobs can spawn.", g); color.set(0xFFFF3030); style.set("Fill"); labels.set(false); distance.set(16.0); }
    @Override protected void onDisable() { tiles.clear(); }
    @Override protected void onWorldLeave() { tiles.clear(); }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || n++ % interval.asInt() != 0) return;
        tiles.clear(); EntityInfo me = game.self(); int cx = (int) Math.floor(me.pos().x()), cy = (int) Math.floor(me.pos().y()), cz = (int) Math.floor(me.pos().z()), r = radius.asInt();
        for (int dx = -r; dx <= r; dx++) for (int dz = -r; dz <= r; dz++) {
            int x = cx + dx, z = cz + dz; if (!game.isLoaded(x, z)) continue;
            for (int y = cy - 3; y <= cy + 3; y++)
                if (game.isSolid(x, y - 1, z) && game.isAir(x, y, z) && game.isAir(x, y + 1, z) && !game.isLiquid(x, y, z) && game.lightLevel(x, y, z) <= level.asInt() && tiles.size() < maxDraw.asInt()) tiles.add(new int[]{x, y, z});
        }
    }
    @Override protected void draw(RenderQueue q) { for (int[] t : tiles) box(q, new Vec3(t[0], t[1], t[2]), new Vec3(t[0] + 1, t[1] + 0.03, t[2] + 1), col()); }
}
