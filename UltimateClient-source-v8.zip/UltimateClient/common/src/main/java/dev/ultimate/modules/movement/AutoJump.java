package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Jumps over one-block obstacles in front of you while you walk forward. */
public final class AutoJump extends Module {
    public final Setting.Num reach = add(Setting.Num.dbl("reach", "How far ahead to look (blocks)", 0.8, 0.4, 1.5, 0.1));
    private final Game game; private boolean pressed;
    public AutoJump(Game g) { super("auto-jump", "Auto Jump", "Hops over single blocks automatically.", Category.MOVEMENT); game = g; }
    @Override protected void onDisable() { if (pressed && game.inWorld()) game.setJumpInput(false); pressed = false; }
    @Override protected void onWorldLeave() { pressed = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (pressed) { game.setJumpInput(false); pressed = false; return; }
        EntityInfo me = game.self();
        if (!me.onGround() || !game.movingForward() || game.sneaking()) return;
        Vec3 a = me.pos().add(Angles.dir(game.yaw()).scale(reach.get()));
        int x = (int) Math.floor(a.x()), z = (int) Math.floor(a.z()), y = (int) Math.floor(me.pos().y());
        if (!game.isLoaded(x, z)) return;
        if (game.isSolid(x, y, z) && game.isAir(x, y + 1, z) && game.isAir(x, y + 2, z)) { game.setJumpInput(true); pressed = true; }
    }
}
