package dev.ultimate.modules.world;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;

/** Mines a straight tunnel in the direction you face (width x height), nearest block first, optionally walking forward. */
public final class TunnelMiner extends Module {
    public final Setting.Num width = add(Setting.Num.intg("width", "Tunnel width", 1, 1, 5));
    public final Setting.Num height = add(Setting.Num.intg("height", "Tunnel height", 2, 1, 5));
    public final Setting.Num depth = add(Setting.Num.intg("depth", "How many blocks ahead to clear", 4, 1, 6));
    public final Setting.Bool walk = add(new Setting.Bool("walk", "Walk forward while the way ahead is clear", false));
    private final Game game; private BlockPos current; private boolean walking;
    public TunnelMiner(Game g) { super("tunnel-miner", "Tunnel Miner", "Digs a tunnel in front of you.", Category.WORLD); game = g; }
    @Override protected void onDisable() { current = null; if (walking && game.inWorld()) game.setForwardInput(false); walking = false; }
    @Override protected void onWorldLeave() { current = null; walking = false; }
    private boolean mineable(int x, int y, int z) { return game.isLoaded(x, z) && !game.isAir(x, y, z) && game.isBreakable(x, y, z) && !game.isLiquid(x, y, z); }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        EntityInfo me = game.self(); Vec3 eye = Angles.eye(me);
        double yaw = Math.toRadians(game.yaw()); int fx, fz;                      // facing snapped to an axis
        if (Math.abs(Math.sin(yaw)) > Math.abs(Math.cos(yaw))) { fx = Math.sin(yaw) > 0 ? -1 : 1; fz = 0; } else { fx = 0; fz = Math.cos(yaw) > 0 ? 1 : -1; }
        int px = (int) Math.floor(me.pos().x()), py = (int) Math.floor(me.pos().y()), pz = (int) Math.floor(me.pos().z());
        if (current != null && !mineable(current.x(), current.y(), current.z())) current = null;
        boolean clearAhead = true;
        if (current == null) {
            double bd = Double.MAX_VALUE; int half = (width.asInt() - 1) / 2;
            for (int f = 1; f <= depth.asInt(); f++) for (int l = -half; l <= width.asInt() - 1 - half; l++) for (int h = 0; h < height.asInt(); h++) {
                int x = px + fx * f - fz * l, z = pz + fz * f + fx * l, y = py + h;
                if (!mineable(x, y, z)) continue;
                if (f <= 2) clearAhead = false;
                double d = new Vec3(x + .5, y + .5, z + .5).distanceTo(eye);
                if (d <= 5.0 && d < bd) { bd = d; current = new BlockPos(x, y, z); }
            }
        } else clearAhead = false;
        if (current != null && !game.breakBlock(current)) current = null;
        boolean go = walk.get() && clearAhead && current == null;
        if (go != walking) { game.setForwardInput(go); walking = go; }
    }
}
