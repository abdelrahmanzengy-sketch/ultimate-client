package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;

import java.util.ArrayList;
import java.util.List;

/** Seals the four sides at head height and the block above your head whenever any respawn anchor is within range. */
public final class AnchorGuard extends Module {
    public final Setting.Num radius = add(Setting.Num.intg("radius", "Act when an anchor is within this many blocks", 6, 2, 10));
    public final Setting.Bool roof = add(new Setting.Bool("roof", "Also cap the block above your head", true));
    public final Setting.Num perTick = add(Setting.Num.intg("per-tick", "Blocks placed per tick", 2, 1, 5));
    private final Game game;
    public AnchorGuard(Game g) { super("anchor-guard", "Anchor Guard", "Seals head height when anchors are nearby.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        EntityInfo me = game.self(); int cx = Placer.fx(me), cy = Placer.fy(me), cz = Placer.fz(me), r = radius.asInt(); boolean found = false;
        outer: for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++)
            if (game.isLoaded(cx + dx, cz + dz) && game.anchorCharges(new BlockPos(cx + dx, cy + dy, cz + dz)) >= 0) { found = true; break outer; }
        if (!found) return;
        List<BlockPos> t = new ArrayList<>();
        t.add(new BlockPos(cx + 1, cy + 1, cz)); t.add(new BlockPos(cx - 1, cy + 1, cz)); t.add(new BlockPos(cx, cy + 1, cz + 1)); t.add(new BlockPos(cx, cy + 1, cz - 1));
        if (roof.get()) t.add(new BlockPos(cx, cy + 2, cz));
        Placer.placeAny(game, t, perTick.asInt(), false);
    }
}
