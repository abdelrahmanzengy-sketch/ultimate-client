package dev.ultimate.modules.combat;

import dev.ultimate.combat.Explosion;
import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.core.FriendManager;
import dev.ultimate.game.*;

import java.util.*;

/**
 * Places and breaks end crystals using the {@link Explosion} damage model.
 * Target selection (nearest players, multiple targets), target prediction, self-damage and friend protection,
 * place/break delays, hotbar switching and optional rotation. Logic is unit-tested against a fake {@link Game};
 * it has not been run in a real Minecraft client.
 */
public final class CrystalAura extends Module {
    public final Setting.Bool place = add(new Setting.Bool("place", "Place crystals", true));
    public final Setting.Bool destroy = add(new Setting.Bool("break", "Break crystals", true));
    public final Setting.Num placeRange = add(Setting.Num.dbl("place-range", "Placement range", 4.5, 1.0, 6.0, 0.1));
    public final Setting.Num breakRange = add(Setting.Num.dbl("break-range", "Break range", 4.5, 1.0, 6.0, 0.1));
    public final Setting.Num targetRange = add(Setting.Num.dbl("target-range", "Max distance of targets", 10.0, 3.0, 12.0, 0.5));
    public final Setting.Num maxTargets = add(Setting.Num.intg("max-targets", "Targets considered at once", 1, 1, 4));
    public final Setting.Num minDamage = add(Setting.Num.dbl("min-damage", "Minimum damage to a target", 6.0, 0.0, 36.0, 0.5));
    public final Setting.Num maxSelfDamage = add(Setting.Num.dbl("max-self-damage", "Maximum damage to yourself", 8.0, 0.0, 36.0, 0.5));
    public final Setting.Num selfWeight = add(Setting.Num.dbl("self-weight", "Score penalty per self-damage point", 1.0, 0.0, 4.0, 0.1));
    public final Setting.Num friendMaxDamage = add(Setting.Num.dbl("friend-max-damage", "Skip any crystal that hurts a friend by this much", 2.0, 0.0, 36.0, 0.5));
    public final Setting.Num predictTicks = add(Setting.Num.intg("predict-ticks", "Predict target movement (ticks)", 0, 0, 10));
    public final Setting.Bool facePlace = add(new Setting.Bool("face-place", "Lower min damage on low-health targets", true));
    public final Setting.Num facePlaceHealth = add(Setting.Num.dbl("face-place-health", "Health threshold for face-place", 8.0, 0.0, 20.0, 0.5));
    public final Setting.Num placeDelay = add(Setting.Num.intg("place-delay", "Place delay (ticks)", 0, 0, 20));
    public final Setting.Num breakDelay = add(Setting.Num.intg("break-delay", "Break delay (ticks)", 0, 0, 20));
    public final Setting.Bool autoSwitch = add(new Setting.Bool("auto-switch", "Switch to crystals in the hotbar", true));
    public final Setting.Bool switchBack = add(new Setting.Bool("switch-back", "Restore previous slot after placing", true));
    public final Setting.Bool rotate = add(new Setting.Bool("rotate", "Look at the crystal/placement", false));
    public final Setting.Bool pauseOnEat = add(new Setting.Bool("pause-on-eat", "Pause while using an item", true));
    public final Setting.Bool pauseOnMine = add(new Setting.Bool("pause-on-mine", "Pause while mining", false));

    private final Game game;
    private final FriendManager friends;
    private long lastPlace = -1000, lastBreak = -1000;
    /** For HUD: last target and damage numbers (written on the client thread). */
    public volatile String hudTarget = "";
    public volatile float hudTargetDamage, hudSelfDamage;

    public CrystalAura(Game game, FriendManager friends) {
        super("crystal-aura", "Crystal Aura", "Places and breaks end crystals for maximum damage with self-damage protection.", Category.COMBAT);
        this.game = game; this.friends = friends;
    }

    @Override protected void onDisable() { hudTarget = ""; hudTargetDamage = hudSelfDamage = 0; }

    /** Damage numbers for one crystal center against everyone relevant. */
    private record Eval(float target, float self, boolean friendHurt, float score) {}

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (pauseOnEat.get() && game.usingItem()) return;
        if (pauseOnMine.get() && game.breakingBlock()) return;
        EntityInfo me = game.self();
        List<EntityInfo> all = game.entities();
        List<EntityInfo> targets = pickTargets(me, all);
        if (targets.isEmpty()) { hudTarget = ""; return; }
        List<EntityInfo> friendsNear = new ArrayList<>();
        for (EntityInfo e : all) if (e.kind() == EntityInfo.Kind.PLAYER && friends.isFriend(e.name())) friendsNear.add(e);
        long now = game.tick();
        if (destroy.get() && now - lastBreak >= breakDelay.asInt()) doBreak(me, all, targets, friendsNear, now);
        if (place.get() && now - lastPlace >= placeDelay.asInt()) doPlace(me, targets, friendsNear, now);
    }

    private List<EntityInfo> pickTargets(EntityInfo me, List<EntityInfo> all) {
        List<EntityInfo> t = new ArrayList<>();
        for (EntityInfo e : all)
            if (e.kind() == EntityInfo.Kind.PLAYER && !friends.isFriend(e.name()) && e.health() > 0
                    && e.pos().distanceTo(me.pos()) <= targetRange.get()) t.add(e);
        t.sort(Comparator.comparingDouble(e -> e.pos().distanceTo(me.pos())));
        return t.size() > maxTargets.asInt() ? new ArrayList<>(t.subList(0, maxTargets.asInt())) : t;
    }

    private Vec3 predicted(EntityInfo e) {
        int n = predictTicks.asInt();
        if (n == 0) return e.pos();
        return e.pos().add(e.velocity().x() * n, 0, e.velocity().z() * n);
    }

    private Eval evaluate(Vec3 center, EntityInfo me, List<EntityInfo> targets, List<EntityInfo> friendsNear) {
        Explosion.Blocks b = game::isSolid;
        int diff = game.difficulty();
        float self = Explosion.damage(Explosion.Kind.CRYSTAL, center, me, me.pos(), diff, b);
        boolean hurtFriend = false;
        for (EntityInfo f : friendsNear)
            if (Explosion.damage(Explosion.Kind.CRYSTAL, center, f, f.pos(), diff, b) >= Math.max(0.5, friendMaxDamage.get())) { hurtFriend = true; break; }
        float best = 0, sum = 0;
        for (EntityInfo t : targets) {
            float d = Explosion.damage(Explosion.Kind.CRYSTAL, center, t, predicted(t), diff, b);
            float need = (float) (facePlace.get() && t.effectiveHealth() <= facePlaceHealth.get() ? Math.min(1.0, minDamage.get()) : minDamage.get());
            if (d >= need) { sum += d; best = Math.max(best, d); }
        }
        return new Eval(best, self, hurtFriend, (float) (sum - self * selfWeight.get()));
    }

    private boolean selfSafe(Eval ev, EntityInfo me) {
        return !ev.friendHurt && ev.self <= maxSelfDamage.get() && ev.self < me.effectiveHealth() - 1f;
    }

    private void doBreak(EntityInfo me, List<EntityInfo> all, List<EntityInfo> targets, List<EntityInfo> fr, long now) {
        EntityInfo bestCrystal = null; Eval bestEval = null;
        for (EntityInfo c : all) {
            if (c.kind() != EntityInfo.Kind.CRYSTAL) continue;
            if (c.pos().distanceTo(me.pos()) > breakRange.get()) continue;
            Eval ev = evaluate(c.pos(), me, targets, fr);
            if (ev.target <= 0 || !selfSafe(ev, me)) continue;
            if (bestEval == null || ev.score > bestEval.score) { bestCrystal = c; bestEval = ev; }
        }
        if (bestCrystal == null) return;
        if (rotate.get()) game.lookAt(bestCrystal.pos());
        if (game.attack(bestCrystal.id())) {
            lastBreak = now; hudTargetDamage = bestEval.target; hudSelfDamage = bestEval.self;
            hudTarget = targets.get(0).name();
        }
    }

    private void doPlace(EntityInfo me, List<EntityInfo> targets, List<EntityInfo> fr, long now) {
        boolean offhand = game.offhand() == ItemKind.END_CRYSTAL, mainHand = game.mainHand() == ItemKind.END_CRYSTAL;
        int slot = (!offhand && !mainHand && autoSwitch.get()) ? game.hotbarSlotOf(ItemKind.END_CRYSTAL) : -1;
        if (!offhand && !mainHand && slot < 0) return;

        Vec3 p = me.pos();
        int r = (int) Math.ceil(placeRange.get());
        BlockPos bestBase = null; Eval bestEval = null;
        for (int x = (int) Math.floor(p.x()) - r; x <= (int) Math.floor(p.x()) + r; x++)
            for (int z = (int) Math.floor(p.z()) - r; z <= (int) Math.floor(p.z()) + r; z++) {
                if (!game.isLoaded(x, z)) continue;
                for (int y = (int) Math.floor(p.y()) - r; y <= (int) Math.floor(p.y()) + r; y++) {
                    if (!game.isCrystalBase(x, y, z)) continue;
                    Vec3 center = new Vec3(x + 0.5, y + 1, z + 0.5);
                    if (center.distanceTo(new Vec3(p.x(), p.y() + 1.62, p.z())) > placeRange.get()) continue;
                    BlockPos base = new BlockPos(x, y, z);
                    if (!game.canPlaceCrystal(base)) continue;
                    Eval ev = evaluate(center, me, targets, fr);
                    if (ev.target <= 0 || !selfSafe(ev, me)) continue;
                    if (bestEval == null || ev.score > bestEval.score) { bestBase = base; bestEval = ev; }
                }
            }
        if (bestBase == null) return;
        int prev = game.selectedSlot();
        if (slot >= 0) game.selectSlot(slot);
        if (rotate.get()) game.lookAt(new Vec3(bestBase.x() + 0.5, bestBase.y() + 1.0, bestBase.z() + 0.5));
        boolean ok = game.placeCrystal(bestBase);
        if (slot >= 0 && switchBack.get()) game.selectSlot(prev);
        if (ok) {
            lastPlace = now; hudTargetDamage = bestEval.target; hudSelfDamage = bestEval.self; hudTarget = targets.get(0).name();
        }
    }
}
