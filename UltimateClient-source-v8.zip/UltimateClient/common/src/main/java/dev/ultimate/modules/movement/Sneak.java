package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Holds sneak for you. */
public final class Sneak extends Module {
    public final Setting.Bool onlyWhenMoving = add(new Setting.Bool("only-when-moving", "Sneak only while you are moving", false));
    private final Game game;
    public Sneak(Game g) { super("sneak", "Sneak", "Keeps you sneaking.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        game.setSneakInput(!onlyWhenMoving.get() || game.movingAny());
    }
    @Override protected void onDisable() { if (game.inWorld()) game.setSneakInput(false); }
}
