package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Holes;
import dev.ultimate.util.Placer;

import java.util.List;

/**
 * Drops an anvil on an enemy standing in a hole. The anvil needs something solid next to its spot to be placed against, so
 * it only works where a wall or block is nearby; it does not build scaffolding.
 */
public final class AutoAnvil extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Placement reach", 5.0, 2.0, 6.0, 0.1));
    public final Setting.Num height = add(Setting.Num.intg("height", "Blocks above the target's feet to place the anvil", 3, 2, 5));
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between anvils", 10, 1, 40));
    public final Setting.Bool onlyInHole = add(new Setting.Bool("only-in-hole", "Only target players standing in a 1x1 hole", true));
    private final Game game; private final FriendManager friends; private long last = -1000;
    public AutoAnvil(Game g, FriendManager f) { super("auto-anvil", "Auto Anvil", "Drops anvils on enemies standing in holes.", Category.COMBAT); game = g; friends = f; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem() || game.tick() - last < delay.asInt()) return;
        EntityInfo t = Placer.nearestEnemy(game, friends, range.get() + 2); if (t == null) return;
        int tx = Placer.fx(t), ty = Placer.fy(t), tz = Placer.fz(t);
        if (onlyInHole.get() && Holes.classify(game, tx, ty, tz) == Holes.NONE) return;
        BlockPos spot = new BlockPos(tx, ty + height.asInt(), tz);
        if (spot.center().distanceTo(Angles.eye(game.self())) > range.get()) return;
        for (int y = ty + 1; y < spot.y(); y++) if (game.isSolid(tx, y, tz)) return; // column must be clear
        if (game.isSolid(tx, spot.y(), tz)) return;
        int n = Placer.place(game, List.of(spot), ItemKind.ANVIL, 1, false);
        if (n > 0) last = game.tick();
    }
}
