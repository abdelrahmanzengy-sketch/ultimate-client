package dev.ultimate.modules.combat;

import dev.ultimate.combat.Explosion;
import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;

/**
 * Places a bed beside the nearest enemy and right-clicks it. Beds only explode in the Nether and the End (in the Overworld
 * they just let you sleep), so this does nothing useful elsewhere. Uses the damage model to avoid hurting you.
 */
public final class BedAura extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Placement reach", 4.5, 1.0, 6.0, 0.1));
    public final Setting.Num targetRange = add(Setting.Num.dbl("target-range", "Max target distance", 7.0, 3.0, 10.0, 0.5));
    public final Setting.Num minDamage = add(Setting.Num.dbl("min-damage", "Minimum damage to the target", 6.0, 0.0, 36.0, 0.5));
    public final Setting.Num maxSelf = add(Setting.Num.dbl("max-self-damage", "Maximum damage to you", 6.0, 0.0, 36.0, 0.5));
    public final Setting.Num delay = add(Setting.Num.intg("delay", "Ticks between actions", 2, 0, 20));
    private static final int[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    private final Game game; private final FriendManager friends; private long last = -1000; private BlockPos pending; private int prevSlot = -1;
    public BedAura(Game g, FriendManager f) { super("bed-aura", "Bed Aura", "Places and detonates beds next to enemies (Nether/End).", Category.COMBAT); game = g; friends = f; }
    @Override protected void onDisable() { pending = null; if (prevSlot >= 0 && game.inWorld()) game.selectSlot(prevSlot); prevSlot = -1; }
    @Override protected void onWorldLeave() { pending = null; prevSlot = -1; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        long now = game.tick(); if (now - last < delay.asInt()) return;
        EntityInfo me = game.self(); Vec3 eye = Angles.eye(me);
        if (pending != null) { // second step: the bed was placed, detonate it
            BlockPos p = pending; pending = null;
            if (game.blockId(p.x(), p.y(), p.z()).endsWith("_bed")) { game.interactBlock(p); last = now; }
            if (prevSlot >= 0) { game.selectSlot(prevSlot); prevSlot = -1; }
            return;
        }
        int bed = game.hotbarSlotOf(ItemKind.BED); if (bed < 0) return;
        EntityInfo t = Placer.nearestEnemy(game, friends, targetRange.get()); if (t == null) return;
        int tx = Placer.fx(t), ty = Placer.fy(t), tz = Placer.fz(t);
        BlockPos best = null; int bdx = 0, bdz = 0; double bs = -1e9;
        for (int[] o : DIRS) for (int[] h : DIRS) {
            BlockPos foot = new BlockPos(tx + o[0], ty, tz + o[1]); int hx = foot.x() + h[0], hz = foot.z() + h[1];
            if (hx == tx && hz == tz) continue;
            if (!game.isLoaded(foot.x(), foot.z()) || !game.isLoaded(hx, hz) || !game.isAir(foot.x(), ty, foot.z()) || !game.isAir(hx, ty, hz)) continue;
            if (!game.isSolid(foot.x(), ty - 1, foot.z()) || !game.isSolid(hx, ty - 1, hz)) continue;
            if (foot.center().distanceTo(eye) > range.get()) continue;
            Explosion.Blocks b = (x, y, z) -> !(y == ty && ((x == foot.x() && z == foot.z()) || (x == hx0(foot, h) && z == hz0(foot, h)))) && game.isSolid(x, y, z);
            float dt = Explosion.damage(Explosion.Kind.BED, foot.center(), t, t.pos(), game.difficulty(), b), ds = Explosion.damage(Explosion.Kind.BED, foot.center(), me, me.pos(), game.difficulty(), b);
            if (dt < minDamage.asFloat() || ds > maxSelf.get() || ds >= me.effectiveHealth() - 0.5f) continue;
            double s = dt - ds; if (s > bs) { bs = s; best = foot; bdx = h[0]; bdz = h[1]; }
        }
        if (best == null) return;
        prevSlot = game.selectedSlot(); game.selectSlot(bed);
        game.lookAt(new Vec3(best.x() + 0.5 + bdx * 2, best.y() + 0.5, best.z() + 0.5 + bdz * 2));
        if (game.placeBlock(best)) { pending = best; last = now; } else { game.selectSlot(prevSlot); prevSlot = -1; }
    }
    private static int hx0(BlockPos f, int[] h) { return f.x() + h[0]; }
    private static int hz0(BlockPos f, int[] h) { return f.z() + h[1]; }
}
