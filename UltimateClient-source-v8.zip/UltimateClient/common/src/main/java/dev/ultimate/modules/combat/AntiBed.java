package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;
import dev.ultimate.util.Placer;

import java.util.ArrayList;
import java.util.List;

/** When a bed is placed next to you, puts blocks between it and you at foot and head height. */
public final class AntiBed extends Module {
    public final Setting.Num radius = add(Setting.Num.intg("radius", "Look for beds within this many blocks", 4, 2, 7));
    public final Setting.Num perTick = add(Setting.Num.intg("per-tick", "Blocks placed per tick", 2, 1, 4));
    private final Game game;
    public AntiBed(Game g) { super("anti-bed", "Anti Bed", "Blocks the line to nearby beds.", Category.COMBAT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        EntityInfo me = game.self(); int cx = Placer.fx(me), cy = Placer.fy(me), cz = Placer.fz(me), r = radius.asInt();
        int bx = 0, bz = 0; double bd = Double.MAX_VALUE; boolean found = false;
        for (int dx = -r; dx <= r; dx++) for (int dy = -1; dy <= 2; dy++) for (int dz = -r; dz <= r; dz++) {
            if (!game.isLoaded(cx + dx, cz + dz) || !game.blockId(cx + dx, cy + dy, cz + dz).endsWith("_bed")) continue;
            double d = dx * dx + dz * dz; if (d < bd) { bd = d; bx = dx; bz = dz; found = true; }
        }
        if (!found) return;
        int sx = Integer.signum(bx), sz = Integer.signum(bz); List<BlockPos> t = new ArrayList<>();
        for (int h = 0; h <= 1; h++) { if (sx != 0) t.add(new BlockPos(cx + sx, cy + h, cz)); if (sz != 0) t.add(new BlockPos(cx, cy + h, cz + sz)); }
        Placer.placeAny(game, t, perTick.asInt(), false);
    }
}
