package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Jumps for you when you reach the edge of a block while walking forward. */
public final class Parkour extends Module {
    public final Setting.Num edge = add(Setting.Num.dbl("edge", "Distance from the ledge to jump (blocks)", 0.35, 0.1, 0.9, 0.05));
    private final Game game; private boolean pressed;
    public Parkour(Game g) { super("parkour", "Parkour", "Auto-jumps at ledges.", Category.MOVEMENT); game = g; }
    @Override protected void onDisable() { if (pressed && game.inWorld()) game.setJumpInput(false); pressed = false; }
    @Override protected void onWorldLeave() { pressed = false; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead()) return;
        if (pressed) { game.setJumpInput(false); pressed = false; return; }
        EntityInfo me = game.self();
        if (!me.onGround() || !game.movingForward() || game.sneaking()) return;
        Vec3 a = me.pos().add(Angles.dir(game.yaw()).scale(edge.get()));
        int x = (int) Math.floor(a.x()), z = (int) Math.floor(a.z()), y = (int) Math.floor(me.pos().y());
        if (!game.isLoaded(x, z)) return;
        if (game.isAir(x, y - 1, z) && game.isAir(x, y - 2, z)) { game.setJumpInput(true); pressed = true; }
    }
}
