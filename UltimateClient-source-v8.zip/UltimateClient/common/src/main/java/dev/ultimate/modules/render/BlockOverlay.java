package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.game.*;

/** Outlines the block you are looking at. */
public final class BlockOverlay extends EspModule {
    public BlockOverlay(Game g) { super("block-overlay", "Block Overlay", "Highlights the block under your crosshair.", g); color.set(0xFFFFFFFF); style.set("Both"); labels.set(false); }
    @Override protected void draw(RenderQueue q) {
        BlockPos t = game.targetBlock(); if (t == null || !game.isLoaded(t.x(), t.z())) return;
        blockBox(q, t, col()); label(q, t.center().add(0, 0.8, 0), game.blockId(t.x(), t.y(), t.z()).replace("minecraft:", ""));
    }
}
