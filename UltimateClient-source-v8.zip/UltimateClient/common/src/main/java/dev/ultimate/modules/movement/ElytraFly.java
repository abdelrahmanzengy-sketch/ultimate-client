package dev.ultimate.modules.movement;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** While gliding: forward flies along your view, jump/sneak climb/descend, otherwise you hover. */
public final class ElytraFly extends Module {
    public final Setting.Num speed = add(Setting.Num.dbl("speed", "Forward speed (blocks/tick)", 1.2, 0.1, 4.0, 0.1));
    public final Setting.Num vertical = add(Setting.Num.dbl("vertical-speed", "Vertical speed (blocks/tick)", 0.5, 0.05, 2.0, 0.05));
    public final Setting.Num idleSink = add(Setting.Num.dbl("idle-sink", "Sink rate while hovering", 0.02, 0.0, 0.3, 0.01));
    private final Game game;
    public ElytraFly(Game g) { super("elytra-fly", "Elytra Fly", "Controlled elytra flight.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.gliding()) return;
        if (game.movingForward()) { game.setVelocity(Angles.look(game.yaw(), game.pitch()).scale(speed.get())); return; }
        double vy = game.jumping() ? vertical.get() : game.sneaking() ? -vertical.get() : -idleSink.get();
        game.setVelocity(new Vec3(0, vy, 0));
    }
}
