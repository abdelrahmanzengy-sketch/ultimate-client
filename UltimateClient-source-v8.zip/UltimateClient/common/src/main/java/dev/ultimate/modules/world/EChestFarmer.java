package dev.ultimate.modules.world;

import dev.ultimate.core.Category;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Mines ender chests in reach with the pickaxe from your hotbar. Use a Silk Touch pickaxe to keep the chests; otherwise they drop obsidian. */
public final class EChestFarmer extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Reach", 4.5, 2.0, 6.0, 0.1));
    private final Game game; private int prev = -1;
    public EChestFarmer(Game g) { super("echest-farmer", "E-Chest Farmer", "Mines nearby ender chests.", Category.WORLD); game = g; }
    @Override protected void onDisable() { restore(); }
    @Override protected void onWorldLeave() { prev = -1; }
    private void restore() { if (prev >= 0 && game.inWorld()) game.selectSlot(prev); prev = -1; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        EntityInfo me = game.self(); Vec3 eye = Angles.eye(me); int r = (int) Math.ceil(range.get());
        int cx = (int) Math.floor(me.pos().x()), cy = (int) Math.floor(me.pos().y()), cz = (int) Math.floor(me.pos().z()); BlockPos best = null; double bd = Double.MAX_VALUE;
        for (int dx = -r; dx <= r; dx++) for (int dy = -r; dy <= r; dy++) for (int dz = -r; dz <= r; dz++) {
            int x = cx + dx, y = cy + dy, z = cz + dz; if (!game.isLoaded(x, z) || !game.blockId(x, y, z).endsWith("ender_chest")) continue;
            double d = new Vec3(x + .5, y + .5, z + .5).distanceTo(eye); if (d <= range.get() && d < bd) { bd = d; best = new BlockPos(x, y, z); }
        }
        if (best == null) { restore(); return; }
        int pick = game.hotbarSlotOf(ItemKind.PICKAXE); if (pick < 0) { restore(); return; }
        if (prev < 0) prev = game.selectedSlot(); game.selectSlot(pick); game.lookAt(best.center()); game.breakBlock(best);
    }
}
