package dev.ultimate.modules.combat;

import dev.ultimate.core.Category;
import dev.ultimate.core.FriendManager;
import dev.ultimate.core.Module;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

/** Smoothly turns the view toward the closest player inside a field-of-view cone. Never snaps. */
public final class AimAssist extends Module {
    public final Setting.Num range = add(Setting.Num.dbl("range", "Maximum distance", 5.0, 1.0, 8.0, 0.5));
    public final Setting.Num fov = add(Setting.Num.dbl("fov", "Only targets within this many degrees of your view", 90.0, 10.0, 360.0, 5.0));
    public final Setting.Num speed = add(Setting.Num.dbl("speed", "Max degrees turned per tick", 4.0, 0.5, 30.0, 0.5));
    public final Setting.Bool vertical = add(new Setting.Bool("vertical", "Also adjust pitch", true));
    public final Setting.Mode aimAt = add(new Setting.Mode("aim-at", "Body part", "Chest", "Head", "Chest", "Feet"));
    public final Setting.Bool onlyWithWeapon = add(new Setting.Bool("only-with-weapon", "Only while holding a sword or axe", false));
    private final Game game; private final FriendManager friends;

    public AimAssist(Game g, FriendManager f) { super("aim-assist", "Aim Assist", "Gently steers your aim toward nearby players.", Category.COMBAT); game = g; friends = f; }

    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || game.usingItem()) return;
        if (onlyWithWeapon.get() && game.mainHand() != ItemKind.SWORD && game.mainHand() != ItemKind.AXE) return;
        EntityInfo me = game.self(), best = null; double bestAngle = Double.MAX_VALUE;
        Vec3 eye = Angles.eye(me); float yaw = game.yaw(), pitch = game.pitch();
        for (EntityInfo e : game.entities()) {
            if (e.kind() != EntityInfo.Kind.PLAYER || e.health() <= 0 || friends.isFriend(e.name())) continue;
            if (e.pos().distanceTo(me.pos()) > range.get()) continue;
            double ang = Math.abs(Angles.wrap(Angles.yawTo(eye, aim(e)) - yaw));
            if (ang <= fov.get() / 2.0 && ang < bestAngle) { bestAngle = ang; best = e; }
        }
        if (best == null) return;
        Vec3 p = aim(best);
        float ny = Angles.step(yaw, Angles.yawTo(eye, p), speed.asFloat());
        float np = vertical.get() ? Angles.step(pitch, Angles.pitchTo(eye, p), speed.asFloat()) : pitch;
        game.setRotation(ny, Math.max(-90f, Math.min(90f, np)));
    }

    private Vec3 aim(EntityInfo e) {
        double f = switch (aimAt.get()) { case "Head" -> 0.95; case "Feet" -> 0.1; default -> 0.65; };
        return e.pos().add(0, e.height() * f, 0);
    }
}
