package dev.ultimate.modules.render;

import dev.ultimate.core.RenderQueue;
import dev.ultimate.core.Setting;
import dev.ultimate.game.*;

import java.util.List;
import java.util.Locale;

/** Draws where every ender pearl currently in flight (yours and other players') will land. */
public final class PearlTrajectory extends EspModule {
    public final Setting.Num steps = add(Setting.Num.intg("steps", "Maximum simulated ticks", 120, 10, 300));
    public PearlTrajectory(Game g) { super("pearl-trajectory", "Pearl Trajectory", "Shows where flying ender pearls will land.", g); color.set(0xFFB040FF); }
    @Override protected void draw(RenderQueue q) {
        for (EntityInfo e : game.entities()) {
            if (e.kind() != EntityInfo.Kind.OTHER || !e.name().toLowerCase(Locale.ROOT).contains("ender pearl") || !within(e.pos())) continue;
            List<Vec3> pts = Trajectories.simulate(game, e.pos(), e.velocity(), 0.03, 0.99, steps.asInt());
            for (int i = 1; i < pts.size(); i++) line(q, pts.get(i - 1), pts.get(i), col());
            Vec3 end = pts.get(pts.size() - 1); box(q, end.add(-0.3, -0.3, -0.3), end.add(0.3, 0.3, 0.3), col());
            label(q, end.add(0, 0.8, 0), String.format(Locale.ROOT, "pearl %.0fm", end.distanceTo(game.self().pos())));
        }
    }
}
