package dev.ultimate.modules.movement;

import dev.ultimate.core.*;
import dev.ultimate.core.Module;
import dev.ultimate.game.*;

/** While gliding, steers toward a coordinate and holds altitude, then turns itself off and tells you when it arrives. */
public final class ElytraAutopilot extends Module {
    public final Setting.Num targetX = add(Setting.Num.dbl("target-x", "Destination X", 0.0, -3.0e7, 3.0e7, 1.0));
    public final Setting.Num targetZ = add(Setting.Num.dbl("target-z", "Destination Z", 0.0, -3.0e7, 3.0e7, 1.0));
    public final Setting.Num arrive = add(Setting.Num.dbl("arrive-radius", "Stop within this many blocks of the target", 12.0, 2.0, 200.0, 1.0));
    public final Setting.Num turnRate = add(Setting.Num.dbl("turn-rate", "Max degrees turned per tick", 6.0, 1.0, 30.0, 1.0));
    public final Setting.Num climbPitch = add(Setting.Num.dbl("climb-pitch", "Pitch used to gain height (degrees, negative = up)", -30.0, -60.0, 0.0, 1.0));
    public final Setting.Num divePitch = add(Setting.Num.dbl("dive-pitch", "Pitch used to gain speed (degrees)", 20.0, 0.0, 60.0, 1.0));
    private final Game game;
    public ElytraAutopilot(Game g) { super("elytra-autopilot", "Elytra Autopilot", "Flies your elytra to a coordinate.", Category.MOVEMENT); game = g; }
    @Override protected void onTick() {
        if (!game.inWorld() || game.selfDead() || !game.gliding()) return;
        EntityInfo me = game.self();
        double dx = targetX.get() - me.pos().x(), dz = targetZ.get() - me.pos().z();
        if (Math.sqrt(dx * dx + dz * dz) <= arrive.get()) { game.message("Elytra Autopilot: arrived"); setEnabled(false); return; }
        float yaw = Angles.step(game.yaw(), (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0), turnRate.asFloat());
        double vy = me.velocity().y(); float pitch;
        if (vy < -0.15) pitch = climbPitch.asFloat();            // sinking: pull up
        else if (vy > 0.1) pitch = divePitch.asFloat();          // rising too fast: dive for speed
        else pitch = 0f;
        game.setRotation(yaw, Math.max(-90f, Math.min(90f, Angles.step(game.pitch(), pitch, 6f))));
    }
}
