# UltimateClient — Reference Feature Inventory (step 1)

Source: class names / fabric.mod.json read from the five uploaded JARs. Module names are real class names;
behaviour/settings were NOT decompiled yet (that is the next inventory pass). Licences: Meteor, Anubis, OpSec = GPL-3.0; Baritone = LGPL-3.0.

## Reference JARs
| JAR | Version | MC | Java | Classes |
|---|---|---|---|---|
| Meteor Client | 1.21.11-86 | 1.21.11 | 21 | 1349 |
| Anubis | 1.0+mc1.21.11 | ~1.21.11 | 21 | 1284 (breaks Embeddium/OptiFabric) |
| Baritone-Meteor | 1.21.11-SNAPSHOT | 1.21.11 | 21 | 465 |
| OpSec | 1.1.7.1 | 1.21.11 (<26.1) and 26.2 (>=26.2 <26.3, Java 25) | 21 / 25 | 116 each |

## Meteor 1.21.11-86 modules
- **Combat:** AnchorAura AntiAnchor AntiAnvil AntiBed ArrowDodge AttributeSwap AutoAnvil AutoArmor AutoCity AutoEXP AutoLog AutoTotem AutoTrap AutoWeapon AutoWeb BedAura BowAimbot BowSpam Burrow Criticals CrystalAura Hitboxes HoleFiller KillAura Offhand Quiver SelfAnvil SelfTrap SelfWeb Surround
- **Movement:** AirJump Anchor AntiVoid AutoJump AutoWalk AutoWasp Blink ClickTP ElytraBoost ElytraFly(Bounce/Packet/Pitch40/Vanilla) EntityControl FastClimb Flight GUIMove HighJump Jesus LongJump NoFall NoSlow Parkour ReverseStep SafeWalk Scaffold Slippy Sneak Speed(Strafe/Vanilla) Spider Sprint Step TridentBoost Velocity
- **Player:** AirPlace AntiAFK AntiHunger AutoClicker AutoEat AutoFish AutoGap AutoMend AutoReplenish AutoRespawn AutoTool BreakDelay ChestSwap EXPThrower FakePlayer FastUse GhostHand InstantRebreak LiquidInteract MiddleClickExtra Multitask NameProtect NoInteract NoMiningTrace NoRotate NoStatusEffects OffhandCrash Portals PotionSaver Reach Rotation SpeedMine
- **Render:** BetterTab BetterTooltips BlockSelection Blur BossStack Breadcrumbs BreakIndicators CameraTweaks Chams CityESP ESP EntityOwner FreeLook Freecam Fullbright HandView HoleESP ItemHighlight ItemPhysics LightOverlay LogoutSpots Nametags NoRender PopChams StorageESP TimeChanger Tracers Trail Trajectories TunnelESP VoidESP Waypoints Xray Zoom BlockESP Markers WallHack
- **World:** Ambience AutoBreed AutoBrewer AutoMount AutoNametag AutoShearer AutoSign AutoSmelter BuildHeight Collisions EChestFarmer EndermanLook Excavator Flamethrower HighwayBuilder InfinityMiner LiquidFiller MountBypass NoGhostBlocks Nuker PacketMine SpawnProofer StashFinder Timer VeinMiner
- **Misc:** AntiPacketKick AutoReconnect BetterBeacons BetterChat BookBot DiscordPresence InventoryTweaks MessageAura Notebot Notifier PacketCanceller PacketLogger ServerSpoof SoundBlocker Spam Swarm

## Anubis 1.0 modules (net.anubis.client.module.impl)
- **Combat:** AimAssist AnchorAura AutoCity AutoInvTotem AutoTotem AutoTrap CrystalAura CrystalMacro CrystalOptimizer FakeLag FastXp FriendGuard HoverTotem JumpReset KeyThrow KillAura KnockbackDelay Mace ShieldBreaker SingleAnchorMacro SpearLunge Triggerbot WTapRecode AnchorGuard PearlFlight CrystalBot SwordBot (+ helpers: CrystalDamage, HurtClock, LootGuard, SlotReturn, OffhandRefill, DoubleHand)
- **Movement:** AutoJump AutoWalk BoatFly BoatNoclip ClickTp ElytraFly ElytraSwap EntityControl EntitySpeed Fly Jesus NoJumpDelay Sneak Speed Spider Sprint TridentBoost
- **Misc:** AirStuck AntiGhostBlock AntiTrap AntiVanish AutoClicker AutoEat AutoReconnect AutoRelog BlockNotifier ChatMacro CoordSnapper DiscordPresence FastUse Freecam LegitAutoTool MediaBaseFinder NameProtect NetheriteFinder NoInvLeak PlayerDetection SkinChange SlowSwing Spam SpawnerProtect StaffList StaffLive TridentUtil WeatherNotifier
- **Render:** Atmosphere BetterSusChunk BlockEntityDebug BlockEsp BlockOverlay ChunkScanner ColorGrading CustomCrosshair CustomFov CustomGlint Esp Freelook Fullbright HandModel HitParticles HoleEsp ItemEsp JumpCircles LightEsp LowHealthWarning MotionBlur Nametags NoRender PearlTrajectory ShaderEsp SpawnerNametags SpawnerNotifier StorageEsp SusChunkFinder SwingAnimation TargetEsp TimeChanger Tracers Trajectories Waypoints Xray Zoom
- **HUD/GUI:** Hud, Radar, Performance, Hotkeys, RegionMap, SpotifyHud; ClickGuiRenderer, HudEditorScreen, HudLayoutStore, ProfileList, ModuleConfigStore, ArmorStatus; settings types: Boolean/Number/Mode/Color/Key/String/StringList/Action/BlockColorList/ItemColorList
- **Server-specific economy bots (not planned):** AhSell, AhSniper, AutoSell, AutoTpaHere, OrderAhSeller, OrderDropper, PanicPay, TpMacro, GoliathRtp, DonutNoFall

## Baritone (baritone-meteor 1.21.11)
- Commands: Axis Blacklist Build Click Come ETA Elytra Explore ExploreFilter Farm Find Follow ForceCancel Gc Goal Goto Help Invert Litematica Mine Path Pickup Proc ReloadAll Render Repack SaveAll Schematica Sel Set Surface ThisWay Tunnel Version Waypoints
- Processes: Builder, CustomGoal, Elytra, Explore, Farm, Follow, GetToBlock, Mine, Backfill, InventoryPauser
- Integration plan: depend on the Baritone API jar (do not copy its code); settings screen generated from Baritone `Settings`.

## OpSec 1.1.7.1 (privacy)
From class names (not yet read in detail): client brand spoofing (ClientSpoofer, SpoofSettings), resource-pack guard / pack stripping (ResourcePackGuard, PackStripHandler), tracking-pack detection (TrackPackDetector), translation-key exploit protection (TranslationProtectionHandler), shader strip tracking, account manager, privacy logger, jar integrity check, config screen. Conflicts with: exploitpreventer. Breaks: ichor, labymod.

## Spec items with NO match in any reference (must be designed from scratch)
Auto Mount etc. exist; but these do not appear by name: Crystal prediction/target prediction internals, Shield-aware damage calc beyond CrystalDamage helper, Hover/Inv Totem exist only in Anubis, Spawner ESP (Anubis SpawnerNametags/Notifier), Fake Stats, Inventory Privacy Overlay (closest: Anubis NoInvLeak), Compass/Lag-notifier/Server-info HUD elements, Chunk-border/Netherite-visuals, Auto Respawn/Anti-Hunger exist (Meteor).

## Deliberately excluded
Crash/exploit style modules (Meteor OffhandCrash, MountBypass, AntiPacketKick, PacketCanceller) and anything intended to evade server anti-cheat.
