# UltimateClient — honest status (2026-11-13 update)

## What was verified in this update
Run with plain JDK 21 / Gradle 9 (offline), no Minecraft involved:
- `gradle :core:runCoreTests`   → 44 checks, 0 failures (module lifecycle, settings validation, event bus, config profiles)
- `gradle :common:runModuleTests` → 185 checks, 0 failures (see below)

## Architecture added
`Game` (core/.../game) is the single interface between module logic and Minecraft. Modules in `common` only talk to
`Game`, so they are version independent and tested here against a fake world. Each Minecraft version implements `Game` once.
`combat/Explosion` is a vanilla-formula explosion model (ray-sampled exposure, falloff, difficulty, armor/toughness,
resistance, blast protection) used by crystal logic. It was tested for internal consistency only; it was NOT compared
with real in-game damage.

## Modules with real logic (19) + HUD model — logic unit-tested, NOT run in Minecraft
Crystal Aura (place + break, target selection, multi-target, prediction, self-damage and friend protection, face-place, delays,
hotbar/offhand handling, HUD numbers), Kill Aura (priorities, cooldown, line of sight, friends, multi-hit), Auto Totem,
Surround, Sprint, Fly (Hover/Glide), No Fall, Auto Respawn, plus Auto Trap, Self Trap, Auto Web, Self Web, Hole Filler,
Auto Offhand, Speed, Auto Walk, High Jump, Anti AFK, Auto Eat. The HUD model (`hud/Hud.java`: watermark, active modules,
coordinates, speed, direction, totem count, crystal info; drag/scale clamping; layout persisted in profiles) produces text only —
there is no renderer or HUD editor screen.
Every one has settings, description, category, keybind field, enable/disable/tick callbacks and cleanup through `Module`.

## NOT verified / NOT done
- **Nothing has been compiled against Minecraft.** The sandbox blocks maven.fabricmc.net, repo.maven.apache.org and
  Mojang's servers, so Loom could not run and **no JAR was produced** (neither UltimateClient-1.21.11.jar nor -26.2.jar).
- `versions/1.21.11/.../McGame.java` and `UltimateClient.java` (tick hook, `/uc` commands, config dir) were written
  from memory of the Yarn API and are untested; expect a handful of name fixes on the first build.
- `versions/26.2` has build config and `fabric.mod.json` only — no entrypoint and no `Game` implementation.
- No Click GUI, HUD, keybind capture, rendering/ESP, Baritone integration, mixins, Android/Pojav testing,
  Sodium/Iris/VulkanMod/LWJGL compatibility layer, or OpSec-style privacy features.
- Skeleton classes from the previous drop (settings only, no behaviour) were moved to `/unfinished` and are no longer
  registered, because registered do-nothing modules violate the "no placeholder modules" requirement.
- Blast-protection enchantment level of *other* players is reported as 0 by McGame (affects crystal damage estimates).

See STATUS.md for the item-by-item list against the original specification.

## v4 update (2026-11-13)
- 32 new modules (19 -> 51), see STATUS.md. New `Game` capabilities (view angles, jump/sneak input, use-item, crosshair target, break/interact block,
  liquid/light queries, anchors, tool choice, night vision, FOV, step height, chat, fishing bobber, armor/chest/hotbar inventory moves, item ids) all have
  safe defaults in the interface, real implementations in `McGame` (uncompiled) and a full fake in the tests.
- `game/Angles.java`: yaw/pitch maths shared by Aim Assist, Elytra Fly, Auto Jump, Parkour.
- `sh scripts/run-tests.sh` runs everything without Gradle (set `JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"` on a JRE-only machine).
- Still true: nothing has been compiled against Minecraft and no JAR has been built.

## v5 update (2026-11-14)
- `core`: `Keys` (name<->GLFW), `KeyPoller` (edge-triggered keybinds, no allocations), `BrandState` (read by the brand mixin).
- `common`: `Shell` (the `/uc` interpreter: pure Java, tested), 9 new modules, extra HUD elements; `Game` gained keyDown/screenOpen/isBlocking/blockId/fps/ping.
- `versions/1.21.11`: entrypoint wires shell + keys + autosave + `HudRenderer`; `mixin/ClientBrandMixin`; `McGame` additions.
- `versions/26.2`: new `McGame` (Mojang names), entrypoint and mixin. No HUD renderer.
- Build: root `build.gradle` fixed; version jars now contain core+common classes; GitHub Actions workflow added.
