# Building

Nothing here has ever been built against Minecraft by the author. Expect to fix some compile errors in the two `McGame.java` files first.

## Easiest: GitHub Actions (works from a phone browser)
1. Create a GitHub repository and upload this folder's contents (keep `.github/workflows/build.yml`).
2. Open the **Actions** tab -> the **build** run. It runs the unit tests, then builds `1.21.11` and `26.2` separately.
3. Download the artifacts: `UltimateClient-1.21.11` / `UltimateClient-26.2` (the jar) and `log-1.21.11` / `log-26.2` (the full build log).
4. If a build fails, send me the log. Most likely errors are renamed Minecraft methods in `versions/*/src/main/java/dev/ultimate/McGame.java`
   (spots marked `VERIFY`), or a Gradle / Loom version that does not match `build.gradle` (versions are pinned in the two version build files and in the workflow).

## Locally
Install JDK 21 and JDK 25, and Gradle 9.5.1 (no wrapper is included). Then:
```sh
sh scripts/run-tests.sh                 # pure-Java tests, no Minecraft or network needed
gradle :versions:1.21.11:build
gradle :versions:26.2:build
```
Jars: `versions/<version>/build/libs/`. Install into `.minecraft/mods` (or the Pojav mods folder) with the matching Fabric Loader and Fabric API.

## Using it in game
No Click GUI exists yet. Use chat commands: `/uc help`. Examples: `/uc list`, `/uc toggle crystal-aura`, `/uc set crystal-aura min-damage 8`,
`/uc bind fly G`, `/uc save pvp`, `/uc load pvp`, `/uc friend add Name`, `/uc panic`. Settings are saved on disconnect/exit to
`config/ultimateclient/<profile>.json` and the `default` profile loads at start.
