# Status against the original specification (1.21.11-only package, 2026-11-14)

> This package contains only the Minecraft 1.21.11 target. The 26.2 adapter was removed; the shared `core`/`common` code is identical to the two-version project.

**Read this first.** *Logic tested* = unit-tested here against a fake `Game` (no Minecraft). **Nothing in this project has been compiled
against Minecraft, run in a real client, tested on PojavLauncher, or tested with Sodium/Iris/VulkanMod.** The authoring sandbox could not reach
maven.fabricmc.net / Mojang, so Fabric Loom never ran and **no JAR exists**. Build with the GitHub Actions workflow (see BUILDING.md); the first
build will almost certainly report some renamed-method errors in the two `McGame.java` adapters and the mixins (look for `VERIFY` comments).

Verified here (plain JDK 21, `sh scripts/run-tests.sh`): `CoreTest` 44 checks, `ModuleTest` 2004 checks, 0 failures. That covers every module toggled
alone in 6 hostile scenes (normal, crowded, outside a world, dead, chunks unloaded, void), all 118 modules enabled together for 200 ticks plus a
disconnect, a JSON profile round-trip of every setting, the whole `/uc` shell, and behaviour tests per module (`V6Test`, `V7Test`).

## v8 additions
- Anti Anchor / Anchor Guard / Anti Bed / Anti Anvil now fall back to cobblestone-type blocks when you carry no obsidian (`Placer.placeAny`, tested).
- `docs/MODULES.md` (every module, setting, range and default, generated from the code), `default-config/default.json`, `scripts/gen-docs.sh`, install steps in README.md.
- Tests: `ModuleTest` 2005 checks, 0 failures.

## Compile attempt (v7)
I tried to compile the version adapters. **It is not possible in the authoring sandbox**: Fabric Maven, Mojang's servers, Maven Central and the Gradle
distribution servers are all blocked (only GitHub is reachable), so there is no Minecraft jar to compile against. `core` + `common` (everything that does not
touch Minecraft) compile with plain JDK 21 and pass all tests.
What I could do instead: I cloned the Yarn 1.21.11 mappings from GitHub and checked the names the 1.21.11 adapter and its mixins use. Confirmed to exist:
`AbstractBoatEntity`, `DisconnectedScreen`, `ConnectScreen.connect(Screen, MinecraftClient, ServerAddress, ServerInfo, boolean, CookieStorage)`, `ServerAddress.parse`,
`ServerInfo.address`, `HandledScreen.focusedSlot`, `Slot.inventory/getIndex`, `TextVisitFactory.visitFormatted(String,int,Style,Style,CharacterVisitor)`, `MinecraftClient.itemUseCooldown`,
`ClientPlayerInteractionManager.blockBreakingCooldown/currentBreakingProgress/attackEntity/interactEntity`, `ChunkManager.getWorldChunk(int,int)`, `WorldAccess.getChunkManager`,
`LivingEntity.hurtTime/getStatusEffects`, `StatusEffectInstance.isInfinite/getDuration/getAmplifier/getEffectType`, `ClientPlayNetworkHandler.getPlayerList`, `PlayerListEntry.getProfile`,
`GameOptions.leftKey/rightKey/getViewDistance`, `Registries.BLOCK_ENTITY_TYPE`, `Entity.getVehicle/getVelocity/setVelocity/getChunkPos`. This proves the names exist, **not** that the code compiles
(types, generics and Mojang-side API details were not checked). Item constants such as `Items.MACE` / `ItemTags.BEDS` are generated names and could not be grepped.
There is no mapping repository for the 26.2 (Mojang-named) adapter, so none of its names were checked.
`GameProfile.name()` (authlib) and the `DisconnectionInfo.reason()` record accessor were not verifiable, so the disconnect reason is still not read.

## What changed in v7 (55 new modules, 63 -> 118)
- **Combat (+15):** Crystal Macro, Crystal Optimizer, Single Anchor Macro, Anti Anchor, Anchor Guard, Anti Bed, Bed Aura, Auto Anvil, Anti Anvil, Criticals (crit assist: hops, no packets),
  W-Tap, Mace, Auto Inventory Totem, Hover Totem, Friend Guard (attack mixin).
- **Movement (+5):** Velocity (client-side knockback scaling), Elytra Boost, Boat Fly, Entity Speed, GUI Move.
- **Player (+4):** Fast Use, Fast XP, Break Delay, Speed Mine (via accessor mixins).
- **Render (+20) - logic only, see warning below:** Entity/Player/Item/Storage/Block/Hole/City/Target/Spawner ESP, Netherite Finder, Tracers, Nametags, Trajectories,
  Pearl Trajectory, Breadcrumbs, Logout Spots, Waypoints, Block Overlay, Light Overlay, Custom FOV. Every ESP has colour, opacity, distance, thickness, style, labels and a max-shapes cap.
- **World (+8):** Stash Finder, E-Chest Farmer, Excavator, Waypoint Navigation (straight line only), Auto Shearer, Auto Breed, Auto Mount, Baritone (reflection bridge + settings; `/uc baritone <cmd>`).
- **Misc (+3):** Auto Reconnect, Auto Relog, Name Protect (text mixin).
- **HUD (+5 model elements):** Player Radar, Inventory Summary, Lag Notifier, Target Info, Combat Info. **Shell:** `/uc wp`, `/uc excavator`, `/uc baritone`.

### Important warnings about v7
- **No renderer exists for the ESP modules.** They describe boxes/lines/labels into a `RenderQueue` (tested), but no per-version code draws that queue yet, so on screen they show
  nothing. The Render/ESP modules are therefore NOT usable in-game until a world-render hook is written per version (Fabric's render events changed in 1.21.x; I did not guess).
  Block ESP / Netherite Finder / Spawner ESP / Waypoints etc. will behave correctly once drawn.
- **Lag Notifier is silent** (`msSincePacket` has no adapter). **Auto Relog** reconnects on any disconnect because the disconnect reason is not read yet.
- Accessor/mixin targets (`itemUseCooldown`/`rightClickDelay`, break cooldown/progress, `focusedSlot`/`hoveredSlot`, text visitor, attack methods) are from memory; if one is wrong
  the mixin is skipped (`require = 0`) and the dependent module fails safely (disabled with an error) instead of crashing the game.
- Anchor/bed explosions only work outside the Overworld/Nether respectively; Criticals/W-Tap/Velocity/Speed Mine/Boat Fly/Elytra Boost change client behaviour that some servers reject.
  Use them only where the rules allow. None of this is anti-cheat evasion.

## What changed in v6
Jump Reset, Strafe, Staff List and the Compass/Hole/Potion/Server HUD elements (see git history of this file).

## What changed in v5
Build fixes, keybind polling, the `/uc` shell, Client Brand (+ mixin; it does not make the client undetectable), 26.2 adapter, GitHub Actions workflow.

## Registered modules: 118 (logic tested, none run in-game)
**Combat (34):** Jump Reset, Crystal Aura, Crystal Macro, Crystal Optimizer, Anchor Aura, Single Anchor Macro, Anti Anchor, Anchor Guard, Anti Bed, Bed Aura, Auto Anvil, Anti Anvil, Criticals, W-Tap, Mace, Auto Inventory Totem, Hover Totem, Friend Guard, Kill Aura, Auto Totem, Auto Offhand, Auto Armor, Auto Weapon, Aim Assist, Trigger Bot, Auto City, Shield Breaker, Auto EXP, Surround, Auto Trap, Self Trap, Auto Web, Self Web, Hole Filler
**Movement (27):** Strafe, Velocity, Elytra Boost, Boat Fly, Entity Speed, GUI Move, Fly, Elytra Fly, Elytra Autopilot, Speed, Sprint, No Fall, Auto Walk, High Jump, Air Jump, Jesus, Reverse Step, Long Jump, Slow Fall, Step, Safe Walk, Auto Jump, Parkour, Spider, Fast Climb, Sneak, Anti Void
**Player (13):** Fast Use, Fast XP, Break Delay, Speed Mine, Auto Respawn, Auto Eat, Auto Gap, Auto Tool, Auto Replenish, Auto Fish, Auto Clicker, Chest Swap, Anti AFK
**Render (22, not drawn yet):** Fullbright, Zoom, Custom FOV, Entity ESP, Player ESP, Item ESP, Storage ESP, Block ESP, Netherite Finder, Spawner ESP, Hole ESP, City ESP, Target ESP, Tracers, Nametags, Trajectories, Pearl Trajectory, Breadcrumbs, Logout Spots, Waypoints, Block Overlay, Light Overlay (Fullbright, Zoom, Custom FOV do not need the renderer)
**World (13):** Nuker, Tunnel Miner, Vein Miner, Liquid Filler, Spawn Proofer, Stash Finder, E-Chest Farmer, Excavator, Waypoint Navigation, Auto Shearer, Auto Breed, Auto Mount, Baritone
**Misc (8):** Staff List, Auto Reconnect, Auto Relog, Name Protect, Chat Macro, Player Detection, Weather Notifier, Block Notifier
**Client (1):** Client Brand

HUD model elements (21): watermark, active modules, coordinates, speed, direction, totem count, FPS, ping, armor durability, keybinds, crystal info, compass, hole, potions, server, radar, inventory, lag, target, combat. Drawn on-screen on 1.21.11 only; not drawn on 26.2.

## Caveats on specific modules
- Fly, Spider, Anti Void, Slow Fall, Step, Long Jump, Air Jump, Jesus, Reverse Step, Elytra Fly change client motion; many servers correct or reject this. Use only where allowed.
- Anchor Aura: anchors only explode outside the Nether. The damage model is the vanilla formula, not compared with real in-game damage.
- Auto Armor scores armor+toughness attributes only (no enchantments). Auto Fish bite detection is a bobber-velocity heuristic. Fullbright will not touch a real server-given night-vision effect.
- Vein Miner mines the connected ore after YOU break the first block. Block Notifier scans in budgeted slices (default 300 positions per tick).
- Keybinds read keyboard keys only (not mouse buttons). Key polling and brand mixin use `require = 0` so a mapping mismatch disables the feature instead of crashing.

## Not implemented (original spec items still missing)
**Combat:** Spear Lunge, Knockback Delay
**Movement:** No Slow, Trident Boost, Boat NoClip, Entity Control, Click Teleport (not planned: teleport exploits), Blink, Freecam (need packet/camera hooks)
**Player:** Auto Mend, Instant Rebreak, Inventory Tweaks, Anti Hunger, Potion Saver, No Rotate, Rotation, Reach (server-side), Multitask, Liquid Interact
**Render:** the renderer itself (draws nothing yet), X-Ray, Free Look, Freecam, Chams, Wall Hack, Item Highlight, Hit Particles, Custom Crosshair, Motion Blur, No Render, Chunk Scanner, Sus Chunk Finder
**World:** Highway Builder, Auto Brew/Smelt/Sign (need screen automation), automatic building/schematics beyond what Baritone itself does
**Misc / privacy:** Anti Vanish, Anti Ghost Block, Discord Presence (native IPC), Staff Live/Notifications, Coordinate Snapper, Spawner Protection, Media Base Finder, Fake Stats, Inventory Privacy Overlay, tracking-exploit protections
**GUI:** Click GUI screens (search, colour picker, sliders, dropdowns, keybind editor UI). The `/uc` shell is the only control surface.
**HUD:** drag/resize UI, player radar as a graphic, lag source, 26.2 drawing
**Platform:** Android/Pojav testing, Sodium/Iris/VulkanMod/LWJGL compatibility layer, any verified JAR
